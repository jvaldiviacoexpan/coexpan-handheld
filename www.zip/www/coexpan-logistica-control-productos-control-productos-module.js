(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["coexpan-logistica-control-productos-control-productos-module"],{

/***/ "3eJ0":
/*!****************************************************************************************************************************!*\
  !*** ./src/app/pages/coexpan/logistica/control-productos/bodega-planta/bp-etq-reimprimir/bp-etq-reimprimir.component.scss ***!
  \****************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("@import url(\"https://fonts.googleapis.com/css2?family=Rubik:wght@600&display=swap\");\n*:not(ion-icon) {\n  font-family: \"Rubik\", sans-serif !important;\n}\nion-header .toolbar {\n  --background: rgba(0, 145, 197, 0.5);\n  --color: white;\n}\nion-content {\n  --background: none;\n}\nion-content .ion-row-1 {\n  padding-top: 4px;\n}\nion-content .ion-row-1 .ion-list {\n  background-color: rgba(232, 233, 233, 0);\n  border-radius: 3%;\n}\nion-content .ion-row-1 .ion-list ion-item {\n  --background: rgb(232, 233, 233, 0.8);\n}\nion-footer .toolbar {\n  --background: rgba(0, 0, 0, 0);\n  --color: white;\n}\nion-footer .ion-row-2 .btn-1 {\n  --background: rgba(0, 75, 102, 0.99);\n  --color: white;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcYnAtZXRxLXJlaW1wcmltaXIuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQVEsbUZBQUE7QUFHUjtFQUNFLDJDQUFBO0FBREY7QUFLRTtFQUNFLG9DQUFBO0VBQ0EsY0FBQTtBQUZKO0FBTUE7RUFDRSxrQkFBQTtBQUhGO0FBSUU7RUFDRSxnQkFBQTtBQUZKO0FBR0k7RUFDRSx3Q0FBQTtFQUNBLGlCQUFBO0FBRE47QUFFTTtFQUNFLHFDQUFBO0FBQVI7QUFRRTtFQUNFLDhCQUFBO0VBQ0EsY0FBQTtBQUxKO0FBUUk7RUFDRSxvQ0FBQTtFQUNBLGNBQUE7QUFOTiIsImZpbGUiOiJicC1ldHEtcmVpbXByaW1pci5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIkBpbXBvcnQgdXJsKCdodHRwczovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2NzczI/ZmFtaWx5PVJ1YmlrOndnaHRANjAwJmRpc3BsYXk9c3dhcCcpO1xyXG5cclxuXHJcbio6bm90KGlvbi1pY29uKSB7XHJcbiAgZm9udC1mYW1pbHk6ICdSdWJpaycsIHNhbnMtc2VyaWYhaW1wb3J0YW50O1xyXG59XHJcblxyXG5pb24taGVhZGVyIHtcclxuICAudG9vbGJhciB7XHJcbiAgICAtLWJhY2tncm91bmQ6IHJnYmEoMCwgMTQ1LCAxOTcsIDAuNSk7XHJcbiAgICAtLWNvbG9yOiB3aGl0ZTtcclxuICB9XHJcbn1cclxuXHJcbmlvbi1jb250ZW50IHtcclxuICAtLWJhY2tncm91bmQ6IG5vbmU7XHJcbiAgLmlvbi1yb3ctMXtcclxuICAgIHBhZGRpbmctdG9wOiA0cHg7XHJcbiAgICAuaW9uLWxpc3Qge1xyXG4gICAgICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2IoMjMyLCAyMzMsIDIzMywgMC4wKTtcclxuICAgICAgYm9yZGVyLXJhZGl1czogMyU7XHJcbiAgICAgIGlvbi1pdGVtIHtcclxuICAgICAgICAtLWJhY2tncm91bmQ6IHJnYigyMzIsIDIzMywgMjMzLCAwLjgpO1xyXG5cclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxufVxyXG5cclxuaW9uLWZvb3RlciB7XHJcbiAgLnRvb2xiYXIge1xyXG4gICAgLS1iYWNrZ3JvdW5kOiByZ2JhKDAsIDAsIDAsIDApO1xyXG4gICAgLS1jb2xvcjogd2hpdGU7XHJcbiAgfVxyXG4gIC5pb24tcm93LTJ7XHJcbiAgICAuYnRuLTEge1xyXG4gICAgICAtLWJhY2tncm91bmQ6IHJnYmEoMCwgNzUsIDEwMiwgMC45OSk7XHJcbiAgICAgIC0tY29sb3I6IHdoaXRlO1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG5cclxuXHJcbiJdfQ== */");

/***/ }),

/***/ "5Gyp":
/*!**************************************************************************************************************************!*\
  !*** ./src/app/pages/coexpan/logistica/control-productos/bodega-planta/bp-etq-reimprimir/bp-etq-reimprimir.component.ts ***!
  \**************************************************************************************************************************/
/*! exports provided: BpEtqReimprimirComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BpEtqReimprimirComponent", function() { return BpEtqReimprimirComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_bp_etq_reimprimir_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./bp-etq-reimprimir.component.html */ "ir1d");
/* harmony import */ var _bp_etq_reimprimir_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./bp-etq-reimprimir.component.scss */ "3eJ0");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _models_Registros_model__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../../../models/Registros.model */ "JUB7");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _providers_web_services_cxp_cxp_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../../../../providers/web-services/cxp/cxp.service */ "4gYv");







let BpEtqReimprimirComponent = class BpEtqReimprimirComponent {
    constructor(alertCtrl, loadingCtrl, toastController, cxpService) {
        this.alertCtrl = alertCtrl;
        this.loadingCtrl = loadingCtrl;
        this.toastController = toastController;
        this.cxpService = cxpService;
        //#region VARIABLES
        this.pallets = [];
        this.isLoading = false;
        //#endregion VIEWCHILD
        //#region MODEL HTML
        this.txtarea = {
            spinner: false,
        };
    }
    //#endregion MODEL HTML
    ngOnInit() { }
    ngAfterViewInit() {
        this.btnEnviar.disabled = true;
        setTimeout(() => {
            this.txtCodigos.setFocus();
        }, 200);
    }
    textoCodigos(valor) {
        this.codigos = valor;
        if (this.codigos.length === 0) {
            this.btnEnviar.disabled = true;
        }
        else {
            this.btnEnviar.disabled = false;
        }
        console.log(this.codigos);
    }
    obtenerDatosPallet(codbarramulti) {
        // let pallet: PalletModel = new PalletModel();
        const datos = new _models_Registros_model__WEBPACK_IMPORTED_MODULE_4__["InfoEtiquetaModel"]();
        let request = new _models_Registros_model__WEBPACK_IMPORTED_MODULE_4__["GetRequestModel"]();
        //#region html
        this.txtCodigos.disabled = true;
        this.txtCodigos.value = '';
        this.txtarea.spinner = true;
        //#endregion html
        //#region condicion
        const cbm = codbarramulti.trim();
        if (cbm.length <= 0) {
            this.messageToast('Escanée un Código de Pallet', 2000);
            return;
        }
        if (cbm.length <= 11) {
            datos.CodBobina = cbm;
            datos.CodPallet = 'N';
        }
        else {
            datos.CodBobina = 'N';
            datos.CodPallet = cbm;
        }
        //#endregion condicion
        this.cxpService.cxpObtenerInformacionEtiquetaPallet(datos).then((data) => {
            request = JSON.parse(data.toString());
            if (request.Status.STATUS === 'T') {
                if (request.Objeto !== null) {
                    this.pallets.push(request.Objeto);
                }
                else {
                    this.messageToast(`Etiqueta de Pallet no encontrada.`, 2000);
                }
            }
            else {
                this.messageToast(request.Status.MESSAGE, 10000);
            }
            this.existenitems();
            //#region html
            this.txtCodigos.disabled = false;
            this.txtarea.spinner = false;
            setTimeout(() => {
                this.txtCodigos.setFocus();
            }, 100);
            //#endregion html
        }, (err) => {
            console.log(err);
            this.existenitems();
            //#region html
            this.txtCodigos.disabled = false;
            this.txtarea.spinner = false;
            //#endregion html
        });
        // this.txtCodigos.disabled = true;
        // this.txtCodigos.value = '';
        // this.txtarea.spinner = true;
        console.log(cbm);
    }
    imprimirEtiquetas() {
        const datos = new _models_Registros_model__WEBPACK_IMPORTED_MODULE_4__["ImpresoraEtiquetaPalletModel"]();
        let request = new _models_Registros_model__WEBPACK_IMPORTED_MODULE_4__["GetRequestModel"]();
        const ip = localStorage.getItem('ipimp');
        if (ip) {
            datos.IpZebra = ip;
            datos.Pallets = this.pallets;
            this.cxpService.cxpReimprimirEtiquetaPallet(datos).then((data) => {
                console.log(data);
                request = JSON.parse(data.toString());
                if (request.Status.STATUS === 'T') {
                    this.messageToast(request.Status.MESSAGE, 2000);
                }
                else {
                    let str1 = 'Ocurrio un problema al imprimir: \n';
                    request.Objeto.forEach(el => {
                        str1 += `  - ${el}\n`;
                    });
                    this.messageToast(str1, 6000);
                }
            }, (err) => {
                console.log(err);
                this.messageToast(err, 6000);
            });
        }
        else {
            this.messageToast(`Selecciones una impresora en el menu.`, 2000);
        }
    }
    // public palletRepetido(nropallets: string): boolean {
    //   let existe = false;
    //   this.pallets.forEach(pt => {
    //     if (pt.CODBAR_MULTI === nropallets) {existe = true; }
    //   });
    //   return existe;
    // }
    // public enviarEntradaMercancia() {
    //   console.log('se envía para imprimir.');
    // }
    eliminarItem(nropallet) {
        for (let i = 0; i < this.pallets.length; i++) {
            if (this.pallets[i].CODBAR_MULTI === nropallet) {
                this.pallets.splice(i, 1);
                this.messageToast(`Etiqueta ${nropallet} Quitado de la lista.`, 2000);
                this.existenitems();
            }
        }
        console.log(`Etiqueta Eliminada: ${nropallet}`);
    }
    //#region Informacion Pallet
    infoItem(nropallet) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            let pallet = new _models_Registros_model__WEBPACK_IMPORTED_MODULE_4__["PalletModel"]();
            pallet = this.obtenerPallet(nropallet);
            const str = this.generarListaBobinas(pallet);
            const alert = yield this.alertCtrl.create({
                cssClass: 'alert-palletybobinas',
                header: `DETALLE PALLET ${nropallet}`,
                message: str,
            });
            yield alert.present();
        });
    }
    obtenerPallet(nroPallet) {
        let rtnPallet = new _models_Registros_model__WEBPACK_IMPORTED_MODULE_4__["PalletModel"]();
        this.pallets.forEach(pallet => {
            if (pallet.CODBAR_MULTI === nroPallet) {
                rtnPallet = pallet;
            }
        });
        return rtnPallet;
    }
    generarListaBobinas(pallet) {
        const str = `
    <ion-list>
          <ion-item>
            <ion-label>OF - ${pallet.ORDEN_FAB.substr(5, 20)}</ion-label>
          </ion-item>
          <ion-item>
            <ion-label>CLIENTE - ${pallet.CLIENTE}</ion-label>
          </ion-item>
          <ion-item>
            <ion-label>PALLET ${pallet.CORRELATIVO}</ion-label>
          </ion-item>
          <ion-item>
            <ion-label>KG BRUTO - ${pallet.PESO_BRUTO}</ion-label>
          </ion-item>
          <ion-item>
            <ion-label>KG NETO ${pallet.PESO_NETO}</ion-label>
          </ion-item>
        </ion-list>
        <br>`;
        return str;
    }
    //#endregion Informacion Pallet
    //#region HERRAMIENTAS
    existenitems() {
        if (this.pallets.length > 0) {
            this.btnEnviar.disabled = false;
            return true;
        }
        else {
            this.btnEnviar.disabled = true;
            return false;
        }
    }
    showLoading() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.isLoading = true;
            return yield this.loadingCtrl.create({
                cssClass: 'loading',
                message: 'Enviando...',
            }).then(a => {
                a.present().then(() => {
                    // console.log('presented');
                    if (!this.isLoading) {
                        a.dismiss();
                    }
                });
            });
        });
    }
    dismissLoading() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.isLoading = false;
            return yield this.loadingCtrl.dismiss().then(() => console.log('dismissed'));
        });
    }
    messageToast(msj, time) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const toast = yield this.toastController.create({
                message: msj,
                duration: time
            });
            toast.present();
        });
    }
    obtenerFecha() {
        const fechaDate = new Date();
        let fechaString = '';
        const anio = fechaDate.getFullYear();
        let dia = '';
        let mes = '';
        let hora = '';
        let minuto = '';
        let segundo = '';
        if (fechaDate.getDate() < 10) {
            dia = `0${fechaDate.getDate()}`;
        }
        else {
            dia = fechaDate.getDate().toString();
        }
        if (fechaDate.getMonth() < 10) {
            mes = `0${fechaDate.getMonth() + 1}`;
        }
        else {
            mes = (fechaDate.getMonth() + 1).toString();
        }
        if (fechaDate.getHours() < 10) {
            hora = `0${fechaDate.getHours()}`;
        }
        else {
            hora = fechaDate.getHours().toString();
        }
        if (fechaDate.getMinutes() < 10) {
            minuto = `0${fechaDate.getMinutes()}`;
        }
        else {
            minuto = fechaDate.getMinutes().toString();
        }
        if (fechaDate.getSeconds() < 10) {
            segundo = `0${fechaDate.getSeconds()}`;
        }
        else {
            segundo = fechaDate.getSeconds().toString();
        }
        fechaString = `${anio}${mes}${dia} ${hora}:${minuto}:${segundo}`;
        return fechaString;
    }
    transformarArreglo(codigos) {
        const arrayCadena = codigos.trim().split(' ');
        const arrayCadenaClean = arrayCadena.filter(Boolean);
        const arrayClean = [...new Set(arrayCadenaClean)];
        return arrayClean;
    }
    removerPallet(codpallet) {
        for (let i = 0; i < this.pallets.length; i++) {
            if (this.pallets[i].CODBAR_MULTI === codpallet) {
                this.pallets.splice(i, 1);
                this.existenitems();
            }
        }
    }
};
BpEtqReimprimirComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["LoadingController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ToastController"] },
    { type: _providers_web_services_cxp_cxp_service__WEBPACK_IMPORTED_MODULE_6__["CxpService"] }
];
BpEtqReimprimirComponent.propDecorators = {
    btnEnviar: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"], args: ['btnEnviar',] }],
    txtCodigos: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"], args: ['codigos',] }]
};
BpEtqReimprimirComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-bp-etq-reimprimir',
        template: _raw_loader_bp_etq_reimprimir_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_bp_etq_reimprimir_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], BpEtqReimprimirComponent);



/***/ }),

/***/ "5aaO":
/*!*************************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/coexpan/logistica/control-productos/bodega-renca/br-egreso/br-egreso.component.html ***!
  \*************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar class=\"toolbar\">\n    <ion-title>Egreso de Bobinas</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-grid fixed>\n    <ion-row class=\"ion-justify-content-center\">\n      <ion-col size=\"12\">\n        <ion-item class=\"ion-item-1\">\n          <ion-textarea #codigos rows=\"13\"\n            (keyup)=\"revisarTexto(codigos.value)\"\n            (keyup.enter)=\"presentAlertConfirm(codigos.value)\"\n            placeholder=\"Escanea las bobinas para ingresar...\">\n          </ion-textarea>\n        </ion-item>\n      </ion-col>\n    </ion-row>\n    <ion-row class=\"ion-row-2 ion-justify-content-center\">\n      <ion-col size=\"12\">\n          <ion-button #btnenviar size=\"large\" expand=\"block\" color=\"dark\"\n          (click)=\"presentAlertConfirm(codigos.value)\">\n            Enviar\n          </ion-button>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-content>\n\n\n<ion-footer class=\"ion-no-border\">\n  <div class=\"tri_inf_izq\"> </div>\n  <div class=\"tri_inf_der\"></div>\n</ion-footer>\n");

/***/ }),

/***/ "5s14":
/*!****************************************************************************************************************************************!*\
  !*** ./src/app/pages/coexpan/logistica/control-productos/bodega-planta/bp-etq-entrada-mercancia/bp-etq-entrada-mercancia.component.ts ***!
  \****************************************************************************************************************************************/
/*! exports provided: BpEtqEntradaMercanciaComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BpEtqEntradaMercanciaComponent", function() { return BpEtqEntradaMercanciaComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_bp_etq_entrada_mercancia_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./bp-etq-entrada-mercancia.component.html */ "TChH");
/* harmony import */ var _bp_etq_entrada_mercancia_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./bp-etq-entrada-mercancia.component.scss */ "iUSm");
/* harmony import */ var _models_Registros_model__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../../../../../../models/Registros.model */ "JUB7");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _providers_web_services_cxp_cxp_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../../../../providers/web-services/cxp/cxp.service */ "4gYv");








let BpEtqEntradaMercanciaComponent = class BpEtqEntradaMercanciaComponent {
    constructor(alertCtrl, loadingCtrl, cxpService, toastController) {
        this.alertCtrl = alertCtrl;
        this.loadingCtrl = loadingCtrl;
        this.cxpService = cxpService;
        this.toastController = toastController;
        this.impresoras = new _models_Registros_model__WEBPACK_IMPORTED_MODULE_3__["GetRequestModel"]();
        this.isLoading = false;
    }
    ngOnInit() {
        this.cargarEtlPesaje();
    }
    ngAfterViewInit() {
        this.btnEnviar.disabled = true;
        this.txtCodigos.autofocus = true;
    }
    cargarEtlPesaje(event) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const loading = yield this.loadingCtrl.create({
                cssClass: 'my-custom-class',
                message: 'Preparando datos...',
            });
            yield loading.present();
            this.cxpService.cxpLogisticaEjecutarEtlPesaje().then(data => {
                loading.dismiss();
                console.log(data);
                switch (data) {
                    case '"0"':
                        this.pstAlert('Error!', 'Problema al cargar la información al sistema.');
                        break;
                    case '"1"':
                        console.log('Cargado con éxito');
                        const ip = localStorage.getItem('ipimp');
                        if (ip) {
                            this.comprobarEstadoImpresora(ip);
                            break;
                        }
                        else {
                            this.obtenerImpresoras();
                            break;
                        }
                    case '"3"':
                        this.pstAlert('Error!', 'Carga de información cancelada.');
                        break;
                    case '"5"':
                        this.pstAlert('Error!', 'Error Desconocido.');
                        break;
                    default:
                        this.pstAlert('Error!', data.toString());
                        break;
                }
            }, (err) => {
                this.pstAlert('Error Grave', 'Problema lógico de parte del servidor.');
                console.log(err);
                if (event) {
                    event.target.complete();
                    // loading.dismiss();
                }
                loading.dismiss();
            });
            if (event) {
                event.target.complete();
            }
        });
    }
    //#region HERRAMIENTAS
    obtenerImpresoras() {
        let rq = new _models_Registros_model__WEBPACK_IMPORTED_MODULE_3__["GetRequestModel"]();
        this.cxpService.cxpLogisticaGetImpresora().then(data => {
            rq = JSON.parse(data.toString());
            // console.log(rq);
            this.impresoras = rq;
            this.alertselectimpresora();
        }, (err) => {
            console.log(err);
        });
    }
    alertselectimpresora() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const inputss = [];
            this.impresoras.Objeto.forEach(im => {
                inputss.push(this.generarInput(im.NSERIAL, im.TAG_NOMBRE, im.IP));
            });
            const alert = yield this.alertCtrl.create({
                cssClass: '',
                header: 'Selec. Impresora',
                inputs: inputss,
                buttons: [
                    {
                        text: 'OK',
                        handler: (ip) => {
                            // console.log(ip);
                            localStorage.setItem('ipimp', ip);
                            this.comprobarEstadoImpresora(ip);
                        },
                    },
                ],
            });
            yield alert.present();
        });
    }
    generarInput(dname, dlabel, dvalue) {
        const input = {
            name: dname,
            type: 'radio',
            label: dlabel,
            value: dvalue,
        };
        return input;
    }
    //#endregion HERRAMIENTAS
    textoCodigos(valor) {
        this.codigos = valor;
        if (this.codigos.length === 0) {
            this.btnEnviar.disabled = true;
        }
        else {
            this.btnEnviar.disabled = false;
        }
        console.log(this.codigos);
    }
    revisionCodigos() {
        this.arrayCod = this.transformarArreglo(this.codigos);
        if (this.arrayCod.length === 0) {
            this.pstErrorCodigos();
        }
        else {
            this.pstConfirmarEnvio();
        }
    }
    enviarCodigos() {
        const registros = new _models_Registros_model__WEBPACK_IMPORTED_MODULE_3__["RegistrosModel"]();
        registros.CodBarras = this.arrayCod;
        registros.FechaScan = this.obtenerFecha();
        registros.Bodega = 1;
        registros.IdUsuario = null;
        let mensaje;
        let err = 0;
        let suc = 0;
        this.present();
        this.cxpService.cxpLogisticaEntradaMercancia(registros).then((res) => {
            this.dismiss();
            console.log(res);
            mensaje = JSON.parse(res.toString());
            console.log(mensaje);
            mensaje.EstadoCodigos.forEach(status => {
                switch (status.ESTADO) {
                    case 'F':
                        err += 1;
                        break;
                    case 'T':
                        suc += 1;
                        break;
                    default: break;
                }
            });
            if (mensaje.Status.STATUS === 'T') {
                let bobError = '';
                // let infobob = '';
                if (err > 0) {
                    bobError = `<strong>Error: ${err} bob.<br></strong>`;
                }
                this.pstAlert('Estado de Ingreso', `<strong>Correctas: ${suc} bob.<br></strong><br>
          ${bobError}`);
                if (err === 0) {
                    const datosImpresion = new _models_Registros_model__WEBPACK_IMPORTED_MODULE_3__["ImprimirEtqMultipleZebraModel"]();
                    datosImpresion.CodBarra = mensaje.EstadoCodigos[0].CODBARRA;
                    datosImpresion.IpZebra = localStorage.getItem('ipimp');
                    this.cxpService.cxpLogisticaImprimirEtiquetaMultimple(datosImpresion).then(dataImpresion => {
                        console.log(dataImpresion);
                    }, (errImpresion => {
                        console.log(errImpresion);
                    }));
                }
            }
            else if (mensaje.Status.STATUS === 'F') {
                this.pstAlert('Error!', mensaje.Status.MESSAGE);
            }
            else {
                this.pstAlert('Error!', mensaje.Status.MESSAGE_EXCEPTION_DESCR);
            }
        }, (errr) => {
            console.log(err);
            this.pstAlert('Error de Servidor...', errr);
            this.dismiss();
        });
        this.txtCodigos.value = '';
        this.btnEnviar.disabled = true;
        this.txtCodigos.setFocus();
    }
    //#region HERRAMIENTAS
    pstErrorCodigos() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                header: 'Error',
                message: 'Ingrese 1 o más códigos para continuar...',
                buttons: [{ text: 'Ok' }]
            });
            yield alert.present();
            this.btnEnviar.disabled = true;
            this.txtCodigos.value = '';
        });
    }
    pstConfirmarEnvio() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                cssClass: 'loading',
                header: 'Confirmar Envío',
                message: 'Desea enviar los <strong>Códigos de Bobinas</strong> ?',
                buttons: [
                    {
                        text: 'Cancelar',
                        role: 'cancel',
                        handler: () => {
                            console.log('no se envió :(');
                        }
                    }, {
                        text: 'Ok',
                        handler: () => {
                            this.enviarCodigos();
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    present() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.isLoading = true;
            return yield this.loadingCtrl.create({
                cssClass: 'loading',
                message: 'Enviando...',
            }).then(a => {
                a.present().then(() => {
                    // console.log('presented');
                    if (!this.isLoading) {
                        a.dismiss();
                    }
                });
            });
        });
    }
    pstAlert(cab, cuerpo, subcab) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                cssClass: 'loading',
                header: cab,
                subHeader: subcab,
                message: cuerpo,
                buttons: [
                    {
                        text: 'OK',
                        handler: () => {
                            this.txtCodigos.setFocus();
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    dismiss() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.isLoading = false;
            return yield this.loadingCtrl.dismiss().then(() => console.log('dismissed'));
        });
    }
    obtenerFecha() {
        const fechaDate = new Date();
        let fechaString = '';
        const anio = fechaDate.getFullYear();
        let dia = '';
        let mes = '';
        let hora = '';
        let minuto = '';
        let segundo = '';
        if (fechaDate.getDate() < 10) {
            dia = `0${fechaDate.getDate()}`;
        }
        else {
            dia = fechaDate.getDate().toString();
        }
        if (fechaDate.getMonth() < 9) {
            mes = `0${fechaDate.getMonth() + 1}`;
        }
        else {
            mes = (fechaDate.getMonth() + 1).toString();
        }
        if (fechaDate.getHours() < 10) {
            hora = `0${fechaDate.getHours()}`;
        }
        else {
            hora = fechaDate.getHours().toString();
        }
        if (fechaDate.getMinutes() < 10) {
            minuto = `0${fechaDate.getMinutes()}`;
        }
        else {
            minuto = fechaDate.getMinutes().toString();
        }
        if (fechaDate.getSeconds() < 10) {
            segundo = `0${fechaDate.getSeconds()}`;
        }
        else {
            segundo = fechaDate.getSeconds().toString();
        }
        fechaString = `${anio}${mes}${dia} ${hora}:${minuto}:${segundo}`;
        console.log(mes);
        return fechaString;
    }
    transformarArreglo(codigos) {
        const arrayCadena = codigos.trim().split(' ');
        const arrayCadenaClean = arrayCadena.filter(Boolean);
        const arrayClean = [...new Set(arrayCadenaClean)];
        return arrayClean;
    }
    messageToast(msj, time) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const toast = yield this.toastController.create({
                message: msj,
                duration: time,
            });
            toast.present();
        });
    }
    comprobarEstadoImpresora(ip) {
        let status = new _models_Registros_model__WEBPACK_IMPORTED_MODULE_3__["GetRequestModel"]();
        const impresora = new _models_Registros_model__WEBPACK_IMPORTED_MODULE_3__["ImpresoraPostModel"]();
        impresora.ipAddress = ip;
        this.cxpService.cxpEstadoImpresora(impresora).then(data => {
            status = JSON.parse(data.toString());
            console.log(status);
            if (status.Status.STATUS === 'T') {
                status.Objeto.forEach(el => {
                    this.messageToast(el, 2000);
                });
            }
            else {
                this.messageToast(status.Status.MESSAGE, 5000);
            }
        }, (err) => {
            this.messageToast(err, 5000);
        });
    }
};
BpEtqEntradaMercanciaComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["LoadingController"] },
    { type: _providers_web_services_cxp_cxp_service__WEBPACK_IMPORTED_MODULE_6__["CxpService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ToastController"] }
];
BpEtqEntradaMercanciaComponent.propDecorators = {
    btnEnviar: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["ViewChild"], args: ['btnEnviar',] }],
    txtCodigos: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["ViewChild"], args: ['codigos',] }]
};
BpEtqEntradaMercanciaComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
        selector: 'app-bp-entrada-mercancia',
        template: _raw_loader_bp_etq_entrada_mercancia_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_bp_etq_entrada_mercancia_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], BpEtqEntradaMercanciaComponent);



/***/ }),

/***/ "5txJ":
/*!***************************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/coexpan/logistica/control-productos/bodega-renca/menu-renca/menu-renca.component.html ***!
  \***************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n\n<ion-header>\n  <ion-toolbar class=\"toolbar ion-text-center\">\n    <ion-title class=\"title\"><strong>Bodega Renca</strong></ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content fixed>\n  <ion-grid size=\"sx\" class=\"ion-grid-1\">\n    <ion-row class=\"ion-row-1 ion-align-items-center\">\n      <ion-col size=\"12\">\n        <ion-button color=\"tertiary\" size=\"large\" expand=\"block\" (click)=\"pageIngreso()\">\n          ENTRADA\n        </ion-button>\n      </ion-col>\n      <ion-col size=\"12\">\n        <ion-button color=\"secondary\" size=\"large\" expand=\"block\" (click)=\"pageEgreso()\">\n          SALIDA\n        </ion-button>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-content>\n\n<ion-footer class=\"ion-no-border\">\n  <div class=\"tri_inf_izq\"> </div>\n  <div class=\"tri_inf_der\"></div>\n</ion-footer>\n");

/***/ }),

/***/ "6+NG":
/*!******************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/coexpan/logistica/control-productos/page-control/page-control.component.html ***!
  \******************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n<ion-header class=\"ion-no-border\">\n  <ion-toolbar class=\"toolbar\">\n    <div class=\"tri_sup_izq\"> </div>\n    <div class=\"tri_sup_der\"></div>\n    <ion-title class=\"title ion-no-padding\"><strong>Bodega Planta</strong></ion-title>\n    <ion-button class=\"btn-sand\"\n      (click)=\"openMenu()\" slot=\"start\" fill=\"outline\" color=\"warning\">\n      <ion-icon color=\"warning\" name=\"menu\"></ion-icon>\n    </ion-button>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-grid fixed size=\"sx\">\n    <ion-row class=\"ion-align-items-center\">\n      <ion-col size=\"12\">\n        <ion-button size=\"large\" expand=\"block\" color=\"danger\">\n          Coembal (disabled)\n        </ion-button>\n      </ion-col>\n\n      <ion-col size=\"12\">\n        <ion-button size=\"large\" expand=\"block\" (click)=\"pageBodegasCxp()\" color=\"tertiary\">\n          Coexpan\n        </ion-button>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-content>\n\n\n<ion-footer class=\"ion-no-border\">\n  <div class=\"tri_inf_izq\"> </div>\n  <div class=\"tri_inf_der\"></div>\n</ion-footer>\n");

/***/ }),

/***/ "6GvH":
/*!*************************************************************************************************************!*\
  !*** ./src/app/pages/coexpan/logistica/control-productos/bodega-renca/br-ingreso/br-ingreso.component.scss ***!
  \*************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("@import url(\"https://fonts.googleapis.com/css2?family=Rubik:wght@600&display=swap\");\n*:not(ion-icon) {\n  font-family: \"Rubik\", sans-serif !important;\n}\nion-header .toolbar {\n  --background: rgba(89, 81, 235, 0.9);\n  --color: white;\n}\nion-content {\n  --ion-background-color: none;\n}\nion-content ion-grid .ion-item-1 {\n  background-color: #e8e9e9;\n  border-radius: 3%;\n}\nion-content ion-grid .ion-row-2 {\n  padding-top: 6px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcYnItaW5ncmVzby5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBUSxtRkFBQTtBQUVSO0VBQ0UsMkNBQUE7QUFBRjtBQUlFO0VBQ0Usb0NBQUE7RUFDQSxjQUFBO0FBREo7QUFLQTtFQUNFLDRCQUFBO0FBRkY7QUFJSTtFQUNFLHlCQUFBO0VBQ0EsaUJBQUE7QUFGTjtBQUlJO0VBQ0UsZ0JBQUE7QUFGTiIsImZpbGUiOiJici1pbmdyZXNvLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiQGltcG9ydCB1cmwoJ2h0dHBzOi8vZm9udHMuZ29vZ2xlYXBpcy5jb20vY3NzMj9mYW1pbHk9UnViaWs6d2dodEA2MDAmZGlzcGxheT1zd2FwJyk7XHJcblxyXG4qOm5vdChpb24taWNvbikge1xyXG4gIGZvbnQtZmFtaWx5OiAnUnViaWsnLCBzYW5zLXNlcmlmIWltcG9ydGFudDtcclxufVxyXG5cclxuaW9uLWhlYWRlciB7XHJcbiAgLnRvb2xiYXIge1xyXG4gICAgLS1iYWNrZ3JvdW5kOiByZ2JhKDg5LCA4MSwgMjM1LCAwLjkpO1xyXG4gICAgLS1jb2xvcjogd2hpdGU7XHJcbiAgfVxyXG59XHJcblxyXG5pb24tY29udGVudHtcclxuICAtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yOiBub25lO1xyXG4gIGlvbi1ncmlkIHtcclxuICAgIC5pb24taXRlbS0xIHtcclxuICAgICAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDIzMiwgMjMzLCAyMzMpO1xyXG4gICAgICBib3JkZXItcmFkaXVzOiAzJTtcclxuICAgIH1cclxuICAgIC5pb24tcm93LTIge1xyXG4gICAgICBwYWRkaW5nLXRvcDogNnB4O1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG4iXX0= */");

/***/ }),

/***/ "AEVk":
/*!***************************************************************************************!*\
  !*** ./src/app/pages/coexpan/logistica/control-productos/control-productos.module.ts ***!
  \***************************************************************************************/
/*! exports provided: ControlProductosModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ControlProductosModule", function() { return ControlProductosModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _control_productos_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./control-productos-routing.module */ "rCgx");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "ofXK");





let ControlProductosModule = class ControlProductosModule {
};
ControlProductosModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonicModule"],
            _angular_common__WEBPACK_IMPORTED_MODULE_4__["CommonModule"],
            _control_productos_routing_module__WEBPACK_IMPORTED_MODULE_3__["ControlProductosRoutingModule"],
        ],
        declarations: [
            ..._control_productos_routing_module__WEBPACK_IMPORTED_MODULE_3__["routedComponents"],
        ]
    })
], ControlProductosModule);



/***/ }),

/***/ "BuxF":
/*!************************************************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/coexpan/logistica/control-productos/bodega-planta/bp-entrada-mercancia/bp-entrada-mercancia.component.html ***!
  \************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar class=\"toolbar\">\n    <ion-grid fixed>\n      <ion-row class=\"ion-row-1 ion-justify-content-center\">\n        <ion-col size=\"12\">\n          <ion-title>Entrada de Mercancía</ion-title>\n        </ion-col>\n        <ion-col size=\"12\">\n          <ion-item class=\"ion-item-1\">\n            <ion-textarea #codigos rows=\"1\"\n              disabled=\"false\"\n              placeholder=\"Escanea Códido de Pallet...\"\n              (keyup.enter)=\"obtenerDatosPallet(codigos.value)\">\n            </ion-textarea>\n            <ion-spinner *ngIf=\"txtarea.spinner\"  style=\"margin-top: 10px;\" name=\"bubbles\"></ion-spinner>\n          </ion-item>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-grid fixed>\n    <ion-row class=\"ion-row-1\">\n      <ion-col size=\"12\">\n        <ion-list class=\"ion-list\">\n          <ion-item *ngIf=\"pallets.length <= 0\" >\n            <ion-label color=\"dark\">Sin Datos...</ion-label>\n          </ion-item>\n          <ion-item-sliding *ngFor=\"let pt of pallets\">\n            <ion-item>\n              <ion-label>OF: {{pt.Pallet.ORDEN_FAB|number}} - N° Pallet: {{pt.Pallet.CORRELATIVO}}</ion-label>\n              <ion-button #btnpallet (click)=\"infoItem(pt.Pallet.CODBAR_MULTI)\"\n              expand=\"block\" color=\"primary\" shape=\"round\">\n                Info\n              </ion-button>\n            </ion-item>\n            <ion-item-options side=\"end\">\n              <ion-item-option (click)=\"eliminarItem(pt.Pallet.CODBAR_MULTI)\">Borrar</ion-item-option>\n            </ion-item-options>\n          </ion-item-sliding>\n        </ion-list>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-content>\n\n<ion-footer>\n  <ion-toolbar class=\"toolbar\">\n    <ion-grid fixed>\n      <ion-row class=\"ion-row-2 ion-justify-content-center\">\n        <ion-col size=\"12\">\n          <ion-button #btnEnviar size=\"large\" expand=\"block\" class=\"btn-1\"\n            (click)=\"AlertaEnviarEntradaSap()\">\n            Enviar\n          </ion-button>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </ion-toolbar>\n</ion-footer>\n");

/***/ }),

/***/ "Cmb5":
/*!********************************************************************************************************************************!*\
  !*** ./src/app/pages/coexpan/logistica/control-productos/bodega-planta/bp-salida-mercancia/bp-salida-mercancia.component.scss ***!
  \********************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("@import url(\"https://fonts.googleapis.com/css2?family=Rubik:wght@600&display=swap\");\n*:not(ion-icon) {\n  font-family: \"Rubik\", sans-serif !important;\n}\nion-header .toolbar {\n  --background: rgb(250, 90, 90, 0.9);\n  --color: white;\n}\nion-content {\n  --background: none;\n}\nion-content .ion-row-1 {\n  padding-top: 4px;\n}\nion-content .ion-row-1 .ion-item-1 {\n  background-color: #e8e9e9;\n  border-radius: 3%;\n}\nion-content .ion-row-2 .btn-1 {\n  --background: rgb(0, 0, 0);\n  --color: white;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcYnAtc2FsaWRhLW1lcmNhbmNpYS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBUSxtRkFBQTtBQUVSO0VBQ0UsMkNBQUE7QUFBRjtBQUlFO0VBQ0UsbUNBQUE7RUFDQSxjQUFBO0FBREo7QUFLQTtFQUNFLGtCQUFBO0FBRkY7QUFHRTtFQUNFLGdCQUFBO0FBREo7QUFFSTtFQUNFLHlCQUFBO0VBQ0EsaUJBQUE7QUFBTjtBQUlJO0VBQ0UsMEJBQUE7RUFDQSxjQUFBO0FBRk4iLCJmaWxlIjoiYnAtc2FsaWRhLW1lcmNhbmNpYS5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIkBpbXBvcnQgdXJsKCdodHRwczovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2NzczI/ZmFtaWx5PVJ1YmlrOndnaHRANjAwJmRpc3BsYXk9c3dhcCcpO1xyXG5cclxuKjpub3QoaW9uLWljb24pIHtcclxuICBmb250LWZhbWlseTogJ1J1YmlrJywgc2Fucy1zZXJpZiFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbmlvbi1oZWFkZXIge1xyXG4gIC50b29sYmFyIHtcclxuICAgIC0tYmFja2dyb3VuZDogcmdiKDI1MCwgOTAsIDkwLCAwLjkpO1xyXG4gICAgLS1jb2xvcjogd2hpdGU7XHJcbiAgfVxyXG59XHJcblxyXG5pb24tY29udGVudCB7XHJcbiAgLS1iYWNrZ3JvdW5kOiBub25lO1xyXG4gIC5pb24tcm93LTF7XHJcbiAgICBwYWRkaW5nLXRvcDogNHB4O1xyXG4gICAgLmlvbi1pdGVtLTEge1xyXG4gICAgICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2IoMjMyLCAyMzMsIDIzMyk7XHJcbiAgICAgIGJvcmRlci1yYWRpdXM6IDMlO1xyXG4gICAgfVxyXG4gIH1cclxuICAuaW9uLXJvdy0ye1xyXG4gICAgLmJ0bi0xIHtcclxuICAgICAgLS1iYWNrZ3JvdW5kOiByZ2IoMCwgMCwgMCk7XHJcbiAgICAgIC0tY29sb3I6IHdoaXRlO1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG5cclxuIl19 */");

/***/ }),

/***/ "DzOn":
/*!******************************************************************************************!*\
  !*** ./src/app/pages/coexpan/logistica/control-productos/control-productos.component.ts ***!
  \******************************************************************************************/
/*! exports provided: ControlProductosComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ControlProductosComponent", function() { return ControlProductosComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");


let ControlProductosComponent = class ControlProductosComponent {
    constructor() { }
    ngOnInit() { }
};
ControlProductosComponent.ctorParameters = () => [];
ControlProductosComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-controlproductos',
        template: `<ion-router-outlet></ion-router-outlet>`,
    })
], ControlProductosComponent);



/***/ }),

/***/ "FGgn":
/*!*********************************************************************************************************!*\
  !*** ./src/app/pages/coexpan/logistica/control-productos/bodega-renca/br-egreso/br-egreso.component.ts ***!
  \*********************************************************************************************************/
/*! exports provided: BrEgresoComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BrEgresoComponent", function() { return BrEgresoComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_br_egreso_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./br-egreso.component.html */ "5aaO");
/* harmony import */ var _br_egreso_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./br-egreso.component.scss */ "XpJV");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _providers_web_services_cxp_cxp_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../../../../providers/web-services/cxp/cxp.service */ "4gYv");
/* harmony import */ var _models_Registros_model__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../../../../models/Registros.model */ "JUB7");







let BrEgresoComponent = class BrEgresoComponent {
    constructor(cxpService, alertCtrl, loadingCtrl) {
        this.cxpService = cxpService;
        this.alertCtrl = alertCtrl;
        this.loadingCtrl = loadingCtrl;
        this.isLoading = false;
    }
    ngOnInit() { }
    ngAfterViewInit() {
        this.htmlEnviar.disabled = true;
        this.htmlCodigos.setFocus();
    }
    revisarTexto(str) {
        if (str.length === 0) {
            this.htmlEnviar.disabled = true;
        }
        else {
            this.htmlEnviar.disabled = false;
        }
    }
    enviarCodigos(codigos) {
        this.present();
        this.htmlEnviar.disabled = true;
        const registro = new _models_Registros_model__WEBPACK_IMPORTED_MODULE_6__["RegistrosModel"]();
        let mensaje;
        let exi = 0;
        let err = 0;
        registro.FechaScan = this.ObtenerFecha();
        registro.IdUsuario = 1;
        // console.log(this.htmlCodigos.value);
        const arrayCadena = this.transformarArreglo(codigos);
        registro.CodBarras = arrayCadena;
        // console.log(registro.CodBarras);
        if (registro.CodBarras.length === 0) {
            this.presentAlert('Error', 'Debe Escanear para poder enviar los códigos. ', '');
            this.dismiss();
            this.htmlCodigos.value = '';
        }
        else {
            console.log(registro.CodBarras);
            this.cxpService.cxpBrEnviarEgreso(registro).then((res) => {
                mensaje = JSON.parse(res.toString());
                console.log(mensaje);
                mensaje.EstadoCodigos.forEach(status => {
                    switch (status.ESTADO) {
                        case 'T':
                            exi += 1;
                            break;
                        case 'F':
                            err += 1;
                            break;
                        default: break;
                    }
                });
                this.dismiss();
                this.presentAlert('Estado de Ingreso', `<strong>Correctos: ${exi} bob.<br></strong><br>
          <strong>Error: ${err} bob.<br></strong>`, ``);
            }, (error) => {
                console.log(error);
                this.dismiss();
            });
            this.htmlCodigos.value = '';
            this.htmlCodigos.setFocus();
        }
    }
    //#region Herramientas
    transformarArreglo(codigos) {
        const arrayCadena = codigos.trim().split(' ');
        const arrayCadenaClean = arrayCadena.filter(Boolean);
        const arrayClean = [...new Set(arrayCadenaClean)];
        return arrayClean;
    }
    presentAlert(cab, cuerpo, subcab) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                cssClass: 'loading',
                header: cab,
                subHeader: subcab,
                message: cuerpo,
                buttons: [
                    {
                        text: 'OK',
                        handler: () => {
                            this.htmlCodigos.setFocus();
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    presentAlertConfirm(codigos) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                cssClass: 'loading',
                header: 'Confirmar Envío',
                message: 'Desea enviar los <strong>Códigos de Bobinas</strong> ?',
                buttons: [
                    {
                        text: 'Cancelar',
                        role: 'cancel',
                        handler: () => {
                            console.log('no se envio');
                        }
                    }, {
                        text: 'Ok',
                        handler: () => {
                            this.enviarCodigos(codigos);
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    present() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.isLoading = true;
            return yield this.loadingCtrl.create({
                cssClass: 'loading',
                message: 'Enviando...',
            }).then(a => {
                a.present().then(() => {
                    // console.log('presented');
                    if (!this.isLoading) {
                        a.dismiss();
                    }
                });
            });
        });
    }
    dismiss() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.isLoading = false;
            return yield this.loadingCtrl.dismiss().then(() => console.log('dismissed'));
        });
    }
    ObtenerFecha() {
        const fechaDate = new Date();
        let fechaString = '';
        const anio = fechaDate.getFullYear();
        let dia = '';
        let mes = '';
        let hora = '';
        let minuto = '';
        let segundo = '';
        if (fechaDate.getDate() < 10) {
            dia = `0${fechaDate.getDate()}`;
        }
        else {
            dia = fechaDate.getDate().toString();
        }
        if (fechaDate.getMonth() < 9) {
            mes = `0${fechaDate.getMonth() + 1}`;
        }
        else {
            mes = (fechaDate.getMonth() + 1).toString();
        }
        if (fechaDate.getHours() < 10) {
            hora = `0${fechaDate.getHours()}`;
        }
        else {
            hora = fechaDate.getHours().toString();
        }
        if (fechaDate.getMinutes() < 10) {
            minuto = `0${fechaDate.getMinutes()}`;
        }
        else {
            minuto = fechaDate.getMinutes().toString();
        }
        if (fechaDate.getSeconds() < 10) {
            segundo = `0${fechaDate.getSeconds()}`;
        }
        else {
            segundo = fechaDate.getSeconds().toString();
        }
        fechaString = `${anio}${mes}${dia} ${hora}:${minuto}:${segundo}`;
        return fechaString;
    }
};
BrEgresoComponent.ctorParameters = () => [
    { type: _providers_web_services_cxp_cxp_service__WEBPACK_IMPORTED_MODULE_5__["CxpService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"] }
];
BrEgresoComponent.propDecorators = {
    htmlCodigos: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"], args: ['codigos',] }],
    htmlEnviar: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"], args: ['btnenviar',] }]
};
BrEgresoComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-br-egreso',
        template: _raw_loader_br_egreso_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_br_egreso_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], BrEgresoComponent);



/***/ }),

/***/ "POYj":
/*!*************************************************************************************************************!*\
  !*** ./src/app/pages/coexpan/logistica/control-productos/bodega-renca/menu-renca/menu-renca.component.scss ***!
  \*************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-header .toolbar {\n  --background: rgb(7, 33, 230, 0.5);\n}\nion-header .toolbar ion-title {\n  font-size: 25px;\n  --color: rgb(210, 218, 248);\n  text-shadow: 2px 2px 2px #06158c;\n  letter-spacing: 2px;\n}\nion-content .ion-grid-1 {\n  height: 100%;\n}\nion-content .ion-grid-1 .ion-row-1 {\n  height: 100%;\n}\nion-content .ion-grid-1 .ion-row-1 ion-button {\n  --opacity: 0.9;\n}\nion-button.btn-renca {\n  --opacity: 0.900;\n}\n/*Figuras*/\n.tri_inf_izq {\n  position: absolute;\n  width: 100%;\n  height: 0%;\n  border-top: 50px solid transparent;\n  border-right: 410px solid rgba(6, 4, 128, 0.7);\n  border-bottom: 0px solid transparent;\n}\n.tri_inf_der {\n  position: relative;\n  width: 100%;\n  height: 0%;\n  border-top: 50px solid transparent;\n  border-left: 410px solid rgba(7, 33, 230, 0.508);\n  border-bottom: 0px solid transparent;\n}\nion-content {\n  --ion-background-color: none;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcbWVudS1yZW5jYS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDRTtFQUNFLGtDQUFBO0FBQUo7QUFDSTtFQUNFLGVBQUE7RUFDQSwyQkFBQTtFQUNBLGdDQUFBO0VBQ0EsbUJBQUE7QUFDTjtBQUtFO0VBQ0UsWUFBQTtBQUZKO0FBR0k7RUFDRSxZQUFBO0FBRE47QUFFTTtFQUNFLGNBQUE7QUFBUjtBQU1BO0VBQ0UsZ0JBQUE7QUFIRjtBQVVBLFVBQUE7QUFDQTtFQUNFLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFVBQUE7RUFDQSxrQ0FBQTtFQUNBLDhDQUFBO0VBQ0Esb0NBQUE7QUFQRjtBQVVBO0VBQ0Usa0JBQUE7RUFDQSxXQUFBO0VBQ0EsVUFBQTtFQUNBLGtDQUFBO0VBQ0EsZ0RBQUE7RUFDQSxvQ0FBQTtBQVBGO0FBVUE7RUFDRSw0QkFBQTtBQVBGIiwiZmlsZSI6Im1lbnUtcmVuY2EuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taGVhZGVyIHtcclxuICAudG9vbGJhciB7XHJcbiAgICAtLWJhY2tncm91bmQ6IHJnYig3LCAzMywgMjMwLCAwLjUpO1xyXG4gICAgaW9uLXRpdGxlIHtcclxuICAgICAgZm9udC1zaXplOiAyNXB4O1xyXG4gICAgICAtLWNvbG9yOiByZ2IoMjEwLCAyMTgsIDI0OCk7XHJcbiAgICAgIHRleHQtc2hhZG93OiAycHggMnB4IDJweCByZ2IoNiwgMjEsIDE0MCk7XHJcbiAgICAgIGxldHRlci1zcGFjaW5nOiAycHg7XHJcbiAgICB9XHJcbiAgfVxyXG59XHJcblxyXG5pb24tY29udGVudCB7XHJcbiAgLmlvbi1ncmlkLTEge1xyXG4gICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgLmlvbi1yb3ctMSB7XHJcbiAgICAgIGhlaWdodDogMTAwJTtcclxuICAgICAgaW9uLWJ1dHRvbiB7XHJcbiAgICAgICAgLS1vcGFjaXR5OiAwLjk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcbn1cclxuXHJcbmlvbi1idXR0b24uYnRuLXJlbmNhIHtcclxuICAtLW9wYWNpdHk6IDAuOTAwO1xyXG59XHJcbi5mdWxsLWhlaWdodCB7XHJcblxyXG59XHJcblxyXG5cclxuLypGaWd1cmFzKi9cclxuLnRyaV9pbmZfaXpxIHtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgaGVpZ2h0OiAwJTtcclxuICBib3JkZXItdG9wOiA1MHB4IHNvbGlkIHRyYW5zcGFyZW50O1xyXG4gIGJvcmRlci1yaWdodDogNDEwcHggc29saWQgcmdiYSg2LCA0LCAxMjgsIDAuNyk7XHJcbiAgYm9yZGVyLWJvdHRvbTogMHB4IHNvbGlkIHRyYW5zcGFyZW50O1xyXG59XHJcblxyXG4udHJpX2luZl9kZXIge1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICB3aWR0aDogMTAwJTtcclxuICBoZWlnaHQ6IDAlO1xyXG4gIGJvcmRlci10b3A6IDUwcHggc29saWQgdHJhbnNwYXJlbnQ7XHJcbiAgYm9yZGVyLWxlZnQ6IDQxMHB4IHNvbGlkIHJnYmEoNywgMzMsIDIzMCwgMC41MDgpO1xyXG4gIGJvcmRlci1ib3R0b206IDBweCBzb2xpZCB0cmFuc3BhcmVudDtcclxufVxyXG5cclxuaW9uLWNvbnRlbnQge1xyXG4gIC0taW9uLWJhY2tncm91bmQtY29sb3I6IG5vbmU7XHJcbn1cclxuIl19 */");

/***/ }),

/***/ "Qhgg":
/*!********************************************************************************************************************************!*\
  !*** ./src/app/pages/coexpan/logistica/control-productos/bodega-planta/bp-entrada-mercancia/bp-entrada-mercancia.component.ts ***!
  \********************************************************************************************************************************/
/*! exports provided: BpEntradaMercanciaComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BpEntradaMercanciaComponent", function() { return BpEntradaMercanciaComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_bp_entrada_mercancia_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./bp-entrada-mercancia.component.html */ "BuxF");
/* harmony import */ var _bp_entrada_mercancia_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./bp-entrada-mercancia.component.scss */ "cBXM");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _providers_web_services_cxp_cxp_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../../../../providers/web-services/cxp/cxp.service */ "4gYv");
/* harmony import */ var _models_Registros_model__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../../../../models/Registros.model */ "JUB7");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _models_bodega_recepcion_model__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../../../models/bodega-recepcion.model */ "puES");









let BpEntradaMercanciaComponent = class BpEntradaMercanciaComponent {
    constructor(alertCtrl, loadingCtrl, toastController, cxpService, routes) {
        this.alertCtrl = alertCtrl;
        this.loadingCtrl = loadingCtrl;
        this.toastController = toastController;
        this.cxpService = cxpService;
        this.routes = routes;
        //#region VARIABLES
        this.pallets = [];
        this.isLoading = false;
        //#endregion VIEWCHILD
        //#region MODEL HTML
        this.txtarea = {
            spinner: false,
        };
    }
    //#endregion MODEL HTML
    ngOnInit() { }
    ngAfterViewInit() {
        this.btnEnviar.disabled = true;
        setTimeout(() => {
            this.txtCodigos.setFocus();
        }, 100);
    }
    textoCodigos(valor) {
        this.codigos = valor;
        if (this.codigos.length === 0) {
            this.btnEnviar.disabled = true;
        }
        else {
            this.btnEnviar.disabled = false;
        }
        console.log(this.codigos);
    }
    obtenerDatosPallet(codbarramulti) {
        //#region VARIABLES
        const cbm = codbarramulti.trim();
        if (cbm.length <= 0) {
            this.messageToast('Escanée un Código de Pallet');
            return;
        }
        this.txtCodigos.disabled = true;
        this.txtCodigos.value = '';
        this.txtarea.spinner = true;
        console.log(cbm);
        let request;
        //#endregion VARIABLES
        this.cxpService.cxpLogisticaGetPalletBobinas(cbm).then(datos => {
            request = JSON.parse(datos.toString());
            this.txtarea.spinner = false;
            console.log(request);
            if (request.Status.STATUS === 'T') {
                if (this.palletRepetido(request.Objeto.Pallet.CODBAR_MULTI)) {
                    this.messageToast('El Pallet ya se encuentra en la lista.');
                }
                else {
                    this.pallets.push(request.Objeto);
                }
            }
            else {
                if (request.Objeto.Pallet) {
                    this.AlertaReimprimirEtiqueta(request);
                }
                else {
                    this.messageToast(request.Status.MESSAGE);
                }
            }
            this.txtCodigos.disabled = false;
            setTimeout(() => {
                this.txtCodigos.setFocus();
            }, 100);
            this.existenitems();
        }, (err) => {
            console.log(err);
        });
    }
    eliminarItem(nropallet) {
        for (let i = 0; i < this.pallets.length; i++) {
            if (this.pallets[i].Pallet.CODBAR_MULTI === nropallet) {
                this.pallets.splice(i, 1);
                this.messageToast(`Pallet ${nropallet} Quitado de la lista.`);
                this.existenitems();
            }
        }
        console.log(`Pallet Eliminado: ${nropallet}`);
    }
    palletRepetido(nropallets) {
        let existe = false;
        this.pallets.forEach(pt => {
            if (pt.Pallet.CODBAR_MULTI === nropallets) {
                existe = true;
            }
        });
        return existe;
    }
    enviarEntradaMercancia() {
        const usersap = JSON.parse(localStorage.getItem('usersap'));
        const postsap = new _models_Registros_model__WEBPACK_IMPORTED_MODULE_6__["SapPostModel"]();
        postsap.usuario = usersap.User;
        postsap.token = usersap.Token;
        postsap.objeto = this.pallets;
        let palletExito = 0;
        let palletError = 0;
        this.showLoading();
        this.cxpService.cxpLogisticaenviarEntradaMercancia(postsap).then((data) => {
            this.dismissLoading();
            let status = new _models_Registros_model__WEBPACK_IMPORTED_MODULE_6__["GetRequestModel"]();
            status = JSON.parse(data.toString());
            if (status.Status.STATUS === 'T') {
                status.Objeto.forEach(pallet => {
                    if (pallet.Estado === 'T') {
                        palletExito += 1;
                    }
                    else {
                        palletError += 1;
                    }
                });
                //
                this.eliminarPalletConProblemas(this.pallets, status);
                //
                if (palletError > 0) {
                    this.messageToast('Error al registrar estos Pallet. ');
                }
                else {
                    this.messageToast('Pallet(s) registrado(s) en SAP Business One con éxito. ');
                    this.pallets = [];
                }
            }
            else {
                // this.messageToast('sesión expirada, vuelva a iniciar sesión. ');
                if (status.Objeto[0].SapMensaje) {
                    this.messageToast(status.Objeto[0].SapMensaje);
                }
                else {
                    this.messageToast(status.Status.MESSAGE);
                }
                // localStorage.removeItem('usersap');
                // this.routes.navigateByUrl('pages/login');
            }
            this.existenitems();
            console.log(data);
        }, (err) => {
            this.existenitems();
            this.dismissLoading();
            this.messageToast(err);
        });
    }
    //#region Informacion Pallet
    infoItem(nropallet) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            let pallet = new _models_Registros_model__WEBPACK_IMPORTED_MODULE_6__["PalletBobinasModel"]();
            pallet = this.obtenerPallet(nropallet);
            const str = this.generarListaBobinas(pallet);
            const alert = yield this.alertCtrl.create({
                cssClass: 'alert-palletybobinas',
                header: `DETALLE PALLET ${nropallet}`,
                message: str,
                buttons: ['OK']
            });
            yield alert.present();
        });
    }
    obtenerPallet(nroPallet) {
        let rtnPallet = new _models_Registros_model__WEBPACK_IMPORTED_MODULE_6__["PalletBobinasModel"]();
        this.pallets.forEach(pallet => {
            if (pallet.Pallet.CODBAR_MULTI === nroPallet) {
                rtnPallet = pallet;
            }
        });
        return rtnPallet;
    }
    generarListaBobinas(pallet) {
        //#region HTML
        let str = `
    <ion-list>
          <ion-item>
            <ion-label>OF - ${pallet.Pallet.ORDEN_FAB.substr(5, 20)}</ion-label>
          </ion-item>
          <ion-item>
            <ion-label>CLIENTE - ${pallet.Pallet.CLIENTE}</ion-label>
          </ion-item>
          <ion-item>
            <ion-label>PALLET ${pallet.Pallet.CORRELATIVO}</ion-label>
          </ion-item>
          <ion-item>
            <ion-label>KG BRUTO - ${pallet.Pallet.PESO_BRUTO}</ion-label>
          </ion-item>
          <ion-item>
            <ion-label>KG NETO ${pallet.Pallet.PESO_NETO}</ion-label>
          </ion-item>
        </ion-list>
        <br>
        <div><ion-label>Bobina(s)</ion-label></div></br>`;
        //#endregion HTML
        pallet.Bobinas.forEach(bob => {
            const strconst = `
      <ion-label>N° Bobina ${bob.CODBAR_BOB}</ion-label>
      <ul>
        <li>Producto: - ${bob.NOM_PRODUCTO}</li>
        <li>Medidas - ${bob.MEDIDAS}</li>
        <li>Kg Bruto - ${bob.PESO_BRUTO}</li>
        <li>Kg Neto - ${bob.PESO_NETO}</li>
        <li>Valor Resina - $${bob.PRECIO_RESINA}</li>
        <li>Valor Total - $${bob.VALOR_TOTAL}</li>
      </ul>
        </br>`;
            str += strconst;
        });
        return str;
    }
    //#endregion Informacion Pallet
    // TODO INTEGRACION 28-07-2021 Emisión Etiqueta Recepcion
    AlertaReimprimirEtiqueta(mod) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                header: 'SAP Business One.',
                message: 'El Pallet ya se encuentra cargado en el sistema, desea reimprimir?',
                buttons: [
                    {
                        text: 'Cancelar',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: (blah) => {
                            // console.log();
                        }
                    }, {
                        text: 'Continuar',
                        handler: () => {
                            this.reemprimirEtiquetaRecepcion(mod);
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    reemprimirEtiquetaRecepcion(mod) {
        const prm = new _models_Registros_model__WEBPACK_IMPORTED_MODULE_6__["PalletRecepcionModel"]();
        console.log(prm);
        const pallet = new _models_bodega_recepcion_model__WEBPACK_IMPORTED_MODULE_8__["PalletBodegaRecepcionModel"]();
        pallet.modelData = new _models_bodega_recepcion_model__WEBPACK_IMPORTED_MODULE_8__["ModelData"]();
        pallet.ipAddress = localStorage.getItem('ipimp');
        pallet.modelData.fecha = mod.Objeto.Pallet.FECHA;
        pallet.modelData.hora = mod.Objeto.Pallet.HORA.substring(0, 5).replace(':', '');
        pallet.modelData.descrProducto = mod.Objeto.Pallet.NOM_PRODUCTO;
        pallet.modelData.codProducto = mod.Objeto.Pallet.COD_PRODUCTO;
        pallet.modelData.ordenFab = mod.Objeto.Pallet.ORDEN_FAB;
        pallet.modelData.cliente = mod.Objeto.Pallet.CLIENTE;
        pallet.modelData.medidas = mod.Objeto.Pallet.MEDIDAS;
        pallet.modelData.cantBobina = mod.Objeto.Pallet.CANT_BOB;
        pallet.modelData.corrPallet = mod.Objeto.Pallet.CORRELATIVO;
        pallet.modelData.pesoBruto = mod.Objeto.Pallet.PESO_BRUTO.replace(',', '.');
        pallet.modelData.pesoNeto = mod.Objeto.Pallet.PESO_NETO.replace(',', '.');
        if (prm.ipImpresora !== null || prm.ipImpresora !== '') {
            this.cxpService.cxpReimprimirEtiquetaRecepcion(pallet).then((data) => {
                console.log(JSON.parse(data));
                const resp = JSON.parse(data);
                if (resp.Status === 'T') {
                    this.messageToast(resp.Message);
                }
                else {
                    this.messageToast(resp.Message_Exception);
                }
            }, (err) => {
                this.messageToast('Problemas en el servicio. ');
                console.log(err);
            });
        }
        else {
            this.messageToast('Seleccione una impresora para continuar. ');
        }
    }
    eliminarPalletConProblemas(pallet, rq) {
        const newpl = [];
        pallet.forEach(pl => {
            rq.Objeto.forEach(rqpallet => {
                if (pl.Pallet.CODBAR_MULTI === rqpallet.CodBarra && rqpallet.Estado === 'T') {
                    let pet = new _models_Registros_model__WEBPACK_IMPORTED_MODULE_6__["PalletRecepcionModel"]();
                    pet.codProducto = pl.Pallet.COD_PRODUCTO;
                    pet.descProducto = pl.Pallet.NOM_PRODUCTO;
                    pet.ordenFab = pl.Pallet.ORDEN_FAB;
                    pet.cliente = pl.Pallet.CLIENTE;
                    pet.medidas = pl.Pallet.MEDIDAS;
                    pet.cantBobinas = Number(pl.Pallet.CANT_BOB);
                    pet.corrPallet = Number(pl.Pallet.CORRELATIVO);
                    pet.pesoBruto = Number(pl.Pallet.PESO_BRUTO.replace(',', '.'));
                    pet.pesoNeto = Number(pl.Pallet.PESO_NETO.replace(',', '.'));
                    pet.idEtqMulti = pl.Pallet.CODBAR_MULTI;
                    pet.ipImpresora = localStorage.getItem('ipimp');
                    console.log(pet);
                    newpl.push(pet);
                    pet = null;
                }
            });
        });
        this.imprimirEtiquetasRecepcion(newpl);
    }
    imprimirEtiquetasRecepcion(pallets) {
        console.log('Paso por metodo');
        const ipImpresora = localStorage.getItem('ipimp');
        let cantimp = 0;
        if (ipImpresora !== null || ipImpresora !== '') {
            pallets.forEach(pl => {
                const pallet = new _models_bodega_recepcion_model__WEBPACK_IMPORTED_MODULE_8__["PalletBodegaRecepcionModel"]();
                pallet.modelData = new _models_bodega_recepcion_model__WEBPACK_IMPORTED_MODULE_8__["ModelData"]();
                const date = new Date().toISOString().toString();
                pallet.ipAddress = pl.ipImpresora;
                pallet.modelData.fecha = date.split('T')[0];
                pallet.modelData.hora = date.split('T')[1].substring(0, 5).replace(':', '');
                pallet.modelData.descrProducto = pl.descProducto;
                pallet.modelData.codProducto = pl.codProducto;
                pallet.modelData.ordenFab = pl.ordenFab;
                pallet.modelData.cliente = pl.cliente;
                pallet.modelData.medidas = pl.medidas;
                pallet.modelData.cantBobina = pl.cantBobinas.toString();
                pallet.modelData.corrPallet = pl.corrPallet.toString();
                pallet.modelData.pesoBruto = pl.pesoBruto.toString().replace(',', '.');
                pallet.modelData.pesoNeto = pl.pesoNeto.toString().replace(',', '.');
                this.cxpService.cxpReimprimirEtiquetaRecepcion(pallet).then((pallet) => {
                    cantimp++;
                }, (err => {
                    console.log(err);
                }));
            });
            this.messageToast('Etiquetas Enviadas: ' + cantimp);
        }
        else {
            this.messageToast('Seleccione una impresora para continuar. ');
        }
    }
    //#region HERRAMIENTAS
    existenitems() {
        if (this.pallets.length > 0) {
            this.btnEnviar.disabled = false;
            return true;
        }
        else {
            this.btnEnviar.disabled = true;
            return false;
        }
    }
    showLoading() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.isLoading = true;
            return yield this.loadingCtrl.create({
                cssClass: 'loading',
                message: 'Enviando...',
            }).then(a => {
                a.present().then(() => {
                    // console.log('presented');
                    if (!this.isLoading) {
                        a.dismiss();
                    }
                });
            });
        });
    }
    dismissLoading() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.isLoading = false;
            return yield this.loadingCtrl.dismiss().then(() => console.log('dismissed'));
        });
    }
    messageToast(msj) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const toast = yield this.toastController.create({
                message: msj,
                duration: 5000
            });
            toast.present();
        });
    }
    obtenerFecha() {
        const fechaDate = new Date();
        let fechaString = '';
        const anio = fechaDate.getFullYear();
        let dia = '';
        let mes = '';
        let hora = '';
        let minuto = '';
        let segundo = '';
        if (fechaDate.getDate() < 10) {
            dia = `0${fechaDate.getDate()}`;
        }
        else {
            dia = fechaDate.getDate().toString();
        }
        if (fechaDate.getMonth() < 10) {
            mes = `0${fechaDate.getMonth() + 1}`;
        }
        else {
            mes = (fechaDate.getMonth() + 1).toString();
        }
        if (fechaDate.getHours() < 10) {
            hora = `0${fechaDate.getHours()}`;
        }
        else {
            hora = fechaDate.getHours().toString();
        }
        if (fechaDate.getMinutes() < 10) {
            minuto = `0${fechaDate.getMinutes()}`;
        }
        else {
            minuto = fechaDate.getMinutes().toString();
        }
        if (fechaDate.getSeconds() < 10) {
            segundo = `0${fechaDate.getSeconds()}`;
        }
        else {
            segundo = fechaDate.getSeconds().toString();
        }
        fechaString = `${anio}${mes}${dia} ${hora}:${minuto}:${segundo}`;
        return fechaString;
    }
    transformarArreglo(codigos) {
        const arrayCadena = codigos.trim().split(' ');
        const arrayCadenaClean = arrayCadena.filter(Boolean);
        const arrayClean = [...new Set(arrayCadenaClean)];
        return arrayClean;
    }
    removerPallet(codpallet) {
        for (let i = 0; i < this.pallets.length; i++) {
            if (this.pallets[i].Pallet.CODBAR_MULTI === codpallet) {
                this.pallets.splice(i, 1);
                this.existenitems();
            }
        }
    }
    AlertaEnviarEntradaSap() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                cssClass: 'my-custom-class',
                header: 'SAP Business One.',
                message: 'Enviar <strong>Entrada(s) de Mercancia(s)</strong>?',
                buttons: [
                    {
                        text: 'Cancelar',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: (blah) => {
                            // console.log('Confirm Cancel: blah');
                        }
                    }, {
                        text: 'Continuar',
                        handler: () => {
                            this.enviarEntradaMercancia();
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
};
BpEntradaMercanciaComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ToastController"] },
    { type: _providers_web_services_cxp_cxp_service__WEBPACK_IMPORTED_MODULE_5__["CxpService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__["Router"] }
];
BpEntradaMercanciaComponent.propDecorators = {
    btnEnviar: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"], args: ['btnEnviar',] }],
    txtCodigos: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"], args: ['codigos',] }]
};
BpEntradaMercanciaComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-bp-entrada-mercancia',
        template: _raw_loader_bp_entrada_mercancia_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_bp_entrada_mercancia_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], BpEntradaMercanciaComponent);



/***/ }),

/***/ "TChH":
/*!********************************************************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/coexpan/logistica/control-productos/bodega-planta/bp-etq-entrada-mercancia/bp-etq-entrada-mercancia.component.html ***!
  \********************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar class=\"toolbar\">\n    <ion-title>Etiqueta Entrada de Mercancía</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-refresher slot=\"fixed\"\n    (ionRefresh)=\"cargarEtlPesaje($event)\">\n    <ion-refresher-content></ion-refresher-content>\n  </ion-refresher>\n\n  <ion-grid fixed>\n    <ion-row class=\"ion-row-1 ion-justify-content-center\">\n      <ion-col size=\"12\">\n        <ion-item class=\"ion-item-1\">\n          <ion-textarea #codigos rows=\"13\"\n            placeholder=\"Escanea las bobinas para ingresar...\"\n            (keyup)=\"textoCodigos(codigos.value)\"\n            (keyup.enter)=\"revisionCodigos()\">\n          </ion-textarea>\n        </ion-item>\n      </ion-col>\n    </ion-row>\ns\n    <ion-row class=\"ion-row-2 ion-justify-content-center\">\n        <ion-col size=\"12\" class=\"ion-padding\">\n          <ion-button #btnEnviar size=\"large\" expand=\"block\" class=\"btn-1\"\n            (click)=\"revisionCodigos()\">\n            Enviar\n          </ion-button>\n        </ion-col>\n      </ion-row>\n  </ion-grid>\n</ion-content>\n");

/***/ }),

/***/ "UREj":
/*!****************************************************************************************************!*\
  !*** ./src/app/pages/coexpan/logistica/control-productos/page-bodegas/page-bodegas.component.scss ***!
  \****************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("/**/\n.full-height {\n  height: 100%;\n}\n/*Figuras*/\n.tri_sup_izq {\n  position: absolute;\n  width: 100%;\n  height: 0%;\n  border-top: 0px solid transparent;\n  border-right: 480px solid rgba(6, 4, 128, 0.7);\n  border-bottom: 50px solid transparent;\n}\n.tri_sup_der {\n  position: relative;\n  width: 100%;\n  height: 0%;\n  border-top: 0px solid transparent;\n  border-left: 480px solid rgba(7, 33, 230, 0.508);\n  border-bottom: 50px solid transparent;\n}\n.tri_inf_izq {\n  position: absolute;\n  width: 100%;\n  height: 0%;\n  border-top: 50px solid transparent;\n  border-right: 410px solid rgba(6, 4, 128, 0.7);\n  border-bottom: 0px solid transparent;\n}\n.tri_inf_der {\n  position: relative;\n  width: 100%;\n  height: 0%;\n  border-top: 50px solid transparent;\n  border-left: 410px solid rgba(7, 33, 230, 0.508);\n  border-bottom: 0px solid transparent;\n}\nion-content {\n  --ion-background-color: none;\n}\nion-button.btn-renca {\n  --opacity: 0.9;\n}\nion-button.btn-central {\n  --background: rgba(186, 96, 12, 0.900);\n  --color: rgb(255, 255, 255);\n}\nion-header ion-toolbar {\n  --background: none;\n}\nion-header ion-toolbar ion-title {\n  position: absolute;\n}\nion-header ion-toolbar ion-button {\n  margin-left: 15px;\n  position: absolute !important;\n  z-index: 100;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFxwYWdlLWJvZGVnYXMuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsR0FBQTtBQUNBO0VBQ0UsWUFBQTtBQUNGO0FBRUEsVUFBQTtBQUNBO0VBQ0Usa0JBQUE7RUFDQSxXQUFBO0VBQ0EsVUFBQTtFQUNBLGlDQUFBO0VBQ0EsOENBQUE7RUFDQSxxQ0FBQTtBQUNGO0FBRUE7RUFDRSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxVQUFBO0VBQ0EsaUNBQUE7RUFDQSxnREFBQTtFQUNBLHFDQUFBO0FBQ0Y7QUFFQTtFQUNFLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFVBQUE7RUFDQSxrQ0FBQTtFQUNBLDhDQUFBO0VBQ0Esb0NBQUE7QUFDRjtBQUVBO0VBQ0Usa0JBQUE7RUFDQSxXQUFBO0VBQ0EsVUFBQTtFQUNBLGtDQUFBO0VBQ0EsZ0RBQUE7RUFDQSxvQ0FBQTtBQUNGO0FBRUE7RUFDRSw0QkFBQTtBQUNGO0FBRUE7RUFDRSxjQUFBO0FBQ0Y7QUFFQTtFQUNFLHNDQUFBO0VBQ0EsMkJBQUE7QUFDRjtBQUlFO0VBQ0Usa0JBQUE7QUFESjtBQUVJO0VBQ0Usa0JBQUE7QUFBTjtBQUVJO0VBQ0UsaUJBQUE7RUFDQSw2QkFBQTtFQUNBLFlBQUE7QUFBTiIsImZpbGUiOiJwYWdlLWJvZGVnYXMuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIvKiovXHJcbi5mdWxsLWhlaWdodCB7XHJcbiAgaGVpZ2h0OiAxMDAlO1xyXG59XHJcblxyXG4vKkZpZ3VyYXMqL1xyXG4udHJpX3N1cF9penEge1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICB3aWR0aDogMTAwJTtcclxuICBoZWlnaHQ6IDAlO1xyXG4gIGJvcmRlci10b3A6IDBweCBzb2xpZCB0cmFuc3BhcmVudDtcclxuICBib3JkZXItcmlnaHQ6IDQ4MHB4IHNvbGlkIHJnYmEoNiwgNCwgMTI4LCAwLjcpO1xyXG4gIGJvcmRlci1ib3R0b206IDUwcHggc29saWQgdHJhbnNwYXJlbnQ7XHJcbn1cclxuXHJcbi50cmlfc3VwX2RlciB7XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGhlaWdodDogMCU7XHJcbiAgYm9yZGVyLXRvcDogMHB4IHNvbGlkIHRyYW5zcGFyZW50O1xyXG4gIGJvcmRlci1sZWZ0OiA0ODBweCBzb2xpZCByZ2JhKDcsIDMzLCAyMzAsIDAuNTA4KTtcclxuICBib3JkZXItYm90dG9tOiA1MHB4IHNvbGlkIHRyYW5zcGFyZW50O1xyXG59XHJcblxyXG4udHJpX2luZl9penEge1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICB3aWR0aDogMTAwJTtcclxuICBoZWlnaHQ6IDAlO1xyXG4gIGJvcmRlci10b3A6IDUwcHggc29saWQgdHJhbnNwYXJlbnQ7XHJcbiAgYm9yZGVyLXJpZ2h0OiA0MTBweCBzb2xpZCByZ2JhKDYsIDQsIDEyOCwgMC43KTtcclxuICBib3JkZXItYm90dG9tOiAwcHggc29saWQgdHJhbnNwYXJlbnQ7XHJcbn1cclxuXHJcbi50cmlfaW5mX2RlciB7XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGhlaWdodDogMCU7XHJcbiAgYm9yZGVyLXRvcDogNTBweCBzb2xpZCB0cmFuc3BhcmVudDtcclxuICBib3JkZXItbGVmdDogNDEwcHggc29saWQgcmdiYSg3LCAzMywgMjMwLCAwLjUwOCk7XHJcbiAgYm9yZGVyLWJvdHRvbTogMHB4IHNvbGlkIHRyYW5zcGFyZW50O1xyXG59XHJcblxyXG5pb24tY29udGVudCB7XHJcbiAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjogbm9uZTtcclxufVxyXG5cclxuaW9uLWJ1dHRvbi5idG4tcmVuY2Ege1xyXG4gIC0tb3BhY2l0eTogMC45O1xyXG59XHJcblxyXG5pb24tYnV0dG9uLmJ0bi1jZW50cmFsIHtcclxuICAtLWJhY2tncm91bmQ6IHJnYmEoMTg2LCA5NiwgMTIsIDAuOTAwKTtcclxuICAtLWNvbG9yOiByZ2IoMjU1LCAyNTUsIDI1NSk7XHJcbn1cclxuXHJcblxyXG5pb24taGVhZGVyIHtcclxuICBpb24tdG9vbGJhciB7XHJcbiAgICAtLWJhY2tncm91bmQ6IG5vbmU7XHJcbiAgICBpb24tdGl0bGUge1xyXG4gICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB9XHJcbiAgICBpb24tYnV0dG9uIHtcclxuICAgICAgbWFyZ2luLWxlZnQ6IDE1cHg7XHJcbiAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZSAhaW1wb3J0YW50O1xyXG4gICAgICB6LWluZGV4OiAxMDA7XHJcbiAgICB9XHJcbiAgfVxyXG59XHJcbiJdfQ== */");

/***/ }),

/***/ "WsvI":
/*!***************************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/coexpan/logistica/control-productos/bodega-renca/br-ingreso/br-ingreso.component.html ***!
  \***************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar class=\"toolbar\">\n    <ion-title>Ingreso de Bobinas</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-grid fixed>\n    <ion-row class=\"ion-justify-content-center\">\n      <ion-col size=\"12\">\n        <ion-item class=\"ion-item-1\">\n          <ion-textarea #codigos rows=\"13\"\n          placeholder=\"Escanea las bobinas para ingresar...\"\n            (keyup)=\"revisarTexto(codigos.value)\"\n            (keyup.enter)=\"presentAlertConfirm(codigos.value)\">\n          </ion-textarea>\n        </ion-item>\n      </ion-col>\n    </ion-row>\n    <ion-row class=\"ion-row-2 ion-justify-content-center\">\n      <ion-col size=\"12\">\n          <ion-button size=\"large\" #btnenviar expand=\"block\" color=\"dark\"\n          (click)=\"presentAlertConfirm(codigos.value)\">\n            Enviar\n          </ion-button>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-content>\n\n");

/***/ }),

/***/ "Wyu7":
/*!******************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/coexpan/logistica/control-productos/page-bodegas/page-bodegas.component.html ***!
  \******************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n<ion-header class=\"ion-no-border\">\n  <ion-toolbar class=\"toolbar\">\n    <div class=\"tri_sup_izq\"> </div>\n    <div class=\"tri_sup_der\"></div>\n    <ion-title class=\"title ion-no-padding\"><strong>Bodega Planta</strong></ion-title>\n    <ion-button class=\"btn-sand\"\n      (click)=\"openMenu()\" slot=\"start\" fill=\"outline\" color=\"warning\">\n      <ion-icon color=\"dark\" name=\"menu\" color=\"warning\"></ion-icon>\n    </ion-button>\n  </ion-toolbar>\n</ion-header>\n\n\n<ion-content fixed>\n  <ion-grid fixed size=\"sx\" class=\"full-height\">\n    <ion-row class=\"full-height ion-align-items-center\">\n      <ion-col size=\"12\">\n        <ion-button color=\"tertiary btn-renca\" size=\"large\" expand=\"block\" (click)=\"pageMenuRenca()\">\n          Bodega Renca\n        </ion-button>\n      </ion-col>\n      <ion-col size=\"12\">\n        <ion-button class=\"btn-central\" size=\"large\" expand=\"block\" (click)=\"pageMenuPlanta()\">\n          Bodega Planta\n        </ion-button>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-content>\n\n<ion-footer class=\"ion-no-border\">\n  <div class=\"tri_inf_izq\"> </div>\n  <div class=\"tri_inf_der\"></div>\n</ion-footer>\n");

/***/ }),

/***/ "XpJV":
/*!***********************************************************************************************************!*\
  !*** ./src/app/pages/coexpan/logistica/control-productos/bodega-renca/br-egreso/br-egreso.component.scss ***!
  \***********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("@import url(\"https://fonts.googleapis.com/css2?family=Rubik:wght@600&display=swap\");\n*:not(ion-icon) {\n  font-family: \"Rubik\", sans-serif !important;\n}\nion-header .toolbar {\n  --background: rgba(4, 164, 250, 0.9);\n  --color: white;\n}\nion-content {\n  --ion-background-color: none;\n}\nion-content ion-grid .ion-item-1 {\n  background-color: #e8e9e9;\n  border-radius: 3%;\n}\nion-content ion-grid .ion-row-2 {\n  padding-top: 6px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcYnItZWdyZXNvLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFRLG1GQUFBO0FBRVI7RUFDRSwyQ0FBQTtBQUFGO0FBSUU7RUFDRSxvQ0FBQTtFQUNBLGNBQUE7QUFESjtBQUtBO0VBQ0UsNEJBQUE7QUFGRjtBQUlJO0VBQ0UseUJBQUE7RUFDQSxpQkFBQTtBQUZOO0FBSUk7RUFDRSxnQkFBQTtBQUZOIiwiZmlsZSI6ImJyLWVncmVzby5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIkBpbXBvcnQgdXJsKCdodHRwczovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2NzczI/ZmFtaWx5PVJ1YmlrOndnaHRANjAwJmRpc3BsYXk9c3dhcCcpO1xyXG5cclxuKjpub3QoaW9uLWljb24pIHtcclxuICBmb250LWZhbWlseTogJ1J1YmlrJywgc2Fucy1zZXJpZiFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbmlvbi1oZWFkZXIge1xyXG4gIC50b29sYmFyIHtcclxuICAgIC0tYmFja2dyb3VuZDogcmdiYSg0LCAxNjQsIDI1MCwgMC45KTtcclxuICAgIC0tY29sb3I6IHdoaXRlO1xyXG4gIH1cclxufVxyXG5cclxuaW9uLWNvbnRlbnR7XHJcbiAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjogbm9uZTtcclxuICBpb24tZ3JpZCB7XHJcbiAgICAuaW9uLWl0ZW0tMSB7XHJcbiAgICAgIGJhY2tncm91bmQtY29sb3I6IHJnYigyMzIsIDIzMywgMjMzKTtcclxuICAgICAgYm9yZGVyLXJhZGl1czogMyU7XHJcbiAgICB9XHJcbiAgICAuaW9uLXJvdy0yIHtcclxuICAgICAgcGFkZGluZy10b3A6IDZweDtcclxuICAgIH1cclxuICB9XHJcbn1cclxuIl19 */");

/***/ }),

/***/ "aSy8":
/*!****************************************************************************************************!*\
  !*** ./src/app/pages/coexpan/logistica/control-productos/page-control/page-control.component.scss ***!
  \****************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-grid {\n  height: 100%;\n}\n\nion-row {\n  height: 100%;\n}\n\n/*Figuras*/\n\n.tri_sup_izq {\n  position: absolute;\n  width: 100%;\n  height: 0%;\n  border-top: 0px solid transparent;\n  border-right: 480px solid rgba(230, 7, 7, 0.7);\n  border-bottom: 50px solid transparent;\n}\n\n.tri_sup_der {\n  width: 100%;\n  height: 0%;\n  border-top: 0px solid transparent;\n  border-left: 480px solid rgba(7, 33, 230, 0.508);\n  border-bottom: 50px solid transparent;\n}\n\n.tri_inf_izq {\n  position: absolute;\n  width: 100%;\n  height: 0%;\n  border-top: 50px solid transparent;\n  border-right: 410px solid rgba(230, 7, 7, 0.7);\n  border-bottom: 0px solid transparent;\n}\n\n.tri_inf_der {\n  position: relative;\n  width: 100%;\n  height: 0%;\n  border-top: 50px solid transparent;\n  border-left: 410px solid rgba(7, 33, 230, 0.508);\n  border-bottom: 0px solid transparent;\n}\n\nion-header ion-toolbar {\n  --background: none;\n}\n\nion-header ion-toolbar ion-title {\n  position: absolute;\n}\n\nion-header ion-toolbar ion-button {\n  margin-left: 15px;\n  position: absolute !important;\n  z-index: 100;\n}\n\nion-content {\n  --ion-background-color: none;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFxwYWdlLWNvbnRyb2wuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0E7RUFDRSxZQUFBO0FBQUY7O0FBR0E7RUFDRSxZQUFBO0FBQUY7O0FBR0EsVUFBQTs7QUFDQTtFQUNFLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFVBQUE7RUFDQSxpQ0FBQTtFQUNBLDhDQUFBO0VBQ0EscUNBQUE7QUFBRjs7QUFHQTtFQUNFLFdBQUE7RUFDQSxVQUFBO0VBQ0EsaUNBQUE7RUFDQSxnREFBQTtFQUNBLHFDQUFBO0FBQUY7O0FBR0E7RUFDRSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxVQUFBO0VBQ0Esa0NBQUE7RUFDQSw4Q0FBQTtFQUNBLG9DQUFBO0FBQUY7O0FBR0E7RUFDRSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxVQUFBO0VBQ0Esa0NBQUE7RUFDQSxnREFBQTtFQUNBLG9DQUFBO0FBQUY7O0FBSUU7RUFDRSxrQkFBQTtBQURKOztBQUVJO0VBQ0Usa0JBQUE7QUFBTjs7QUFFSTtFQUNFLGlCQUFBO0VBQ0EsNkJBQUE7RUFDQSxZQUFBO0FBQU47O0FBS0E7RUFDRSw0QkFBQTtBQUZGIiwiZmlsZSI6InBhZ2UtY29udHJvbC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG5pb24tZ3JpZCB7XHJcbiAgaGVpZ2h0OiAxMDAlO1xyXG59XHJcblxyXG5pb24tcm93IHtcclxuICBoZWlnaHQ6IDEwMCU7XHJcbn1cclxuXHJcbi8qRmlndXJhcyovXHJcbi50cmlfc3VwX2l6cSB7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGhlaWdodDogMCU7XHJcbiAgYm9yZGVyLXRvcDogMHB4IHNvbGlkIHRyYW5zcGFyZW50O1xyXG4gIGJvcmRlci1yaWdodDogNDgwcHggc29saWQgcmdiYSgyMzAsIDcsIDcsIDAuNyk7XHJcbiAgYm9yZGVyLWJvdHRvbTogNTBweCBzb2xpZCB0cmFuc3BhcmVudDtcclxufVxyXG5cclxuLnRyaV9zdXBfZGVyIHtcclxuICB3aWR0aDogMTAwJTtcclxuICBoZWlnaHQ6IDAlO1xyXG4gIGJvcmRlci10b3A6IDBweCBzb2xpZCB0cmFuc3BhcmVudDtcclxuICBib3JkZXItbGVmdDogNDgwcHggc29saWQgcmdiYSg3LCAzMywgMjMwLCAwLjUwOCk7XHJcbiAgYm9yZGVyLWJvdHRvbTogNTBweCBzb2xpZCB0cmFuc3BhcmVudDtcclxufVxyXG5cclxuLnRyaV9pbmZfaXpxIHtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgaGVpZ2h0OiAwJTtcclxuICBib3JkZXItdG9wOiA1MHB4IHNvbGlkIHRyYW5zcGFyZW50O1xyXG4gIGJvcmRlci1yaWdodDogNDEwcHggc29saWQgcmdiYSgyMzAsIDcsIDcsIDAuNyk7XHJcbiAgYm9yZGVyLWJvdHRvbTogMHB4IHNvbGlkIHRyYW5zcGFyZW50O1xyXG59XHJcblxyXG4udHJpX2luZl9kZXIge1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICB3aWR0aDogMTAwJTtcclxuICBoZWlnaHQ6IDAlO1xyXG4gIGJvcmRlci10b3A6IDUwcHggc29saWQgdHJhbnNwYXJlbnQ7XHJcbiAgYm9yZGVyLWxlZnQ6IDQxMHB4IHNvbGlkIHJnYmEoNywgMzMsIDIzMCwgMC41MDgpO1xyXG4gIGJvcmRlci1ib3R0b206IDBweCBzb2xpZCB0cmFuc3BhcmVudDtcclxufVxyXG5cclxuaW9uLWhlYWRlciB7XHJcbiAgaW9uLXRvb2xiYXIge1xyXG4gICAgLS1iYWNrZ3JvdW5kOiBub25lO1xyXG4gICAgaW9uLXRpdGxlIHtcclxuICAgICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgfVxyXG4gICAgaW9uLWJ1dHRvbiB7XHJcbiAgICAgIG1hcmdpbi1sZWZ0OiAxNXB4O1xyXG4gICAgICBwb3NpdGlvbjogYWJzb2x1dGUgIWltcG9ydGFudDtcclxuICAgICAgei1pbmRleDogMTAwO1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG5cclxuaW9uLWNvbnRlbnQge1xyXG4gIC0taW9uLWJhY2tncm91bmQtY29sb3I6IG5vbmU7XHJcbn1cclxuIl19 */");

/***/ }),

/***/ "b6fR":
/*!************************************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/coexpan/logistica/control-productos/bodega-planta/bp-menu-planta/bp-menu-planta.component.html ***!
  \************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar class=\"toolbar\">\n    <ion-title class=\"title ion-no-padding\"><strong>Bodega Planta</strong></ion-title>\n    <ion-button class=\"btn-sand\"\n      (click)=\"openMenu()\" slot=\"start\" shape=\"clear\" fill=\"clear\" color=\"warning\">\n    <ion-icon name=\"menu-outline\"></ion-icon>\n    </ion-button>\n  </ion-toolbar>\n</ion-header>\n\n\n<ion-content id=\"contentt\" fixed>\n  <ion-grid fixed size=\"sx\" class=\"grid-1\">\n    <ion-row class=\"row-1 ion-align-items-center\">\n      <ion-col size=\"12\">\n        <ion-button class=\"btn-etq\" size=\"large\" expand=\"block\" (click)=\"pageEtqEntradaMercancia()\">\n          Etiqueta Entr. Merc.\n        </ion-button>\n      </ion-col>\n      <ion-col size=\"12\">\n        <ion-button class=\"btn-reetq\" size=\"large\" expand=\"block\" (click)=\"pageReimprimirEtiqueta()\">\n          Reimprimir Etiqueta\n        </ion-button>\n      </ion-col>\n      <ion-col size=\"12\">\n        <ion-button class=\"btn-reetq\" size=\"large\" expand=\"block\" (click)=\"pageEliminarEtiqueta()\">\n          Eliminar Etiqueta\n        </ion-button>\n      </ion-col>\n      <ion-col size=\"12\">\n        <ion-button class=\"btn-em\" size=\"large\" expand=\"block\" (click)=\"pageEntradaMercancia()\">\n          Entrada Mercancia\n        </ion-button>\n      </ion-col>\n      <ion-col size=\"12\">\n        <ion-button class=\"btn-sm\" disabled size=\"large\" expand=\"block\"\n        (click)=\"pageSalidaMercancia()\">\n          Salida de Mercancia\n        </ion-button>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-content>\n\n\n<ion-footer class=\"ion-no-border\">\n  <div class=\"tri_inf_izq\"></div>\n  <div class=\"tri_inf_der\"></div>\n</ion-footer>\n");

/***/ }),

/***/ "cBXM":
/*!**********************************************************************************************************************************!*\
  !*** ./src/app/pages/coexpan/logistica/control-productos/bodega-planta/bp-entrada-mercancia/bp-entrada-mercancia.component.scss ***!
  \**********************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("@import url(\"https://fonts.googleapis.com/css2?family=Rubik:wght@600&display=swap\");\n*:not(ion-icon) {\n  font-family: \"Rubik\", sans-serif !important;\n}\nion-header .toolbar {\n  --background: rgb(197, 191, 0, 0.9);\n  --color: white;\n}\nion-content {\n  --background: none;\n}\nion-content .ion-row-1 {\n  padding-top: 4px;\n}\nion-content .ion-row-1 .ion-list {\n  background-color: rgba(232, 233, 233, 0);\n  border-radius: 3%;\n}\nion-content .ion-row-1 .ion-list ion-item {\n  --background: rgb(232, 233, 233, 0.8);\n}\nion-footer .toolbar {\n  --background: rgb(197, 191, 0, 0.5);\n  --color: white;\n}\nion-footer .ion-row-2 .btn-1 {\n  --background: rgb(0, 0, 0);\n  --color: white;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcYnAtZW50cmFkYS1tZXJjYW5jaWEuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQVEsbUZBQUE7QUFFUjtFQUNFLDJDQUFBO0FBQUY7QUFJRTtFQUNFLG1DQUFBO0VBQ0EsY0FBQTtBQURKO0FBS0E7RUFDRSxrQkFBQTtBQUZGO0FBR0U7RUFDRSxnQkFBQTtBQURKO0FBRUk7RUFDRSx3Q0FBQTtFQUNBLGlCQUFBO0FBQU47QUFDTTtFQUNFLHFDQUFBO0FBQ1I7QUFPRTtFQUNFLG1DQUFBO0VBQ0EsY0FBQTtBQUpKO0FBT0k7RUFDRSwwQkFBQTtFQUNBLGNBQUE7QUFMTiIsImZpbGUiOiJicC1lbnRyYWRhLW1lcmNhbmNpYS5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIkBpbXBvcnQgdXJsKCdodHRwczovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2NzczI/ZmFtaWx5PVJ1YmlrOndnaHRANjAwJmRpc3BsYXk9c3dhcCcpO1xyXG5cclxuKjpub3QoaW9uLWljb24pIHtcclxuICBmb250LWZhbWlseTogJ1J1YmlrJywgc2Fucy1zZXJpZiFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbmlvbi1oZWFkZXIge1xyXG4gIC50b29sYmFyIHtcclxuICAgIC0tYmFja2dyb3VuZDogcmdiKDE5NywgMTkxLCAwLCAwLjkpO1xyXG4gICAgLS1jb2xvcjogd2hpdGU7XHJcbiAgfVxyXG59XHJcblxyXG5pb24tY29udGVudCB7XHJcbiAgLS1iYWNrZ3JvdW5kOiBub25lO1xyXG4gIC5pb24tcm93LTF7XHJcbiAgICBwYWRkaW5nLXRvcDogNHB4O1xyXG4gICAgLmlvbi1saXN0IHtcclxuICAgICAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDIzMiwgMjMzLCAyMzMsIDAuMCk7XHJcbiAgICAgIGJvcmRlci1yYWRpdXM6IDMlO1xyXG4gICAgICBpb24taXRlbSB7XHJcbiAgICAgICAgLS1iYWNrZ3JvdW5kOiByZ2IoMjMyLCAyMzMsIDIzMywgMC44KTtcclxuXHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcbn1cclxuXHJcbmlvbi1mb290ZXIge1xyXG4gIC50b29sYmFyIHtcclxuICAgIC0tYmFja2dyb3VuZDogcmdiKDE5NywgMTkxLCAwLCAwLjUpO1xyXG4gICAgLS1jb2xvcjogd2hpdGU7XHJcbiAgfVxyXG4gIC5pb24tcm93LTJ7XHJcbiAgICAuYnRuLTEge1xyXG4gICAgICAtLWJhY2tncm91bmQ6IHJnYigwLCAwLCAwKTtcclxuICAgICAgLS1jb2xvcjogd2hpdGU7XHJcbiAgICB9XHJcbiAgfVxyXG59XHJcblxyXG5cclxuIl19 */");

/***/ }),

/***/ "e+Bk":
/*!**************************************************************************************************!*\
  !*** ./src/app/pages/coexpan/logistica/control-productos/page-control/page-control.component.ts ***!
  \**************************************************************************************************/
/*! exports provided: PageControlComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PageControlComponent", function() { return PageControlComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_page_control_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./page-control.component.html */ "6+NG");
/* harmony import */ var _page_control_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./page-control.component.scss */ "aSy8");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "TEn/");






let PageControlComponent = class PageControlComponent {
    constructor(route, menu) {
        this.route = route;
        this.menu = menu;
    }
    ngOnInit() { }
    pageBodegasCxp() {
        this.route.navigateByUrl('pages/cxp/control/bodegas');
    }
    openMenu() {
        this.menu.open();
    }
};
PageControlComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["MenuController"] }
];
PageControlComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-page-control',
        template: _raw_loader_page_control_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_page_control_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], PageControlComponent);



/***/ }),

/***/ "eK38":
/*!***********************************************************************************************************!*\
  !*** ./src/app/pages/coexpan/logistica/control-productos/bodega-renca/br-ingreso/br-ingreso.component.ts ***!
  \***********************************************************************************************************/
/*! exports provided: BrIngresoComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BrIngresoComponent", function() { return BrIngresoComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_br_ingreso_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./br-ingreso.component.html */ "WsvI");
/* harmony import */ var _br_ingreso_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./br-ingreso.component.scss */ "6GvH");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _providers_web_services_cxp_cxp_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../../../../providers/web-services/cxp/cxp.service */ "4gYv");
/* harmony import */ var _models_Registros_model__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../../../../models/Registros.model */ "JUB7");







let BrIngresoComponent = class BrIngresoComponent {
    constructor(cxpService, alertCtrl, loadingCtrl) {
        this.cxpService = cxpService;
        this.alertCtrl = alertCtrl;
        this.loadingCtrl = loadingCtrl;
        this.isLoading = false;
    }
    ngOnInit() {
    }
    ngAfterViewInit() {
        this.htmlEnviar.disabled = true;
        this.htmlCodigos.setFocus();
    }
    revisarTexto(str) {
        if (str.length === 0) {
            this.htmlEnviar.disabled = true;
        }
        else {
            this.htmlEnviar.disabled = false;
        }
    }
    enviarCodigos(codigos) {
        this.present();
        this.htmlEnviar.disabled = true;
        const registro = new _models_Registros_model__WEBPACK_IMPORTED_MODULE_6__["RegistrosModel"]();
        let mensaje;
        let exi = 0;
        let err = 0;
        registro.FechaScan = this.ObtenerFecha();
        registro.IdUsuario = 1;
        const arrayCadena = this.transformarArreglo(codigos);
        registro.CodBarras = arrayCadena;
        if (registro.CodBarras.length === 0) {
            this.presentAlert('Error', 'Debe Escanear para poder enviar los códigos', '');
            this.dismiss();
            this.htmlCodigos.value = '';
        }
        else {
            console.log(registro.CodBarras);
            this.cxpService.cxpBrEnviarIngreso(registro).then((res) => {
                mensaje = JSON.parse(res.toString());
                console.log(mensaje);
                mensaje.EstadoCodigos.forEach(status => {
                    switch (status.ESTADO) {
                        case 'T':
                            exi += 1;
                            break;
                        case 'F':
                            err += 1;
                            break;
                        default: break;
                    }
                });
                this.dismiss();
                this.presentAlert('Estado de Ingreso', `<strong>Correctos: ${exi} bob.<br></strong><br>
          <strong>Error: ${err} bob.<br></strong>`, ` `);
            }, (errr) => {
                console.log(errr);
                this.dismiss();
            });
            this.htmlCodigos.value = '';
            this.htmlCodigos.setFocus();
        }
    }
    //#region Herramientas
    transformarArreglo(codigos) {
        const arrayCadena = codigos.trim().split(' ');
        const arrayCadenaClean = arrayCadena.filter(Boolean);
        const arrayClean = [...new Set(arrayCadenaClean)];
        return arrayClean;
    }
    presentAlert(cab, cuerpo, subcab) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                cssClass: 'loading',
                header: cab,
                subHeader: subcab,
                message: cuerpo,
                buttons: [
                    {
                        text: 'OK',
                        handler: () => {
                            this.htmlCodigos.setFocus();
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    presentAlertConfirm(codigos) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                cssClass: 'loading',
                header: 'Confirmar Envío',
                message: 'Desea enviar los <strong>Códigos de Bobinas</strong> ?',
                buttons: [
                    {
                        text: 'Cancelar',
                        role: 'cancel',
                        handler: () => {
                            console.log('no se envio');
                        }
                    }, {
                        text: 'Ok',
                        handler: () => {
                            this.enviarCodigos(codigos);
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    // async loadingData(str: string) {
    //   this.loading = await this.loadingCtrl.create({
    //     cssClass: 'my-custom-class',
    //     message: str,
    //   });
    //   return this.loading.present();
    // }
    present() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.isLoading = true;
            return yield this.loadingCtrl.create({
                cssClass: 'loading',
                message: 'Enviando...',
            }).then(a => {
                a.present().then(() => {
                    // console.log('presented');
                    if (!this.isLoading) {
                        a.dismiss();
                    }
                });
            });
        });
    }
    dismiss() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.isLoading = false;
            return yield this.loadingCtrl.dismiss().then(() => console.log('dismissed'));
        });
    }
    ObtenerFecha() {
        const fechaDate = new Date();
        let fechaString = '';
        const anio = fechaDate.getFullYear();
        let dia = '';
        let mes = '';
        let hora = '';
        let minuto = '';
        let segundo = '';
        if (fechaDate.getDate() < 10) {
            dia = `0${fechaDate.getDate()}`;
        }
        else {
            dia = fechaDate.getDate().toString();
        }
        if (fechaDate.getMonth() < 9) {
            mes = `0${fechaDate.getMonth() + 1}`;
        }
        else {
            mes = (fechaDate.getMonth() + 1).toString();
        }
        if (fechaDate.getHours() < 10) {
            hora = `0${fechaDate.getHours()}`;
        }
        else {
            hora = fechaDate.getHours().toString();
        }
        if (fechaDate.getMinutes() < 10) {
            minuto = `0${fechaDate.getMinutes()}`;
        }
        else {
            minuto = fechaDate.getMinutes().toString();
        }
        if (fechaDate.getSeconds() < 10) {
            segundo = `0${fechaDate.getSeconds()}`;
        }
        else {
            segundo = fechaDate.getSeconds().toString();
        }
        fechaString = `${anio}${mes}${dia} ${hora}:${minuto}:${segundo}`;
        return fechaString;
    }
};
BrIngresoComponent.ctorParameters = () => [
    { type: _providers_web_services_cxp_cxp_service__WEBPACK_IMPORTED_MODULE_5__["CxpService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"] }
];
BrIngresoComponent.propDecorators = {
    htmlCodigos: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"], args: ['codigos',] }],
    htmlEnviar: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"], args: ['btnenviar',] }]
};
BrIngresoComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-br-ingreso',
        template: _raw_loader_br_ingreso_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_br_ingreso_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], BrIngresoComponent);



/***/ }),

/***/ "gLdY":
/*!**********************************************************************************************************************************!*\
  !*** ./src/app/pages/coexpan/logistica/control-productos/bodega-planta/bp-eliminar-etiqueta/bp-eliminar-etiqueta.component.scss ***!
  \**********************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("@import url(\"https://fonts.googleapis.com/css2?family=Rubik:wght@600&display=swap\");\n*:not(ion-icon) {\n  font-family: \"Rubik\", sans-serif !important;\n}\nion-header .toolbar {\n  --background: rgba(197, 0, 0, 0.9);\n  --color: white;\n}\nion-content {\n  --background: none;\n}\nion-content .ion-row-1 {\n  padding-top: 4px;\n}\nion-content .ion-row-1 .ion-list {\n  background-color: rgba(232, 233, 233, 0);\n  border-radius: 3%;\n}\nion-content .ion-row-1 .ion-list ion-item {\n  --background: rgb(232, 233, 233, 0.8);\n}\nion-footer .toolbar {\n  --background: rgba(197, 0, 0, 0.5);\n  --color: white;\n}\nion-footer .ion-row-2 .btn-1 {\n  --background: rgb(0, 0, 0);\n  --color: white;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcYnAtZWxpbWluYXItZXRpcXVldGEuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQVEsbUZBQUE7QUFFUjtFQUNFLDJDQUFBO0FBQUY7QUFJRTtFQUNFLGtDQUFBO0VBQ0EsY0FBQTtBQURKO0FBS0E7RUFDRSxrQkFBQTtBQUZGO0FBR0U7RUFDRSxnQkFBQTtBQURKO0FBRUk7RUFDRSx3Q0FBQTtFQUNBLGlCQUFBO0FBQU47QUFDTTtFQUNFLHFDQUFBO0FBQ1I7QUFPRTtFQUNFLGtDQUFBO0VBQ0EsY0FBQTtBQUpKO0FBT0k7RUFDRSwwQkFBQTtFQUNBLGNBQUE7QUFMTiIsImZpbGUiOiJicC1lbGltaW5hci1ldGlxdWV0YS5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIkBpbXBvcnQgdXJsKCdodHRwczovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2NzczI/ZmFtaWx5PVJ1YmlrOndnaHRANjAwJmRpc3BsYXk9c3dhcCcpO1xyXG5cclxuKjpub3QoaW9uLWljb24pIHtcclxuICBmb250LWZhbWlseTogJ1J1YmlrJywgc2Fucy1zZXJpZiFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbmlvbi1oZWFkZXIge1xyXG4gIC50b29sYmFyIHtcclxuICAgIC0tYmFja2dyb3VuZDogcmdiYSgxOTcsIDAsIDAsIDAuOSk7XHJcbiAgICAtLWNvbG9yOiB3aGl0ZTtcclxuICB9XHJcbn1cclxuXHJcbmlvbi1jb250ZW50IHtcclxuICAtLWJhY2tncm91bmQ6IG5vbmU7XHJcbiAgLmlvbi1yb3ctMXtcclxuICAgIHBhZGRpbmctdG9wOiA0cHg7XHJcbiAgICAuaW9uLWxpc3Qge1xyXG4gICAgICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2IoMjMyLCAyMzMsIDIzMywgMC4wKTtcclxuICAgICAgYm9yZGVyLXJhZGl1czogMyU7XHJcbiAgICAgIGlvbi1pdGVtIHtcclxuICAgICAgICAtLWJhY2tncm91bmQ6IHJnYigyMzIsIDIzMywgMjMzLCAwLjgpO1xyXG5cclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxufVxyXG5cclxuaW9uLWZvb3RlciB7XHJcbiAgLnRvb2xiYXIge1xyXG4gICAgLS1iYWNrZ3JvdW5kOiByZ2JhKDE5NywgMCwgMCwgMC41KTtcclxuICAgIC0tY29sb3I6IHdoaXRlO1xyXG4gIH1cclxuICAuaW9uLXJvdy0ye1xyXG4gICAgLmJ0bi0xIHtcclxuICAgICAgLS1iYWNrZ3JvdW5kOiByZ2IoMCwgMCwgMCk7XHJcbiAgICAgIC0tY29sb3I6IHdoaXRlO1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG4iXX0= */");

/***/ }),

/***/ "i5oz":
/*!************************************************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/coexpan/logistica/control-productos/bodega-planta/bp-eliminar-etiqueta/bp-eliminar-etiqueta.component.html ***!
  \************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-toolbar class=\"toolbar\">\r\n    <ion-grid fixed>\r\n      <ion-row class=\"ion-row-1 ion-justify-content-center\">\r\n        <ion-col size=\"12\">\r\n          <ion-title>Eliminar Etiqueta Pallet</ion-title>\r\n        </ion-col>\r\n        <ion-col size=\"12\">\r\n          <ion-item class=\"ion-item-1\">\r\n            <ion-textarea #codigos rows=\"1\"\r\n              disabled=\"false\"\r\n              placeholder=\"Escanea Códido de Pallet...\"\r\n              (keyup.enter)=\"obtenerDatosPallet(codigos.value)\">\r\n            </ion-textarea>\r\n            <ion-spinner *ngIf=\"txtarea.spinner\"  style=\"margin-top: 10px;\" name=\"bubbles\"></ion-spinner>\r\n          </ion-item>\r\n        </ion-col>\r\n      </ion-row>\r\n    </ion-grid>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n\r\n<ion-card *ngIf=\"pallet\" id=\"cardbobina\">\r\n  <ion-card-header>\r\n    <ion-card-subtitle>Orden Fab: {{pallet.ORDEN_FAB}}</ion-card-subtitle>\r\n    <ion-card-title>{{pallet.NOM_PRODUCTO}}</ion-card-title>\r\n  </ion-card-header>\r\n  <ion-card-content>\r\n    <div>Cliente: {{pallet.CLIENTE}}</div>\r\n    <div>Cant. Bobinas: {{pallet.CANT_BOB}}</div>\r\n    <div>Peso Bruto: {{pallet.PESO_BRUTO}}</div>\r\n    <div>Peso Neto: {{pallet.PESO_NETO}}</div>\r\n    <div>N° Pallet: {{pallet.CORRELATIVO}}</div>\r\n  </ion-card-content>\r\n</ion-card>\r\n\r\n\r\n<ion-footer>\r\n  <ion-toolbar class=\"toolbar\">\r\n    <ion-grid fixed>\r\n      <ion-row class=\"ion-row-2 ion-justify-content-center\">\r\n        <ion-col size=\"12\">\r\n          <ion-button #btnEliminar size=\"large\" expand=\"block\" class=\"btn-1\"\r\n            (click)=\"alertEliminarEtiqueta()\">\r\n            Eliminar\r\n          </ion-button>\r\n        </ion-col>\r\n      </ion-row>\r\n    </ion-grid>\r\n  </ion-toolbar>\r\n</ion-footer>\r\n\r\n\r\n\r\n");

/***/ }),

/***/ "iUSm":
/*!******************************************************************************************************************************************!*\
  !*** ./src/app/pages/coexpan/logistica/control-productos/bodega-planta/bp-etq-entrada-mercancia/bp-etq-entrada-mercancia.component.scss ***!
  \******************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("@import url(\"https://fonts.googleapis.com/css2?family=Rubik:wght@600&display=swap\");\n*:not(ion-icon) {\n  font-family: \"Rubik\", sans-serif !important;\n}\nion-header .toolbar {\n  --background: rgb(197, 191, 0, 0.9);\n  --color: white;\n}\nion-content {\n  --background: none;\n}\nion-content .ion-row-1 {\n  padding-top: 4px;\n}\nion-content .ion-row-1 .ion-item-1 {\n  background-color: #e8e9e9;\n  border-radius: 3%;\n}\nion-content .ion-row-2 .btn-1 {\n  --background: rgb(0, 0, 0);\n  --color: white;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcYnAtZXRxLWVudHJhZGEtbWVyY2FuY2lhLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFRLG1GQUFBO0FBRVI7RUFDRSwyQ0FBQTtBQUFGO0FBSUU7RUFDRSxtQ0FBQTtFQUNBLGNBQUE7QUFESjtBQUtBO0VBQ0Usa0JBQUE7QUFGRjtBQUdFO0VBQ0UsZ0JBQUE7QUFESjtBQUVJO0VBQ0UseUJBQUE7RUFDQSxpQkFBQTtBQUFOO0FBSUk7RUFDRSwwQkFBQTtFQUNBLGNBQUE7QUFGTiIsImZpbGUiOiJicC1ldHEtZW50cmFkYS1tZXJjYW5jaWEuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJAaW1wb3J0IHVybCgnaHR0cHM6Ly9mb250cy5nb29nbGVhcGlzLmNvbS9jc3MyP2ZhbWlseT1SdWJpazp3Z2h0QDYwMCZkaXNwbGF5PXN3YXAnKTtcclxuXHJcbio6bm90KGlvbi1pY29uKSB7XHJcbiAgZm9udC1mYW1pbHk6ICdSdWJpaycsIHNhbnMtc2VyaWYhaW1wb3J0YW50O1xyXG59XHJcblxyXG5pb24taGVhZGVyIHtcclxuICAudG9vbGJhciB7XHJcbiAgICAtLWJhY2tncm91bmQ6IHJnYigxOTcsIDE5MSwgMCwgMC45KTtcclxuICAgIC0tY29sb3I6IHdoaXRlO1xyXG4gIH1cclxufVxyXG5cclxuaW9uLWNvbnRlbnQge1xyXG4gIC0tYmFja2dyb3VuZDogbm9uZTtcclxuICAuaW9uLXJvdy0xe1xyXG4gICAgcGFkZGluZy10b3A6IDRweDtcclxuICAgIC5pb24taXRlbS0xIHtcclxuICAgICAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDIzMiwgMjMzLCAyMzMpO1xyXG4gICAgICBib3JkZXItcmFkaXVzOiAzJTtcclxuICAgIH1cclxuICB9XHJcbiAgLmlvbi1yb3ctMntcclxuICAgIC5idG4tMSB7XHJcbiAgICAgIC0tYmFja2dyb3VuZDogcmdiKDAsIDAsIDApO1xyXG4gICAgICAtLWNvbG9yOiB3aGl0ZTtcclxuICAgIH1cclxuICB9XHJcbn1cclxuXHJcblxyXG4iXX0= */");

/***/ }),

/***/ "ir1d":
/*!******************************************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/coexpan/logistica/control-productos/bodega-planta/bp-etq-reimprimir/bp-etq-reimprimir.component.html ***!
  \******************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-toolbar class=\"toolbar\">\r\n    <ion-grid fixed>\r\n      <ion-row class=\"ion-row-1 ion-justify-content-center\">\r\n        <ion-col size=\"12\">\r\n          <ion-title>Reimpresión Etiqueta</ion-title>\r\n        </ion-col>\r\n        <ion-col size=\"12\">\r\n          <ion-item class=\"ion-item-1\">\r\n            <ion-textarea #codigos rows=\"1\"\r\n              disabled=\"false\"\r\n              placeholder=\"Códido de Pallet o Bobina...\"\r\n              (keyup.enter)=\"obtenerDatosPallet(codigos.value)\">\r\n            </ion-textarea>\r\n            <ion-spinner *ngIf=\"txtarea.spinner\"  style=\"margin-top: 10px;\" name=\"bubbles\"></ion-spinner>\r\n          </ion-item>\r\n        </ion-col>\r\n      </ion-row>\r\n    </ion-grid>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <ion-grid fixed>\r\n    <ion-row class=\"ion-row-1\">\r\n      <ion-col size=\"12\">\r\n        <ion-list class=\"ion-list\">\r\n          <ion-item *ngIf=\"pallets.length <= 0\" >\r\n            <ion-label color=\"dark\">Sin Datos...</ion-label>\r\n          </ion-item>\r\n          <ion-item-sliding *ngFor=\"let pt of pallets\" >\r\n            <ion-item>\r\n              <ion-label>OF: {{pt.ORDEN_FAB|number}} - N° Pallet: {{pt.CORRELATIVO}}</ion-label>\r\n              <ion-button #btnpallet (click)=\"infoItem(pt.CODBAR_MULTI)\"\r\n              expand=\"block\" color=\"primary\" shape=\"round\">\r\n                Info\r\n              </ion-button>\r\n            </ion-item>\r\n            <ion-item-options side=\"end\">\r\n              <ion-item-option (click)=\"eliminarItem(pt.CODBAR_MULTI)\">Borrar</ion-item-option>\r\n            </ion-item-options>\r\n          </ion-item-sliding>\r\n        </ion-list>\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n</ion-content>\r\n\r\n<ion-footer>\r\n  <ion-toolbar class=\"toolbar\">\r\n    <ion-grid fixed>\r\n      <ion-row class=\"ion-row-2 ion-justify-content-center\">\r\n        <ion-col size=\"12\">\r\n          <ion-button #btnEnviar size=\"large\" expand=\"block\" class=\"btn-1\"\r\n            (click)=\"imprimirEtiquetas()\">\r\n            Enviar\r\n          </ion-button>\r\n        </ion-col>\r\n      </ion-row>\r\n    </ion-grid>\r\n  </ion-toolbar>\r\n</ion-footer>\r\n");

/***/ }),

/***/ "islD":
/*!**********************************************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/coexpan/logistica/control-productos/bodega-planta/bp-salida-mercancia/bp-salida-mercancia.component.html ***!
  \**********************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar class=\"toolbar\">\n    <ion-title>Salida de Mercancía</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-grid fixed>\n    <ion-row class=\"ion-row-1 ion-justify-content-center\">\n      <ion-col size=\"12\">\n        <ion-item class=\"ion-item-1\">\n          <ion-textarea #codigos rows=\"13\"\n            placeholder=\"Escanea las bobinas para enviar...\"\n            (keyup)=\"textoCodigos(codigos.value)\"\n            (keyup.enter)=\"revisionCodigos()\">\n          </ion-textarea>\n        </ion-item>\n      </ion-col>\n    </ion-row>\n    <ion-row class=\"ion-row-2 ion-justify-content-center\">\n      <ion-col size=\"12\" class=\"ion-padding\">\n          <ion-button #btnEnviar size=\"large\" expand=\"full\" class=\"btn-1\"\n            (click)=\"revisionCodigos()\">\n            Enviar\n          </ion-button>\n      </ion-col>\n  </ion-row>\n  </ion-grid>\n</ion-content>\n\n");

/***/ }),

/***/ "nrOU":
/*!******************************************************************************************************************************!*\
  !*** ./src/app/pages/coexpan/logistica/control-productos/bodega-planta/bp-salida-mercancia/bp-salida-mercancia.component.ts ***!
  \******************************************************************************************************************************/
/*! exports provided: BpSalidaMercanciaComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BpSalidaMercanciaComponent", function() { return BpSalidaMercanciaComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_bp_salida_mercancia_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./bp-salida-mercancia.component.html */ "islD");
/* harmony import */ var _bp_salida_mercancia_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./bp-salida-mercancia.component.scss */ "Cmb5");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _providers_web_services_cxp_cxp_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../../../../providers/web-services/cxp/cxp.service */ "4gYv");
/* harmony import */ var _models_Registros_model__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../../../../models/Registros.model */ "JUB7");







let BpSalidaMercanciaComponent = class BpSalidaMercanciaComponent {
    constructor(alertCtrl, loadingCtrl, cxpService) {
        this.alertCtrl = alertCtrl;
        this.loadingCtrl = loadingCtrl;
        this.cxpService = cxpService;
        this.isLoading = false;
    }
    ngOnInit() {
    }
    ngAfterViewInit() {
        this.btnEnviar.disabled = true;
    }
    textoCodigos(valor) {
        this.codigos = valor;
        if (this.codigos.length === 0) {
            this.btnEnviar.disabled = true;
        }
        else {
            this.btnEnviar.disabled = false;
        }
        console.log(this.codigos);
    }
    revisionCodigos() {
        this.arrayCod = this.transformarArreglo(this.codigos);
        if (this.arrayCod.length === 0) {
            this.pstErrorCodigos();
        }
        else {
            this.pstConfirmarEnvio();
        }
    }
    enviarCodigos() {
        const registros = new _models_Registros_model__WEBPACK_IMPORTED_MODULE_6__["RegistrosModel"]();
        registros.CodBarras = this.arrayCod;
        registros.FechaScan = this.obtenerFecha();
        registros.Bodega = 1;
        registros.IdUsuario = null;
        let mensaje;
        let err = 0;
        let suc = 0;
        this.cxpService.cxpLogisticaSalidaMercancia(registros).then((res) => {
            console.log(res);
            mensaje = JSON.parse(res.toString());
            console.log(mensaje);
            mensaje.EstadoCodigos.forEach(status => {
                switch (status.ESTADO) {
                    case 'F':
                        err += 1;
                        break;
                    case 'T':
                        suc += 1;
                        break;
                    default: break;
                }
            });
            this.dismiss();
            this.pstAlert('Estado de Ingreso', `<strong>Correctas: ${suc} bob.<br></strong><br>
        <strong>Error: ${err} bob.<br></strong>`);
        }, (err) => {
            console.log(err);
            this.dismiss();
        });
        this.txtCodigos.value = '';
        this.txtCodigos.setFocus();
    }
    //#region HERRAMIENTAS
    pstErrorCodigos() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                header: 'Error',
                message: 'Ingrese 1 o más códigos para continuar...',
                buttons: [{ text: 'Ok' }]
            });
            yield alert.present();
            this.btnEnviar.disabled = true;
            this.txtCodigos.value = '';
        });
    }
    pstConfirmarEnvio() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                cssClass: 'loading',
                header: 'Confirmar Envío',
                message: 'Desea enviar los <strong>Códigos de Bobinas</strong> ?',
                buttons: [
                    {
                        text: 'Cancelar',
                        role: 'cancel',
                        handler: () => {
                            console.log('no se envió :(');
                        }
                    }, {
                        text: 'Ok',
                        handler: () => {
                            this.enviarCodigos();
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    present() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.isLoading = true;
            return yield this.loadingCtrl.create({
                cssClass: 'loading',
                message: 'Enviando...',
            }).then(a => {
                a.present().then(() => {
                    // console.log('presented');
                    if (!this.isLoading) {
                        a.dismiss();
                    }
                });
            });
        });
    }
    pstAlert(cab, cuerpo, subcab) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                cssClass: 'loading',
                header: cab,
                subHeader: subcab,
                message: cuerpo,
                buttons: [
                    {
                        text: 'OK',
                        handler: () => {
                            this.txtCodigos.setFocus();
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    dismiss() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.isLoading = false;
            return yield this.loadingCtrl.dismiss().then(() => console.log('dismissed'));
        });
    }
    obtenerFecha() {
        const fechaDate = new Date();
        let fechaString = '';
        const anio = fechaDate.getFullYear();
        let dia = '';
        let mes = '';
        let hora = '';
        let minuto = '';
        let segundo = '';
        if (fechaDate.getDate() < 10) {
            dia = `0${fechaDate.getDate()}`;
        }
        else {
            dia = fechaDate.getDate().toString();
        }
        if (fechaDate.getMonth() < 10) {
            mes = `0${fechaDate.getMonth() + 1}`;
        }
        else {
            mes = (fechaDate.getMonth() + 1).toString();
        }
        if (fechaDate.getHours() < 10) {
            hora = `0${fechaDate.getHours()}`;
        }
        else {
            hora = fechaDate.getHours().toString();
        }
        if (fechaDate.getMinutes() < 10) {
            minuto = `0${fechaDate.getMinutes()}`;
        }
        else {
            minuto = fechaDate.getMinutes().toString();
        }
        if (fechaDate.getSeconds() < 10) {
            segundo = `0${fechaDate.getSeconds()}`;
        }
        else {
            segundo = fechaDate.getSeconds().toString();
        }
        fechaString = `${anio}${mes}${dia} ${hora}:${minuto}:${segundo}`;
        return fechaString;
    }
    transformarArreglo(codigos) {
        const arrayCadena = codigos.trim().split(' ');
        const arrayCadenaClean = arrayCadena.filter(Boolean);
        const arrayClean = [...new Set(arrayCadenaClean)];
        return arrayClean;
    }
};
BpSalidaMercanciaComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"] },
    { type: _providers_web_services_cxp_cxp_service__WEBPACK_IMPORTED_MODULE_5__["CxpService"] }
];
BpSalidaMercanciaComponent.propDecorators = {
    btnEnviar: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"], args: ['btnEnviar',] }],
    txtCodigos: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"], args: ['codigos',] }]
};
BpSalidaMercanciaComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-bp-salida-mercancia',
        template: _raw_loader_bp_salida_mercancia_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_bp_salida_mercancia_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], BpSalidaMercanciaComponent);



/***/ }),

/***/ "puES":
/*!**************************************************!*\
  !*** ./src/app/models/bodega-recepcion.model.ts ***!
  \**************************************************/
/*! exports provided: PalletBodegaRecepcionModel, ModelData */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PalletBodegaRecepcionModel", function() { return PalletBodegaRecepcionModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ModelData", function() { return ModelData; });
class PalletBodegaRecepcionModel {
}
class ModelData {
}


/***/ }),

/***/ "pyoF":
/*!**************************************************************************************************!*\
  !*** ./src/app/pages/coexpan/logistica/control-productos/page-bodegas/page-bodegas.component.ts ***!
  \**************************************************************************************************/
/*! exports provided: PageBodegasComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PageBodegasComponent", function() { return PageBodegasComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_page_bodegas_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./page-bodegas.component.html */ "Wyu7");
/* harmony import */ var _page_bodegas_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./page-bodegas.component.scss */ "UREj");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "TEn/");






let PageBodegasComponent = class PageBodegasComponent {
    constructor(route, menu) {
        this.route = route;
        this.menu = menu;
    }
    ngOnInit() { }
    pageMenuRenca() {
        this.route.navigateByUrl('pages/cxp/control/br');
    }
    pageMenuPlanta() {
        this.route.navigateByUrl('pages/cxp/control/bp');
    }
    openMenu() {
        this.menu.toggle();
    }
};
PageBodegasComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["MenuController"] }
];
PageBodegasComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-page-bodegas',
        template: _raw_loader_page_bodegas_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_page_bodegas_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], PageBodegasComponent);



/***/ }),

/***/ "qTFu":
/*!***********************************************************************************************************!*\
  !*** ./src/app/pages/coexpan/logistica/control-productos/bodega-renca/menu-renca/menu-renca.component.ts ***!
  \***********************************************************************************************************/
/*! exports provided: MenuRencaComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MenuRencaComponent", function() { return MenuRencaComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_menu_renca_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./menu-renca.component.html */ "5txJ");
/* harmony import */ var _menu_renca_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./menu-renca.component.scss */ "POYj");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "tyNb");





let MenuRencaComponent = class MenuRencaComponent {
    constructor(router) {
        this.router = router;
    }
    ngOnInit() { }
    pageIngreso() {
        this.router.navigateByUrl('pages/cxp/control/br/ingreso');
    }
    pageEgreso() {
        this.router.navigateByUrl('pages/cxp/control/br/egreso');
    }
};
MenuRencaComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] }
];
MenuRencaComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-menu-renca',
        template: _raw_loader_menu_renca_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_menu_renca_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], MenuRencaComponent);



/***/ }),

/***/ "rCgx":
/*!***********************************************************************************************!*\
  !*** ./src/app/pages/coexpan/logistica/control-productos/control-productos-routing.module.ts ***!
  \***********************************************************************************************/
/*! exports provided: ControlProductosRoutingModule, routedComponents */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ControlProductosRoutingModule", function() { return ControlProductosRoutingModule; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "routedComponents", function() { return routedComponents; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _control_productos_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./control-productos.component */ "DzOn");
/* harmony import */ var _page_control_page_control_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./page-control/page-control.component */ "e+Bk");
/* harmony import */ var _bodega_renca_br_ingreso_br_ingreso_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./bodega-renca/br-ingreso/br-ingreso.component */ "eK38");
/* harmony import */ var _bodega_renca_br_egreso_br_egreso_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./bodega-renca/br-egreso/br-egreso.component */ "FGgn");
/* harmony import */ var _page_bodegas_page_bodegas_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./page-bodegas/page-bodegas.component */ "pyoF");
/* harmony import */ var _bodega_renca_menu_renca_menu_renca_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./bodega-renca/menu-renca/menu-renca.component */ "qTFu");
/* harmony import */ var _bodega_planta_bp_menu_planta_bp_menu_planta_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./bodega-planta/bp-menu-planta/bp-menu-planta.component */ "ySe7");
/* harmony import */ var _bodega_planta_bp_etq_entrada_mercancia_bp_etq_entrada_mercancia_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./bodega-planta/bp-etq-entrada-mercancia/bp-etq-entrada-mercancia.component */ "5s14");
/* harmony import */ var _bodega_planta_bp_salida_mercancia_bp_salida_mercancia_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./bodega-planta/bp-salida-mercancia/bp-salida-mercancia.component */ "nrOU");
/* harmony import */ var _bodega_planta_bp_entrada_mercancia_bp_entrada_mercancia_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./bodega-planta/bp-entrada-mercancia/bp-entrada-mercancia.component */ "Qhgg");
/* harmony import */ var _bodega_planta_bp_etq_reimprimir_bp_etq_reimprimir_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./bodega-planta/bp-etq-reimprimir/bp-etq-reimprimir.component */ "5Gyp");
/* harmony import */ var _bodega_planta_bp_eliminar_etiqueta_bp_eliminar_etiqueta_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./bodega-planta/bp-eliminar-etiqueta/bp-eliminar-etiqueta.component */ "uVz2");















const routes = [{
        path: '',
        component: _control_productos_component__WEBPACK_IMPORTED_MODULE_3__["ControlProductosComponent"],
        children: [
            {
                path: 'inicio',
                component: _page_control_page_control_component__WEBPACK_IMPORTED_MODULE_4__["PageControlComponent"],
            },
            {
                path: 'bodegas',
                component: _page_bodegas_page_bodegas_component__WEBPACK_IMPORTED_MODULE_7__["PageBodegasComponent"],
            },
            // #region Bodega Renca
            {
                path: 'br',
                component: _bodega_renca_menu_renca_menu_renca_component__WEBPACK_IMPORTED_MODULE_8__["MenuRencaComponent"],
            },
            {
                path: 'br/ingreso',
                component: _bodega_renca_br_ingreso_br_ingreso_component__WEBPACK_IMPORTED_MODULE_5__["BrIngresoComponent"],
            },
            {
                path: 'br/egreso',
                component: _bodega_renca_br_egreso_br_egreso_component__WEBPACK_IMPORTED_MODULE_6__["BrEgresoComponent"],
            },
            //#endregion
            //#region Bodega Planta
            {
                path: 'bp',
                component: _bodega_planta_bp_menu_planta_bp_menu_planta_component__WEBPACK_IMPORTED_MODULE_9__["BpMenuPlantaComponent"],
            },
            {
                path: 'bp/etqem',
                component: _bodega_planta_bp_etq_entrada_mercancia_bp_etq_entrada_mercancia_component__WEBPACK_IMPORTED_MODULE_10__["BpEtqEntradaMercanciaComponent"],
            },
            {
                path: 'bp/reimprimiretq',
                component: _bodega_planta_bp_etq_reimprimir_bp_etq_reimprimir_component__WEBPACK_IMPORTED_MODULE_13__["BpEtqReimprimirComponent"],
            },
            {
                path: 'bp/eliminaretq',
                component: _bodega_planta_bp_eliminar_etiqueta_bp_eliminar_etiqueta_component__WEBPACK_IMPORTED_MODULE_14__["BpEliminarEtiquetaComponent"],
            },
            {
                path: 'bp/em',
                component: _bodega_planta_bp_entrada_mercancia_bp_entrada_mercancia_component__WEBPACK_IMPORTED_MODULE_12__["BpEntradaMercanciaComponent"],
            },
            {
                path: 'bp/sm',
                component: _bodega_planta_bp_salida_mercancia_bp_salida_mercancia_component__WEBPACK_IMPORTED_MODULE_11__["BpSalidaMercanciaComponent"],
            }
            //#endregion
        ]
    }];
let ControlProductosRoutingModule = class ControlProductosRoutingModule {
};
ControlProductosRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })
], ControlProductosRoutingModule);

const routedComponents = [
    _control_productos_component__WEBPACK_IMPORTED_MODULE_3__["ControlProductosComponent"],
    _page_control_page_control_component__WEBPACK_IMPORTED_MODULE_4__["PageControlComponent"],
    _bodega_renca_br_ingreso_br_ingreso_component__WEBPACK_IMPORTED_MODULE_5__["BrIngresoComponent"],
    _bodega_renca_br_egreso_br_egreso_component__WEBPACK_IMPORTED_MODULE_6__["BrEgresoComponent"],
    _page_bodegas_page_bodegas_component__WEBPACK_IMPORTED_MODULE_7__["PageBodegasComponent"],
    _bodega_renca_menu_renca_menu_renca_component__WEBPACK_IMPORTED_MODULE_8__["MenuRencaComponent"],
    _bodega_planta_bp_menu_planta_bp_menu_planta_component__WEBPACK_IMPORTED_MODULE_9__["BpMenuPlantaComponent"],
    _bodega_planta_bp_etq_entrada_mercancia_bp_etq_entrada_mercancia_component__WEBPACK_IMPORTED_MODULE_10__["BpEtqEntradaMercanciaComponent"],
    _bodega_planta_bp_etq_reimprimir_bp_etq_reimprimir_component__WEBPACK_IMPORTED_MODULE_13__["BpEtqReimprimirComponent"],
    _bodega_planta_bp_eliminar_etiqueta_bp_eliminar_etiqueta_component__WEBPACK_IMPORTED_MODULE_14__["BpEliminarEtiquetaComponent"],
    _bodega_planta_bp_entrada_mercancia_bp_entrada_mercancia_component__WEBPACK_IMPORTED_MODULE_12__["BpEntradaMercanciaComponent"],
    _bodega_planta_bp_salida_mercancia_bp_salida_mercancia_component__WEBPACK_IMPORTED_MODULE_11__["BpSalidaMercanciaComponent"],
];


/***/ }),

/***/ "uVz2":
/*!********************************************************************************************************************************!*\
  !*** ./src/app/pages/coexpan/logistica/control-productos/bodega-planta/bp-eliminar-etiqueta/bp-eliminar-etiqueta.component.ts ***!
  \********************************************************************************************************************************/
/*! exports provided: BpEliminarEtiquetaComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BpEliminarEtiquetaComponent", function() { return BpEliminarEtiquetaComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_bp_eliminar_etiqueta_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./bp-eliminar-etiqueta.component.html */ "i5oz");
/* harmony import */ var _bp_eliminar_etiqueta_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./bp-eliminar-etiqueta.component.scss */ "gLdY");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _providers_web_services_cxp_cxp_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../../../../providers/web-services/cxp/cxp.service */ "4gYv");
/* harmony import */ var _models_Registros_model__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../../../models/Registros.model */ "JUB7");









let BpEliminarEtiquetaComponent = class BpEliminarEtiquetaComponent {
    constructor(alertCtrl, toastCtrl, loadingCtrl, router, cxpService) {
        this.alertCtrl = alertCtrl;
        this.toastCtrl = toastCtrl;
        this.loadingCtrl = loadingCtrl;
        this.router = router;
        this.cxpService = cxpService;
        this.isLoading = false;
        this.txtarea = {
            spinner: false,
        };
    }
    ngOnInit() {
        this.alertComprobarUsuario();
    }
    ngAfterViewInit() {
        this.btnEliminar.disabled = true;
        this.txtCodigos.disabled = true;
    }
    // public comprobarDatoPallet(text: string) {
    //   const newtext = text.trim();
    //
    //   newtext !== '' && newtext.length >= 5 ?
    //   this.btnEliminar.disabled = false :
    //   this.btnEliminar.disabled = true;
    // }
    eliminarEtiquetaPallet() {
        const nroPallet = this.pallet.CODBAR_MULTI;
        this.cxpService.cxpLogisticaEliminarEtiquetaPallet(nroPallet).then((data) => {
            // console.log(JSON.parse(data));
            const sql = JSON.parse(data);
            console.log(sql);
            if (sql.Status.STATUS === 'T') {
                if (sql.Objeto[0].STATUS === 0) {
                    this.toastMessage(sql.Objeto[0].MESSAGE, 'success', 4000);
                    this.eliminarCard(600);
                    setTimeout(() => {
                        this.txtCodigos.setFocus();
                        this.btnEliminar.disabled = true;
                    }, 700);
                }
            }
            else {
                this.toastMessage(sql.Status.MESSAGE, 'warning', 4000);
            }
        });
    }
    obtenerDatosPallet(codigo) {
        // let pallet: PalletModel = new PalletModel();
        const codigopost = codigo.trim();
        const datos = new _models_Registros_model__WEBPACK_IMPORTED_MODULE_7__["InfoEtiquetaModel"]();
        let request = new _models_Registros_model__WEBPACK_IMPORTED_MODULE_7__["GetRequestModel"]();
        if (codigopost === '') {
            this.toastMessage('Ingrese un código.', 'warning', 2000);
            this.txtCodigos.value = '';
            return false;
        }
        //#region html
        this.txtCodigos.disabled = true;
        this.txtCodigos.value = '';
        this.txtarea.spinner = true;
        //#endregion html
        //#region condicion
        if (codigo.length <= 11) {
            datos.CodBobina = codigopost;
            datos.CodPallet = 'N';
        }
        else {
            datos.CodBobina = 'N';
            datos.CodPallet = codigopost;
        }
        //#endregion condicion
        this.cxpService.cxpObtenerInformacionEtiquetaPallet(datos).then((data) => {
            request = JSON.parse(data.toString());
            if (request.Status.STATUS === 'T') {
                if (request.Objeto !== null) {
                    this.pallet = request.Objeto;
                    this.btnEliminar.disabled = false;
                    console.log(this.pallet);
                }
                else {
                    this.toastMessage(`Etiqueta de Pallet no encontrada.`, 'warning', 2000);
                    this.btnEliminar.disabled = true;
                }
            }
            else {
                this.toastMessage(request.Status.MESSAGE, 'warning', 10000);
                this.btnEliminar.disabled = true;
            }
            //#region html
            this.txtCodigos.disabled = false;
            this.txtarea.spinner = false;
            setTimeout(() => { this.txtCodigos.setFocus(); }, 100);
            //#endregion html
        }, (err) => {
            console.log(err);
            //#region html
            this.txtCodigos.disabled = false;
            this.txtarea.spinner = false;
            this.btnEliminar.disabled = true;
            //#endregion html
        });
    }
    alertComprobarUsuario() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                header: 'Administrador',
                subHeader: 'Ingrese las credenciales para continuar.',
                backdropDismiss: false,
                inputs: [
                    {
                        name: 'pass',
                        type: 'password',
                        placeholder: 'Password',
                        attributes: {
                            inputmode: 'decimal'
                        }
                    }
                ],
                buttons: [
                    {
                        text: 'Cancelar',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: () => {
                            this.router.navigateByUrl('pages/cxp/control/bp');
                        }
                    },
                    {
                        text: 'Enviar',
                        handler: (data) => {
                            console.log(data);
                            const Usuario = {
                                User: '1002',
                                Pass: data.pass,
                            };
                            this.showLoading();
                            this.cxpService.cxpLogisticaExtrusionLogin(Usuario).then((rq) => {
                                const dt = JSON.parse(rq.toString());
                                console.log(dt);
                                if (dt.Status.STATUS === 'T' && dt.Objeto[0].STATUS === 1) {
                                    // console.log('bacan');
                                    this.txtCodigos.disabled = false;
                                    this.dismissLoading();
                                }
                                else if (dt.Status.STATUS === 'F') {
                                    this.toastMessage(`${dt.Status.MESSAGE}`, 'danger', 2000);
                                    this.dismissLoading();
                                    this.alertComprobarUsuario();
                                }
                                else if (dt.Status.STATUS === 'T' && dt.Objeto[0].STATUS === 0) {
                                    this.toastMessage('Credenciales Incorrectas.', 'danger', 2000);
                                    this.dismissLoading();
                                    this.alertComprobarUsuario();
                                }
                                else {
                                    this.toastMessage('Credenciales Incorrectas.', 'danger', 2050);
                                    this.dismissLoading();
                                    this.alertComprobarUsuario();
                                }
                            }, (err) => {
                                console.log(err);
                                this.toastMessage(err, 'danger', 2000);
                                this.dismissLoading();
                                this.alertComprobarUsuario();
                            });
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    alertEliminarEtiqueta() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                header: `Etiqueta ${this.pallet.CODBAR_MULTI}`,
                subHeader: 'Esta seguro que desea eliminar esta Etiqueta?.',
                backdropDismiss: true,
                buttons: [
                    {
                        text: 'Cancelar',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: () => {
                            console.log('Calcelar');
                        }
                    },
                    {
                        text: 'Confirmar',
                        handler: (data) => {
                            // console.log(`Eliminar: ${this.pallet.CODBAR_MULTI}`);
                            this.eliminarEtiquetaPallet();
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    toastMessage(mensaje, status, time) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const toast = yield this.toastCtrl.create({
                color: status,
                message: mensaje,
                duration: time
            });
            toast.present();
        });
    }
    eliminarCard(time) {
        const animation = Object(_ionic_angular__WEBPACK_IMPORTED_MODULE_4__["createAnimation"])()
            .addElement(document.getElementById('cardbobina'))
            .duration(time)
            .direction('alternate')
            .iterations(1)
            .keyframes([
            { offset: 0, transform: 'scale(1)', opacity: '1' },
            { offset: 0.5, transform: 'scale(1.5)', opacity: '0.5' },
            { offset: 1, transform: 'scale(2)', opacity: '0' }
        ]);
        animation.play();
        setTimeout(() => {
            this.pallet = null;
        }, time);
        // setTimeout(() => {
        //   console.log(this.pallet);
        // }, time + 500);
    }
    // Metodo que elimina letra por letra el string digitalizado en el campo de texto
    eliminarunoauno() {
        const text = this.txtCodigos.value;
        let cont = 0;
        let cont2 = text.length - 1;
        const arr = [];
        let newtext;
        for (let i = 0; i < text.length; i++) {
            arr.push(text.substring(cont, cont + 1));
            cont++;
        }
        const inter = setInterval(() => {
            // console.log(newtext);
            if (cont2 === -2) {
                clearInterval(inter);
                this.txtCodigos.setFocus();
            }
            newtext = arr.toString();
            this.txtCodigos.value = newtext.replace(/,/g, '');
            arr.splice(cont2, 1);
            cont2--;
        }, 90);
    }
    //#region Loading
    showLoading() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.isLoading = true;
            return yield this.loadingCtrl.create({
                cssClass: 'loading',
                message: 'Enviando...',
            }).then(a => {
                a.present().then(() => {
                    // console.log('presented');
                    if (!this.isLoading) {
                        a.dismiss();
                    }
                });
            });
        });
    }
    dismissLoading() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.isLoading = false;
            return yield this.loadingCtrl.dismiss().then(() => console.log('dismissed'));
        });
    }
};
BpEliminarEtiquetaComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ToastController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
    { type: _providers_web_services_cxp_cxp_service__WEBPACK_IMPORTED_MODULE_6__["CxpService"] }
];
BpEliminarEtiquetaComponent.propDecorators = {
    btnEliminar: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"], args: ['btnEliminar',] }],
    txtCodigos: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"], args: ['codigos',] }]
};
BpEliminarEtiquetaComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-bp-eliminar-etiqueta',
        template: _raw_loader_bp_eliminar_etiqueta_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_bp_eliminar_etiqueta_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], BpEliminarEtiquetaComponent);



/***/ }),

/***/ "xE6v":
/*!**********************************************************************************************************************!*\
  !*** ./src/app/pages/coexpan/logistica/control-productos/bodega-planta/bp-menu-planta/bp-menu-planta.component.scss ***!
  \**********************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-header .toolbar {\n  --background: rgba(104, 104, 104, 0.7);\n}\nion-header .toolbar ion-title {\n  font-size: 25px;\n  --color: rgba(255, 255, 255, 0.666);\n  text-shadow: 2px 2px 2px #4b4b4b;\n  letter-spacing: 2px;\n}\nion-footer {\n  /*Figuras*/\n}\nion-footer .tri_inf_izq, ion-footer .tri_inf_der {\n  position: absolute;\n  width: 100%;\n  height: 0%;\n  border-top: 50px solid transparent;\n  border-right: 410px solid rgba(186, 96, 12, 0.4);\n  border-bottom: 0px solid transparent;\n}\nion-footer .tri_inf_der {\n  position: relative;\n  border-left: 410px solid rgba(186, 96, 12, 0.5);\n}\n/*Componentes*/\nion-content {\n  --background: none;\n}\nion-content .grid-1 {\n  height: 100%;\n}\nion-content .grid-1 .row-1 {\n  height: 100%;\n}\nion-content .grid-1 .row-1 .btn-etq, ion-content .grid-1 .row-1 .btn-reetq {\n  --background: rgba(87, 87, 87, 0.9);\n  --color: white;\n}\nion-content .grid-1 .row-1 .btn-em, ion-content .grid-1 .row-1 .btn-sm {\n  --background: rgba(10, 157, 2, 0.9);\n  --color: white;\n}\nion-content .grid-1 .row-1 .btn-sm {\n  --background: rgba(250, 90, 90, 0.9);\n}\n.btn-sand {\n  padding-left: 0px;\n  padding-right: 0px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcYnAtbWVudS1wbGFudGEuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBR0U7RUFDRSxzQ0FBQTtBQUZKO0FBR0k7RUFDRSxlQUFBO0VBQ0EsbUNBQUE7RUFDQSxnQ0FBQTtFQUNBLG1CQUFBO0FBRE47QUFNQTtFQUNFLFVBQUE7QUFIRjtBQUlFO0VBQ0Usa0JBQUE7RUFDQSxXQUFBO0VBQ0EsVUFBQTtFQUNBLGtDQUFBO0VBQ0EsZ0RBQUE7RUFDQSxvQ0FBQTtBQUZKO0FBS0U7RUFFRSxrQkFBQTtFQUNBLCtDQUFBO0FBSko7QUFRQSxjQUFBO0FBQ0E7RUFDRSxrQkFBQTtBQUxGO0FBTUU7RUFDRSxZQUFBO0FBSko7QUFLSTtFQUNFLFlBQUE7QUFITjtBQUlNO0VBQ0UsbUNBQUE7RUFDQSxjQUFBO0FBRlI7QUFPTTtFQUNFLG1DQUFBO0VBQ0EsY0FBQTtBQUxSO0FBT007RUFFRSxvQ0FBQTtBQU5SO0FBWUE7RUFDRSxpQkFBQTtFQUNBLGtCQUFBO0FBVEYiLCJmaWxlIjoiYnAtbWVudS1wbGFudGEuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuXHJcbmlvbi1oZWFkZXIge1xyXG4gIC50b29sYmFyIHtcclxuICAgIC0tYmFja2dyb3VuZDogcmdiYSgxMDQsIDEwNCwgMTA0LCAwLjcpO1xyXG4gICAgaW9uLXRpdGxlIHtcclxuICAgICAgZm9udC1zaXplOiAyNXB4O1xyXG4gICAgICAtLWNvbG9yOiByZ2JhKDI1NSwgMjU1LCAyNTUsIDAuNjY2KTtcclxuICAgICAgdGV4dC1zaGFkb3c6IDJweCAycHggMnB4IHJnYig3NSwgNzUsIDc1KTtcclxuICAgICAgbGV0dGVyLXNwYWNpbmc6IDJweDtcclxuICAgIH1cclxuICB9XHJcbn1cclxuXHJcbmlvbi1mb290ZXIge1xyXG4gIC8qRmlndXJhcyovXHJcbiAgLnRyaV9pbmZfaXpxIHtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgaGVpZ2h0OiAwJTtcclxuICAgIGJvcmRlci10b3A6IDUwcHggc29saWQgdHJhbnNwYXJlbnQ7XHJcbiAgICBib3JkZXItcmlnaHQ6IDQxMHB4IHNvbGlkIHJnYigxODYsIDk2LCAxMiwgMC40KTtcclxuICAgIGJvcmRlci1ib3R0b206IDBweCBzb2xpZCB0cmFuc3BhcmVudDtcclxuICB9XHJcblxyXG4gIC50cmlfaW5mX2RlciB7XHJcbiAgICBAZXh0ZW5kIC50cmlfaW5mX2l6cTtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIGJvcmRlci1sZWZ0OiA0MTBweCBzb2xpZCByZ2IoMTg2LCA5NiwgMTIsIDAuNSk7XHJcbiAgfVxyXG59XHJcblxyXG4vKkNvbXBvbmVudGVzKi9cclxuaW9uLWNvbnRlbnQge1xyXG4gIC0tYmFja2dyb3VuZDogbm9uZTtcclxuICAuZ3JpZC0xIHtcclxuICAgIGhlaWdodDogMTAwJTtcclxuICAgIC5yb3ctMSB7XHJcbiAgICAgIGhlaWdodDogMTAwJTtcclxuICAgICAgLmJ0bi1ldHEge1xyXG4gICAgICAgIC0tYmFja2dyb3VuZDogcmdiYSg4NywgODcsIDg3LCAwLjkpO1xyXG4gICAgICAgIC0tY29sb3I6IHdoaXRlO1xyXG4gICAgICB9XHJcbiAgICAgIC5idG4tcmVldHEge1xyXG4gICAgICAgIEBleHRlbmQgLmJ0bi1ldHFcclxuICAgICAgfVxyXG4gICAgICAuYnRuLWVtIHtcclxuICAgICAgICAtLWJhY2tncm91bmQ6IHJnYmEoMTAsIDE1NywgMiwgMC45KTtcclxuICAgICAgICAtLWNvbG9yOiB3aGl0ZTtcclxuICAgICAgfVxyXG4gICAgICAuYnRuLXNtIHtcclxuICAgICAgICBAZXh0ZW5kIC5idG4tZW07XHJcbiAgICAgICAgLS1iYWNrZ3JvdW5kOiByZ2JhKDI1MCwgOTAsIDkwLCAwLjkpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG59XHJcblxyXG4uYnRuLXNhbmQge1xyXG4gIHBhZGRpbmctbGVmdDogMHB4O1xyXG4gIHBhZGRpbmctcmlnaHQ6IDBweDtcclxufVxyXG5cclxuXHJcbiJdfQ== */");

/***/ }),

/***/ "ySe7":
/*!********************************************************************************************************************!*\
  !*** ./src/app/pages/coexpan/logistica/control-productos/bodega-planta/bp-menu-planta/bp-menu-planta.component.ts ***!
  \********************************************************************************************************************/
/*! exports provided: BpMenuPlantaComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BpMenuPlantaComponent", function() { return BpMenuPlantaComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_bp_menu_planta_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./bp-menu-planta.component.html */ "b6fR");
/* harmony import */ var _bp_menu_planta_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./bp-menu-planta.component.scss */ "xE6v");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "TEn/");






let BpMenuPlantaComponent = class BpMenuPlantaComponent {
    constructor(routes, menu) {
        this.routes = routes;
        this.menu = menu;
    }
    ngOnInit() { }
    pageEtqEntradaMercancia() {
        this.routes.navigateByUrl('pages/cxp/control/bp/etqem');
    }
    pageReimprimirEtiqueta() {
        this.routes.navigateByUrl('pages/cxp/control/bp/reimprimiretq');
    }
    pageEliminarEtiqueta() {
        this.routes.navigateByUrl('pages/cxp/control/bp/eliminaretq');
    }
    pageEntradaMercancia() {
        // this.routes.navigateByUrl('pages/cxp/control/bp/em');
        const strUserSap = localStorage.getItem('usersap');
        const usersap = JSON.parse(strUserSap);
        if (usersap !== null) {
            this.routes.navigateByUrl('pages/cxp/control/bp/em');
        }
        else {
            this.routes.navigateByUrl('pages/login');
        }
    }
    pageSalidaMercancia() {
        this.routes.navigateByUrl('pages/cxp/control/bp/sm');
    }
    openMenu() {
        this.menu.toggle();
    }
};
BpMenuPlantaComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["MenuController"] }
];
BpMenuPlantaComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-bp-menu-planta',
        template: _raw_loader_bp_menu_planta_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_bp_menu_planta_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], BpMenuPlantaComponent);



/***/ })

}]);
//# sourceMappingURL=coexpan-logistica-control-productos-control-productos-module.js.map