(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! D:\Coexpan\Area_TI\VisualStudioCode\app-movil\coexpan-handheld\src\main.ts */"zUnb");


/***/ }),

/***/ "4gYv":
/*!***********************************************************!*\
  !*** ./src/app/providers/web-services/cxp/cxp.service.ts ***!
  \***********************************************************/
/*! exports provided: CxpService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CxpService", function() { return CxpService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "IheW");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/environments/environment */ "AytR");




let CxpService = class CxpService {
    constructor(http) {
        this.http = http;
    }
    //#region BODEGA PLANTA
    obtenerToken(id) {
        return new Promise((resolve, reject) => {
            this.http.post(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].URL_API_COEXPAN}/security/obtenertoken`, JSON.stringify(id))
                .subscribe(res => {
                resolve(res);
            }, (err) => {
                reject(err);
                console.log(err);
            });
        });
    }
    cxpLogisticaEjecutarEtlPesaje() {
        return new Promise((resolve, reject) => {
            this.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].URL_API_COEXPAN}/logistica/scanner/initpesaje`)
                .subscribe(res => {
                resolve(res);
            }, (err) => {
                reject(err);
                console.log(err);
            });
        });
    }
    cxpLogisticaEntradaMercancia(data) {
        return new Promise((resolve, reject) => {
            this.http.post(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].URL_API_COEXPAN}/logistica/scanner/em`, JSON.stringify(data))
                .subscribe(res => {
                resolve(res);
            }, (err) => {
                reject(err);
                console.log(err);
            });
        });
    }
    cxpLogisticaSalidaMercancia(data) {
        return new Promise((resolve, reject) => {
            this.http.post(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].URL_API_COEXPAN}/logistica/scanner/sm`, JSON.stringify(data))
                .subscribe(res => {
                resolve(res);
            }, (err) => {
                reject(err);
                console.log(err);
            });
        });
    }
    cxpLogisticaImprimirEtiquetaMultimple(data) {
        return new Promise((resolve, reject) => {
            this.http.post(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].URL_API_COEXPAN}/logistica/bodegaplanta/ang-imprimiretq`, JSON.stringify(data))
                .subscribe(res => {
                resolve(res);
            }, (err) => {
                reject(err);
                console.log(err);
            });
        });
    }
    cxpLogisticaGetPalletBobinas(codbarramulti) {
        return new Promise((resolve, reject) => {
            this.http.post(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].URL_API_COEXPAN}/logistica/scanner/obtenerpallet`, JSON.stringify(codbarramulti))
                .subscribe(res => {
                resolve(res);
            }, (err) => {
                reject(err);
            });
        });
    }
    cxpLogisticaenviarEntradaMercancia(datos) {
        return new Promise((resolve, reject) => {
            this.http.post(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].URL_API_COEXPAN}/logistica/scanner/postem`, JSON.stringify(datos))
                .subscribe(res => {
                resolve(res);
            }, (err) => {
                reject(err);
            });
        });
    }
    cxpLogisticaEliminarEtiquetaPallet(data) {
        return new Promise((resolve, reject) => {
            this.http.post(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].URL_API_COEXPAN}/logistica/scanner/eliminaretiqueta`, JSON.stringify(data))
                .subscribe(res => {
                resolve(res);
            }, (err) => {
                reject(err);
                console.log(err);
            });
        });
    }
    //#endregion
    //#region BODEGA RENCA
    cxpBrEnviarIngreso(data) {
        return new Promise((resolve, reject) => {
            this.http.post(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].URL_API_COEXPAN}/logistica/bodegarenca/ionicingreso`, JSON.stringify(data))
                .subscribe(res => {
                resolve(res);
            }, (err) => {
                reject(err);
                console.log(err);
            });
        });
    }
    cxpBrEnviarEgreso(data) {
        return new Promise((resolve, reject) => {
            this.http.post(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].URL_API_COEXPAN}/logistica/bodegarenca/ionicegreso`, JSON.stringify(data))
                .subscribe(res => {
                resolve(res);
            }, (err) => {
                reject(err);
                console.log(err);
            });
        });
    }
    //#endregion
    //#region METODOS GENERICOS
    cxpLogisticaLogin(data) {
        return new Promise((resolve, reject) => {
            this.http.post(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].URL_API_COEXPAN}/security/login`, JSON.stringify(data))
                .subscribe(res => {
                console.log(res);
                resolve(res);
            }, (err) => {
                reject(err);
                console.log(err);
            });
        });
    }
    cxpLogisticaExtrusionLogin(data) {
        return new Promise((resolve, reject) => {
            this.http.post(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].URL_API_COEXPAN}/logistica/scanner/login`, JSON.stringify(data))
                .subscribe(res => {
                resolve(res);
            }, (err) => {
                reject(err);
                console.log(err);
            });
        });
    }
    cxpLogisticaLogout(data) {
        return new Promise((resolve, reject) => {
            this.http.post(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].URL_API_COEXPAN}/security/logout`, JSON.stringify(data))
                .subscribe(res => {
                resolve(res);
            }, (err) => {
                reject(err);
                console.log(err);
            });
        });
    }
    cxpLogisticaGetImpresora() {
        return new Promise((resolve, reject) => {
            this.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].URL_API_COEXPAN}/dashboard/getimpresoras`)
                .subscribe(res => {
                resolve(res);
            }, (err) => {
                reject(err);
                console.log(err);
            });
        });
    }
    cxpEstadoImpresora(data) {
        return new Promise((resolve, reject) => {
            this.http.post(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].URL_API_COEXPAN}/impresora/estado`, JSON.stringify(data))
                .subscribe(res => {
                resolve(res);
            }, (err) => {
                reject(err);
                console.log(err);
            });
        });
    }
    //#endregion METODOS GENERICOS
    //#region METODOS bp-etq-reimprimir
    cxpObtenerInformacionEtiquetaPallet(data) {
        return new Promise((resolve, reject) => {
            this.http.post(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].URL_API_COEXPAN}/logistica/scanner/getinfoetq`, JSON.stringify(data))
                .subscribe(res => {
                resolve(res);
            }, (err) => {
                reject(err);
                console.log(err);
            });
        });
    }
    cxpReimprimirEtiquetaPallet(data) {
        return new Promise((resolve, reject) => {
            this.http.post(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].URL_API_COEXPAN}/logistica/scanner/reimprimiretq`, JSON.stringify(data))
                .subscribe(res => {
                resolve(res);
            }, (err) => {
                reject(err);
                console.log(err);
            });
        });
    }
    //#endregion METODOS bp-etq-reimprimir
    // TODO INTEGRACION 20-07-2021 Emision de etiqueta,
    cxpReimprimirEtiquetaRecepcion(data) {
        console.log('Bodega Recepcion 02-03-2023');
        console.log(data);
        return new Promise((resolve, reject) => {
            this.http.post(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].URL_API_IMPRESORA}`, JSON.stringify(data))
                .subscribe(res => {
                resolve(res);
            }, (err) => {
                reject(err);
                console.log(err);
            });
        });
    }
};
CxpService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] }
];
CxpService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
        providedIn: 'root',
    })
], CxpService);



/***/ }),

/***/ "AytR":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
    production: false,
    // PRODUCCION
    URL_API_COEXPAN: 'https://api.coexpan.cl/api/v1/wscoexpan',
    // URL_API_COEXPAN: 'https://api.coexpan.cl/cat-services/app/n-api-coexpan/wscoexpan',
    URL_API_IMPRESORA: 'https://api.coexpan.cl/api/v1/serv-etiquetas/etq-bodega/recepcion-bobina',
    //DESARROLLO
    // URL_API_COEXPAN: 'https://test.coexpan.cl/api/v1/wscoexpan',
    // URL_API_COEXPAN: 'http://localhost:44302/wscoexpan',
    // URL_API_IMPRESORA: 'https://api.coexpan.cl/api/v1/serv-etiquetas/',
    // SAP BO
    // BD_SAP: 'SBO_COEMBAL_FUSION_TEST',
    BD_SAP: 'SBO_COEMBAL_FUSION',
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "JUB7":
/*!*******************************************!*\
  !*** ./src/app/models/Registros.model.ts ***!
  \*******************************************/
/*! exports provided: RegistrosModel, EstadoIngresoModel, EstadoIngresoV2Model, WsStatusV2Model, GetConsultaModel, GetConsultaModelV2, ImprimirEtqMultipleZebraModel, GetRequestModel, IMPRESORAModel, ImpresoraPostModel, PalletBobinasModel, BobinaModel, PalletModel, LoginModel, MessageModel, UserSapModel, SapPostModel, InfoEtiquetaModel, ImpresoraEtiquetaPalletModel, StatusSqlModel, StatusDtModel, PalletRecepcionModel */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RegistrosModel", function() { return RegistrosModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EstadoIngresoModel", function() { return EstadoIngresoModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EstadoIngresoV2Model", function() { return EstadoIngresoV2Model; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WsStatusV2Model", function() { return WsStatusV2Model; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GetConsultaModel", function() { return GetConsultaModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GetConsultaModelV2", function() { return GetConsultaModelV2; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ImprimirEtqMultipleZebraModel", function() { return ImprimirEtqMultipleZebraModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GetRequestModel", function() { return GetRequestModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IMPRESORAModel", function() { return IMPRESORAModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ImpresoraPostModel", function() { return ImpresoraPostModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PalletBobinasModel", function() { return PalletBobinasModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BobinaModel", function() { return BobinaModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PalletModel", function() { return PalletModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginModel", function() { return LoginModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MessageModel", function() { return MessageModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserSapModel", function() { return UserSapModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SapPostModel", function() { return SapPostModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InfoEtiquetaModel", function() { return InfoEtiquetaModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ImpresoraEtiquetaPalletModel", function() { return ImpresoraEtiquetaPalletModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StatusSqlModel", function() { return StatusSqlModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StatusDtModel", function() { return StatusDtModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PalletRecepcionModel", function() { return PalletRecepcionModel; });
class RegistrosModel {
}
class EstadoIngresoModel {
}
class EstadoIngresoV2Model {
}
class WsStatusV2Model {
}
class GetConsultaModel {
}
class GetConsultaModelV2 {
}
class ImprimirEtqMultipleZebraModel {
}
class GetRequestModel {
}
class IMPRESORAModel {
}
class ImpresoraPostModel {
}
class PalletBobinasModel {
}
class BobinaModel {
}
class PalletModel {
}
class LoginModel {
}
class MessageModel {
}
class UserSapModel {
}
class SapPostModel {
}
//#region bp-etq-reimprimir.component MODEL
class InfoEtiquetaModel {
}
class ImpresoraEtiquetaPalletModel {
}
class StatusSqlModel {
}
class StatusDtModel {
}
// TODO INTEGRACION 20-07-2021
class PalletRecepcionModel {
}
//#endregion


/***/ }),

/***/ "KF1J":
/*!***************************************************************!*\
  !*** ./src/app/providers/interceptors/headers.interceptor.ts ***!
  \***************************************************************/
/*! exports provided: HeadersInterceptor */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HeadersInterceptor", function() { return HeadersInterceptor; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");


let HeadersInterceptor = class HeadersInterceptor {
    constructor() { }
    intercept(request, next) {
        const ContentType = 'application/json; charset=UTF-8';
        const Accept = 'application/json';
        let authorization = '';
        // console.log(request.body.toString());
        if (localStorage.getItem('token') !== null) {
            authorization = localStorage.getItem('token');
        }
        console.log(request.method);
        if (request.method === 'GET') {
            request = request.clone({
                setHeaders: {
                    Authorization: authorization,
                    'Content-Type': ContentType,
                    Accept,
                },
            });
            console.log(request.url);
        }
        else {
            if (request.body.toString() === '[object FormData]') {
                console.log('Se envió un Archivo');
            }
            else {
                console.log(`url dada: ${request.url}`);
                if (request.url === 'https://localhost:44342/api/etq-bodega/recepcion-bobina') {
                    // console.log('paso por nueva api');
                    request = request.clone({
                        setHeaders: {
                            // Authorization: authorization,
                            'Content-Type': 'application/json',
                            Accept: 'application/json',
                        },
                    });
                }
                else {
                    request = request.clone({
                        setHeaders: {
                            Authorization: authorization,
                            'Content-Type': ContentType,
                            Accept,
                        },
                    });
                }
            }
        }
        return next.handle(request);
    }
};
HeadersInterceptor.ctorParameters = () => [];
HeadersInterceptor = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])()
], HeadersInterceptor);



/***/ }),

/***/ "Sy1n":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_app_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./app.component.html */ "VzVu");
/* harmony import */ var _app_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app-component.scss */ "pg99");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _models_Registros_model__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./models/Registros.model */ "JUB7");
/* harmony import */ var _providers_web_services_cxp_cxp_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./providers/web-services/cxp/cxp.service */ "4gYv");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ "TEn/");








let AppComponent = class AppComponent {
    //#endregion Objetos y Variables
    constructor(routes, cxpService, toastController, alertCtrl, menu) {
        this.routes = routes;
        this.cxpService = cxpService;
        this.toastController = toastController;
        this.alertCtrl = alertCtrl;
        this.menu = menu;
        //#region Objetos y Variables
        this.impresoras = new _models_Registros_model__WEBPACK_IMPORTED_MODULE_5__["GetRequestModel"]();
        this.impspinner = false;
        this.btnlo = {
            enabled: false,
            texto: 'Iniciar Sesión',
        };
    }
    ngOnInit() {
        this.textoBtnlo();
    }
    menuPlanta() {
        this.routes.navigateByUrl('pages/cxp/control/bp');
        this.menu.close();
    }
    menuBodegaRenca() {
        this.routes.navigateByUrl('pages/cxp/control/br');
        this.menu.close();
    }
    menuInicio() {
        this.routes.navigateByUrl('/');
        this.menu.close();
    }
    //#region Login-Logout
    loginLogoutSap() {
        //#region Variables
        let request = new _models_Registros_model__WEBPACK_IMPORTED_MODULE_5__["MessageModel"]();
        const user = localStorage.getItem('usersap');
        let logout = {
            user: '',
            token: ''
        };
        logout = JSON.parse(user);
        localStorage.getItem('usersap');
        //#endregion Variables
        if (user) {
            this.AlertaCerrarSesion();
        }
        else {
            this.menu.toggle();
            this.routes.navigateByUrl('pages/login');
        }
    }
    cerrarSesionSap() {
        //#region Variables
        let request = new _models_Registros_model__WEBPACK_IMPORTED_MODULE_5__["MessageModel"]();
        const user = localStorage.getItem('usersap');
        let logout = {
            user: '',
            token: ''
        };
        logout = JSON.parse(user);
        localStorage.getItem('usersap');
        //#endregion Variables
        logout = JSON.parse(user);
        localStorage.getItem('usersap');
        this.cxpService.cxpLogisticaLogout(logout).then((data) => {
            console.log(data);
            request = JSON.parse(data.toString());
            this.messageToast(request.MESSAGE, 2000);
            localStorage.removeItem('usersap');
            this.textoBtnlo();
            this.menu.toggle();
            this.routes.navigateByUrl('/');
        }, (err) => {
            console.log(err);
        });
    }
    textoBtnlo() {
        const user = localStorage.getItem('usersap');
        // console.log(user);
        if (user) {
            this.btnlo.texto = 'Cerrar Sesión SAP BO.';
        }
        else {
            this.btnlo.texto = 'Iniciar Sesión SAP BO.';
        }
    }
    AlertaCerrarSesion() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                cssClass: '',
                header: 'SAP Business One',
                message: 'Presione <strong>Continuar</strong> para cerrar la sesión.',
                buttons: [
                    {
                        text: 'Cancelar',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: (blah) => {
                            // console.log('Confirm Cancel: blah');
                        }
                    }, {
                        text: 'Continuar',
                        handler: () => {
                            this.cerrarSesionSap();
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    //#endregion Login-Logout
    //#region Impresora
    obtenerImpresoras() {
        let rq = new _models_Registros_model__WEBPACK_IMPORTED_MODULE_5__["GetRequestModel"]();
        this.cxpService.cxpLogisticaGetImpresora().then(data => {
            rq = JSON.parse(data.toString());
            // console.log(rq);
            this.impresoras = rq;
            this.alertselectimpresora();
        }, (err) => {
            console.log(err);
        });
    }
    alertselectimpresora() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const inputss = [];
            this.impresoras.Objeto.forEach(im => {
                inputss.push(this.generarInput(im.NSERIAL, im.TAG_NOMBRE, im.IP));
            });
            const alert = yield this.alertCtrl.create({
                cssClass: '',
                header: 'Selec. Impresora',
                inputs: inputss,
                buttons: [
                    {
                        text: 'OK',
                        handler: (ip) => {
                            // console.log(ip);
                            localStorage.setItem('ipimp', ip);
                            this.comprobarEstadoImpresora(ip);
                        },
                    },
                ],
            });
            yield alert.present();
        });
    }
    generarInput(dname, dlabel, dvalue) {
        const input = {
            name: dname,
            type: 'radio',
            label: dlabel,
            value: dvalue,
        };
        return input;
    }
    comprobarEstadoImpresora(ip) {
        //#region Variables
        this.impspinner = true;
        this.btnimp.disabled = true;
        let status = new _models_Registros_model__WEBPACK_IMPORTED_MODULE_5__["GetRequestModel"]();
        const impresora = new _models_Registros_model__WEBPACK_IMPORTED_MODULE_5__["ImpresoraPostModel"]();
        impresora.ipAddress = ip;
        //#endregion Variables
        this.cxpService.cxpEstadoImpresora(impresora).then(data => {
            status = JSON.parse(data.toString());
            // console.log(status);
            if (status.Status.STATUS === 'T') {
                let time = 2000;
                status.Objeto.forEach(el => {
                    this.messageToast(el, time);
                    console.log(el);
                    time += 2000;
                });
            }
            else if (status.Status.STATUS === 'F') {
                let str = `Error con la impresora.\n`;
                status.Objeto.forEach(el => {
                    str += ` - ${el}\n`;
                });
                this.messageToast(str, 5000);
            }
            else {
                const str = `${status.Status.MESSAGE}\n${status.Status.MESSAGE_EXCEPTION_DESCR}`;
                this.messageToast(str, 5000);
            }
            //#region Variables
            this.impspinner = false;
            this.btnimp.disabled = false;
            //#endregion Variables
        }, (err) => {
            this.messageToast(err, 5000);
            //#region Variables
            this.impspinner = false;
            this.btnimp.disabled = false;
            //#endregion Variables
        });
    }
    //#endregion Impresora
    //#region _Herramientas
    messageToast(msj, time) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const toast = yield this.toastController.create({
                message: msj,
                duration: time,
            });
            toast.present();
        });
    }
    prueba() {
        console.log('Hola Hijo mio.');
    }
};
AppComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
    { type: _providers_web_services_cxp_cxp_service__WEBPACK_IMPORTED_MODULE_6__["CxpService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["ToastController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["MenuController"] }
];
AppComponent.propDecorators = {
    btnimp: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"], args: ['btnImpresora',] }]
};
AppComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-root',
        template: _raw_loader_app_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_app_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], AppComponent);



/***/ }),

/***/ "VzVu":
/*!**************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-app>\r\n  <ion-menu side=\"start\" type=\"push\" contentId=\"main\">\r\n    <ion-header>\r\n      <ion-toolbar color=\"warning\">\r\n        <ion-title>Menu Logística</ion-title>\r\n      </ion-toolbar>\r\n    </ion-header>\r\n    <ion-content>\r\n      <ion-list>\r\n        <ion-item button color=\"light\" (click)=\"menuInicio()\">Inicio</ion-item>\r\n        <ion-item color=\"medium\">Menu Bodegas</ion-item>\r\n        <ion-item button color=\"light\" (click)=\"menuPlanta()\">Bodega Planta</ion-item>\r\n        <ion-item button color=\"light\" (click)=\"menuBodegaRenca()\">Bodega Renca</ion-item>\r\n        <ion-item color=\"medium\">Utilidades</ion-item>\r\n        <ion-item #btnImpresora  button color=\"light\" (click)=\"obtenerImpresoras()\">\r\n          Impresora\r\n          <ion-spinner *ngIf=\"impspinner\" slot=\"end\" name=\"crescent\"></ion-spinner>\r\n        </ion-item>\r\n        <ion-item button color=\"warning\" (click)=\"loginLogoutSap()\">{{btnlo.texto}}</ion-item>\r\n      </ion-list>\r\n    </ion-content>\r\n  </ion-menu>\r\n  <ion-router-outlet id=\"main\"></ion-router-outlet>\r\n</ion-app>\r\n\r\n");

/***/ }),

/***/ "ZAI4":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "IheW");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser */ "jhN1");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./app-routing.module */ "vY5A");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./app.component */ "Sy1n");
/* harmony import */ var _providers_interceptors_headers_interceptor__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./providers/interceptors/headers.interceptor */ "KF1J");
/* harmony import */ var _providers_interceptors_httperror_interceptor__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./providers/interceptors/httperror.interceptor */ "oAoK");
/* harmony import */ var _angular_service_worker__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/service-worker */ "Jho9");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../environments/environment */ "AytR");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common */ "ofXK");













let AppModule = class AppModule {
};
AppModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
        declarations: [_app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"]],
        entryComponents: [],
        imports: [
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__["BrowserModule"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClientModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"].forRoot(),
            _app_routing_module__WEBPACK_IMPORTED_MODULE_6__["AppRoutingModule"],
            _angular_service_worker__WEBPACK_IMPORTED_MODULE_10__["ServiceWorkerModule"].register('ngsw-worker.js', { enabled: _environments_environment__WEBPACK_IMPORTED_MODULE_11__["environment"].production })
        ],
        providers: [
            {
                provide: _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouteReuseStrategy"],
                useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicRouteStrategy"]
            },
            {
                provide: _angular_common__WEBPACK_IMPORTED_MODULE_12__["LocationStrategy"],
                useClass: _angular_common__WEBPACK_IMPORTED_MODULE_12__["HashLocationStrategy"],
            },
            {
                provide: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HTTP_INTERCEPTORS"],
                useClass: _providers_interceptors_headers_interceptor__WEBPACK_IMPORTED_MODULE_8__["HeadersInterceptor"],
                multi: true,
            },
            {
                provide: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HTTP_INTERCEPTORS"],
                useClass: _providers_interceptors_httperror_interceptor__WEBPACK_IMPORTED_MODULE_9__["HttpErrorInterceptor"],
                multi: true,
            },
        ],
        bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"]],
    })
], AppModule);



/***/ }),

/***/ "kLfG":
/*!*****************************************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
  \*****************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./ion-action-sheet.entry.js": [
		"dUtr",
		"common",
		0
	],
	"./ion-alert.entry.js": [
		"Q8AI",
		"common",
		1
	],
	"./ion-app_8.entry.js": [
		"hgI1",
		"common",
		2
	],
	"./ion-avatar_3.entry.js": [
		"CfoV",
		"common",
		3
	],
	"./ion-back-button.entry.js": [
		"Nt02",
		"common",
		4
	],
	"./ion-backdrop.entry.js": [
		"Q2Bp",
		5
	],
	"./ion-button_2.entry.js": [
		"0Pbj",
		"common",
		6
	],
	"./ion-card_5.entry.js": [
		"ydQj",
		"common",
		7
	],
	"./ion-checkbox.entry.js": [
		"4fMi",
		"common",
		8
	],
	"./ion-chip.entry.js": [
		"czK9",
		"common",
		9
	],
	"./ion-col_3.entry.js": [
		"/CAe",
		10
	],
	"./ion-datetime_3.entry.js": [
		"WgF3",
		"common",
		11
	],
	"./ion-fab_3.entry.js": [
		"uQcF",
		"common",
		12
	],
	"./ion-img.entry.js": [
		"wHD8",
		13
	],
	"./ion-infinite-scroll_2.entry.js": [
		"2lz6",
		14
	],
	"./ion-input.entry.js": [
		"ercB",
		"common",
		15
	],
	"./ion-item-option_3.entry.js": [
		"MGMP",
		"common",
		16
	],
	"./ion-item_8.entry.js": [
		"9bur",
		"common",
		17
	],
	"./ion-loading.entry.js": [
		"cABk",
		"common",
		18
	],
	"./ion-menu_3.entry.js": [
		"kyFE",
		"common",
		19
	],
	"./ion-modal.entry.js": [
		"TvZU",
		"common",
		20
	],
	"./ion-nav_2.entry.js": [
		"vnES",
		"common",
		21
	],
	"./ion-popover.entry.js": [
		"qCuA",
		"common",
		22
	],
	"./ion-progress-bar.entry.js": [
		"0tOe",
		"common",
		23
	],
	"./ion-radio_2.entry.js": [
		"h11V",
		"common",
		24
	],
	"./ion-range.entry.js": [
		"XGij",
		"common",
		25
	],
	"./ion-refresher_2.entry.js": [
		"nYbb",
		"common",
		26
	],
	"./ion-reorder_2.entry.js": [
		"smMY",
		"common",
		27
	],
	"./ion-ripple-effect.entry.js": [
		"STjf",
		28
	],
	"./ion-route_4.entry.js": [
		"k5eQ",
		"common",
		29
	],
	"./ion-searchbar.entry.js": [
		"OR5t",
		"common",
		30
	],
	"./ion-segment_2.entry.js": [
		"fSgp",
		"common",
		31
	],
	"./ion-select_3.entry.js": [
		"lfGF",
		"common",
		32
	],
	"./ion-slide_2.entry.js": [
		"5xYT",
		33
	],
	"./ion-spinner.entry.js": [
		"nI0H",
		"common",
		34
	],
	"./ion-split-pane.entry.js": [
		"NAQR",
		35
	],
	"./ion-tab-bar_2.entry.js": [
		"knkW",
		"common",
		36
	],
	"./ion-tab_2.entry.js": [
		"TpdJ",
		"common",
		37
	],
	"./ion-text.entry.js": [
		"ISmu",
		"common",
		38
	],
	"./ion-textarea.entry.js": [
		"U7LX",
		"common",
		39
	],
	"./ion-toast.entry.js": [
		"L3sA",
		"common",
		40
	],
	"./ion-toggle.entry.js": [
		"IUOf",
		"common",
		41
	],
	"./ion-virtual-scroll.entry.js": [
		"8Mb5",
		42
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "kLfG";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "oAoK":
/*!*****************************************************************!*\
  !*** ./src/app/providers/interceptors/httperror.interceptor.ts ***!
  \*****************************************************************/
/*! exports provided: HttpErrorInterceptor */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HttpErrorInterceptor", function() { return HttpErrorInterceptor; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "kU1M");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _web_services_cxp_cxp_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../web-services/cxp/cxp.service */ "4gYv");
/* harmony import */ var _models_Registros_model__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../models/Registros.model */ "JUB7");








let HttpErrorInterceptor = class HttpErrorInterceptor {
    constructor(router, toastController, cxpService) {
        this.router = router;
        this.toastController = toastController;
        this.cxpService = cxpService;
        this.ID = 'ID20274622';
    }
    intercept(req, next) {
        return next.handle(req).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(error => {
            let errorMessage = '';
            if (error instanceof ErrorEvent) {
                // client-side error
                errorMessage = `Client-side error: ${error.error.message}`;
            }
            else {
                // backend error
                errorMessage = `Server-side error: ${error.status} ${error.message}`;
                console.log(error.error);
            }
            // aquí podrías agregar código que muestre el error en alguna parte fija de la pantalla.
            switch (error.status) {
                case 401:
                    localStorage.removeItem('token');
                    let rq = new _models_Registros_model__WEBPACK_IMPORTED_MODULE_7__["GetRequestModel"]();
                    this.cxpService.obtenerToken(this.ID).then((data) => {
                        rq = JSON.parse(data.toString());
                        localStorage.setItem('token', rq.Objeto);
                        console.log(data);
                    }, (err) => {
                        console.log(err);
                    });
                    this.presentToast(`Sesión expirada, se refrescara la App`, 5000);
                    setTimeout(() => {
                        window.location.reload();
                    }, 5000);
                    break;
                case 404:
                    this.presentToast(`Solicitud HTTP (API) no encontrada.`, 5000);
                    break;
                case 500:
                    this.presentToast(`Error en el sector Lógico del Servidor.`, 5000);
                    break;
                case 504:
                    this.presentToast(`Servidor Desconectado.`, 5000);
                    break;
                default:
                    this.presentToast(`${errorMessage}`, 5000);
                    break;
            }
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(errorMessage);
        }));
    }
    presentToast(mensaje, duracion) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const toast = yield this.toastController.create({
                message: mensaje, duration: duracion,
            });
            toast.present();
        });
    }
};
HttpErrorInterceptor.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ToastController"] },
    { type: _web_services_cxp_cxp_service__WEBPACK_IMPORTED_MODULE_6__["CxpService"] }
];
HttpErrorInterceptor = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
        providedIn: 'root',
    })
], HttpErrorInterceptor);



/***/ }),

/***/ "pg99":
/*!************************************!*\
  !*** ./src/app/app-component.scss ***!
  \************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-content {\n  --background: rgb(174, 182, 191, 0.1);\n}\nion-content ion-list {\n  padding-bottom: 0px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcYXBwLWNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBO0VBQ0UscUNBQUE7QUFBRjtBQUNFO0VBQ0UsbUJBQUE7QUFDSiIsImZpbGUiOiJhcHAtY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuaW9uLWNvbnRlbnQge1xyXG4gIC0tYmFja2dyb3VuZDogcmdiKDE3NCwgMTgyLCAxOTEsIDAuMSk7XHJcbiAgaW9uLWxpc3Qge1xyXG4gICAgcGFkZGluZy1ib3R0b206IDBweDtcclxuICB9XHJcbn1cclxuXHJcblxyXG5cclxuIl19 */");

/***/ }),

/***/ "vY5A":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");



const routes = [
    {
        path: 'pages',
        loadChildren: () => __webpack_require__.e(/*! import() | pages-pages-module */ "pages-pages-module").then(__webpack_require__.bind(null, /*! ./pages/pages.module */ "dgmN")).then(m => m.PagesModule)
    },
    { path: '', redirectTo: 'pages', pathMatch: 'full' },
    { path: '**', redirectTo: 'pages' },
];
const config = {
    useHash: false,
};
let AppRoutingModule = class AppRoutingModule {
};
AppRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes, config)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })
], AppRoutingModule);



/***/ }),

/***/ "zUnb":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "a3Wg");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "ZAI4");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "AytR");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(err => console.log(err));


/***/ }),

/***/ "zn8P":
/*!******************************************************!*\
  !*** ./$$_lazy_route_resource lazy namespace object ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "zn8P";

/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map