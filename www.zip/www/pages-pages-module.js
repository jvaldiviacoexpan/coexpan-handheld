(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-pages-module"],{

/***/ "/CUk":
/*!*********************************************************************!*\
  !*** ./src/app/pages/common/principal/inicio/inicio.component.scss ***!
  \*********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".full-height {\n  height: 100%;\n}\n\n/*Figuras*/\n\n.tri_sup_izq {\n  position: absolute;\n  width: 100%;\n  height: 0%;\n  border-top: 0px solid transparent;\n  border-right: 480px solid rgba(230, 7, 7, 0.7);\n  border-bottom: 50px solid transparent;\n}\n\n.tri_sup_der {\n  position: relative;\n  width: 100%;\n  height: 0%;\n  border-top: 0px solid transparent;\n  border-left: 480px solid rgba(7, 33, 230, 0.508);\n  border-bottom: 50px solid transparent;\n}\n\n.tri_inf_izq {\n  position: absolute;\n  width: 100%;\n  height: 0%;\n  border-top: 50px solid transparent;\n  border-right: 410px solid rgba(230, 7, 7, 0.7);\n  border-bottom: 0px solid transparent;\n}\n\n.tri_inf_der {\n  width: 100%;\n  height: 0%;\n  border-top: 50px solid transparent;\n  border-left: 410px solid rgba(7, 33, 230, 0.508);\n  border-bottom: 0px solid transparent;\n}\n\nion-header ion-toolbar {\n  --background: none;\n}\n\nion-header ion-toolbar ion-title {\n  position: absolute;\n}\n\nion-header ion-toolbar ion-button {\n  position: absolute !important;\n  z-index: 100;\n}\n\nion-content {\n  --ion-background-color: none;\n}\n\n.btn-sand {\n  margin-left: 15px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXGluaWNpby5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDQTtFQUNFLFlBQUE7QUFBRjs7QUFHQSxVQUFBOztBQUNBO0VBQ0Usa0JBQUE7RUFDQSxXQUFBO0VBQ0EsVUFBQTtFQUNBLGlDQUFBO0VBQ0EsOENBQUE7RUFDQSxxQ0FBQTtBQUFGOztBQUdBO0VBQ0Usa0JBQUE7RUFDQSxXQUFBO0VBQ0EsVUFBQTtFQUNBLGlDQUFBO0VBQ0EsZ0RBQUE7RUFDQSxxQ0FBQTtBQUFGOztBQUdBO0VBQ0Usa0JBQUE7RUFDQSxXQUFBO0VBQ0EsVUFBQTtFQUNBLGtDQUFBO0VBQ0EsOENBQUE7RUFDQSxvQ0FBQTtBQUFGOztBQUdBO0VBQ0UsV0FBQTtFQUNBLFVBQUE7RUFDQSxrQ0FBQTtFQUNBLGdEQUFBO0VBQ0Esb0NBQUE7QUFBRjs7QUFJRTtFQUNFLGtCQUFBO0FBREo7O0FBRUk7RUFDRSxrQkFBQTtBQUFOOztBQUVJO0VBQ0UsNkJBQUE7RUFDQSxZQUFBO0FBQU47O0FBS0E7RUFDRSw0QkFBQTtBQUZGOztBQUtBO0VBQ0UsaUJBQUE7QUFGRiIsImZpbGUiOiJpbmljaW8uY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuLmZ1bGwtaGVpZ2h0IHtcclxuICBoZWlnaHQ6IDEwMCU7XHJcbn1cclxuXHJcbi8qRmlndXJhcyovXHJcbi50cmlfc3VwX2l6cSB7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGhlaWdodDogMCU7XHJcbiAgYm9yZGVyLXRvcDogMHB4IHNvbGlkIHRyYW5zcGFyZW50O1xyXG4gIGJvcmRlci1yaWdodDogNDgwcHggc29saWQgcmdiYSgyMzAsIDcsIDcsIDAuNyk7XHJcbiAgYm9yZGVyLWJvdHRvbTogNTBweCBzb2xpZCB0cmFuc3BhcmVudDtcclxufVxyXG5cclxuLnRyaV9zdXBfZGVyIHtcclxuICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgaGVpZ2h0OiAwJTtcclxuICBib3JkZXItdG9wOiAwcHggc29saWQgdHJhbnNwYXJlbnQ7XHJcbiAgYm9yZGVyLWxlZnQ6IDQ4MHB4IHNvbGlkIHJnYmEoNywgMzMsIDIzMCwgMC41MDgpO1xyXG4gIGJvcmRlci1ib3R0b206IDUwcHggc29saWQgdHJhbnNwYXJlbnQ7XHJcbn1cclxuXHJcbi50cmlfaW5mX2l6cSB7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGhlaWdodDogMCU7XHJcbiAgYm9yZGVyLXRvcDogNTBweCBzb2xpZCB0cmFuc3BhcmVudDtcclxuICBib3JkZXItcmlnaHQ6IDQxMHB4IHNvbGlkIHJnYmEoMjMwLCA3LCA3LCAwLjcpO1xyXG4gIGJvcmRlci1ib3R0b206IDBweCBzb2xpZCB0cmFuc3BhcmVudDtcclxufVxyXG5cclxuLnRyaV9pbmZfZGVyIHtcclxuICB3aWR0aDogMTAwJTtcclxuICBoZWlnaHQ6IDAlO1xyXG4gIGJvcmRlci10b3A6IDUwcHggc29saWQgdHJhbnNwYXJlbnQ7XHJcbiAgYm9yZGVyLWxlZnQ6IDQxMHB4IHNvbGlkIHJnYmEoNywgMzMsIDIzMCwgMC41MDgpO1xyXG4gIGJvcmRlci1ib3R0b206IDBweCBzb2xpZCB0cmFuc3BhcmVudDtcclxufVxyXG5cclxuaW9uLWhlYWRlciB7XHJcbiAgaW9uLXRvb2xiYXIge1xyXG4gICAgLS1iYWNrZ3JvdW5kOiBub25lO1xyXG4gICAgaW9uLXRpdGxlIHtcclxuICAgICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgfVxyXG4gICAgaW9uLWJ1dHRvbiB7XHJcbiAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZSAhaW1wb3J0YW50O1xyXG4gICAgICB6LWluZGV4OiAxMDA7XHJcbiAgICB9XHJcbiAgfVxyXG59XHJcblxyXG5pb24tY29udGVudCB7XHJcbiAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjogbm9uZTtcclxufVxyXG5cclxuLmJ0bi1zYW5kIHtcclxuICBtYXJnaW4tbGVmdDogMTVweDtcclxufVxyXG5cclxuIl19 */");

/***/ }),

/***/ "8D7W":
/*!******************************************!*\
  !*** ./src/app/pages/pages.component.ts ***!
  \******************************************/
/*! exports provided: PagesComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PagesComponent", function() { return PagesComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");


let PagesComponent = class PagesComponent {
    constructor() { }
    ngOnInit() { }
};
PagesComponent.ctorParameters = () => [];
PagesComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-pages',
        template: `<ion-router-outlet></ion-router-outlet>`
    })
], PagesComponent);



/***/ }),

/***/ "B1Cg":
/*!************************************************************!*\
  !*** ./src/app/pages/common/principal/principal.module.ts ***!
  \************************************************************/
/*! exports provided: PrincipalModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PrincipalModule", function() { return PrincipalModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _principal_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./principal-routing.module */ "OiCg");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "ofXK");





let PrincipalModule = class PrincipalModule {
};
PrincipalModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"],
            _angular_common__WEBPACK_IMPORTED_MODULE_4__["CommonModule"],
            _principal_routing_module__WEBPACK_IMPORTED_MODULE_2__["PrincipalRoutingModule"],
        ],
        declarations: [
            ..._principal_routing_module__WEBPACK_IMPORTED_MODULE_2__["routedComponents"],
        ],
    })
], PrincipalModule);



/***/ }),

/***/ "Irzv":
/*!*******************************************************************!*\
  !*** ./src/app/pages/common/principal/inicio/inicio.component.ts ***!
  \*******************************************************************/
/*! exports provided: InicioComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InicioComponent", function() { return InicioComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_inicio_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./inicio.component.html */ "Qois");
/* harmony import */ var _inicio_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./inicio.component.scss */ "/CUk");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _providers_web_services_cxp_cxp_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../../providers/web-services/cxp/cxp.service */ "4gYv");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _models_Registros_model__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../models/Registros.model */ "JUB7");








let InicioComponent = class InicioComponent {
    constructor(router, cxpService, menu) {
        this.router = router;
        this.cxpService = cxpService;
        this.menu = menu;
        this.ID = 'ID20274622';
    }
    ngOnInit() {
        this.obtenerToken(this.ID);
    }
    pageInventario() {
        console.log('navegar al inventario');
    }
    pageLogistica() {
        this.router.navigateByUrl('pages/cxp/control/inicio');
    }
    obtenerToken(id) {
        localStorage.removeItem('token');
        let rq = new _models_Registros_model__WEBPACK_IMPORTED_MODULE_7__["GetRequestModel"]();
        this.cxpService.obtenerToken(id).then(data => {
            rq = JSON.parse(data.toString());
            localStorage.setItem('token', rq.Objeto);
            console.log(rq);
        }, (err) => {
            console.log(err);
        });
    }
    openMenu() {
        this.menu.toggle();
    }
};
InicioComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
    { type: _providers_web_services_cxp_cxp_service__WEBPACK_IMPORTED_MODULE_5__["CxpService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["MenuController"] }
];
InicioComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-inicio',
        template: _raw_loader_inicio_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_inicio_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], InicioComponent);



/***/ }),

/***/ "Jibr":
/*!***************************************************************!*\
  !*** ./src/app/pages/common/principal/principal.component.ts ***!
  \***************************************************************/
/*! exports provided: PrincipalComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PrincipalComponent", function() { return PrincipalComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");


let PrincipalComponent = class PrincipalComponent {
    constructor() { }
    ngOnInit() { }
};
PrincipalComponent.ctorParameters = () => [];
PrincipalComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-principal',
        template: `<ion-router-outlet></ion-router-outlet>`,
    })
], PrincipalComponent);



/***/ }),

/***/ "O5R8":
/*!*****************************************************************!*\
  !*** ./src/app/pages/common/principal/login/login.component.ts ***!
  \*****************************************************************/
/*! exports provided: LoginComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginComponent", function() { return LoginComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_login_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./login.component.html */ "PHCC");
/* harmony import */ var _login_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./login.component.scss */ "n/wm");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _providers_web_services_cxp_cxp_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../../providers/web-services/cxp/cxp.service */ "4gYv");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../app.component */ "Sy1n");
/* harmony import */ var _models_Registros_model__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../models/Registros.model */ "JUB7");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/environments/environment */ "AytR");










let LoginComponent = class LoginComponent {
    constructor(cxpService, toastCtrl, route, alertCtrl, menuCtrl) {
        this.cxpService = cxpService;
        this.toastCtrl = toastCtrl;
        this.route = route;
        this.alertCtrl = alertCtrl;
        this.menuCtrl = menuCtrl;
        this.spinner = false;
    }
    ngOnInit() { }
    ngAfterViewInit() {
        this.btnEnviar.disabled = true;
    }
    // onEstadoUsuario() {
    //   this.estadoUsuario.emit();
    // }
    checkUserPassword() {
        if (this.user.value.toString().length > 0 && this.pass.value.toString().length > 0) {
            this.btnEnviar.disabled = false;
        }
        else {
            this.btnEnviar.disabled = true;
        }
    }
    registrar() {
        //#region Variables
        this.spinner = true;
        const usuario = new _models_Registros_model__WEBPACK_IMPORTED_MODULE_8__["LoginModel"]();
        usuario.user = this.user.value.toString();
        usuario.password = this.pass.value.toString();
        usuario.companydb = src_environments_environment__WEBPACK_IMPORTED_MODULE_9__["environment"].BD_SAP;
        this.btnEnviar.disabled = true;
        //#endregion Variables
        this.cxpService.cxpLogisticaLogin(usuario).then(data => {
            const rq = JSON.parse(data.toString());
            // console.log(rq);
            if (rq.ID_SAP === 0) {
                // this.toastMesssage('Credenciales Correctas');
                const usersap = new _models_Registros_model__WEBPACK_IMPORTED_MODULE_8__["UserSapModel"]();
                usersap.User = usuario.user;
                usersap.Token = rq.TOKEN;
                const strUserSap = JSON.stringify(usersap);
                localStorage.setItem('usersap', strUserSap);
                this.route.navigateByUrl('/');
                setTimeout(() => {
                    window.location.reload();
                }, 200);
            }
            else {
                this.toastMesssage('Error con las credenciales, vuelva a intentarlo');
            }
            this.spinner = false;
            //#region Componentes
            const appComponent = new _app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"](this.route, this.cxpService, this.toastCtrl, this.alertCtrl, this.menuCtrl);
            appComponent.textoBtnlo();
            //#endregion Componentes
            this.btnEnviar.disabled = false;
            // console.log(rq);
        }, (err) => {
            console.log(err);
            this.btnEnviar.disabled = false;
            this.spinner = false;
        });
    }
    toastMesssage(msg) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const toast = yield this.toastCtrl.create({
                message: msg,
                duration: 3000
            });
            toast.present();
        });
    }
};
LoginComponent.ctorParameters = () => [
    { type: _providers_web_services_cxp_cxp_service__WEBPACK_IMPORTED_MODULE_5__["CxpService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ToastController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["MenuController"] }
];
LoginComponent.propDecorators = {
    user: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"], args: ['user',] }],
    pass: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"], args: ['pass',] }],
    btnEnviar: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"], args: ['btnEnviar',] }]
};
LoginComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-bp-login',
        template: _raw_loader_login_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_login_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], LoginComponent);



/***/ }),

/***/ "OiCg":
/*!********************************************************************!*\
  !*** ./src/app/pages/common/principal/principal-routing.module.ts ***!
  \********************************************************************/
/*! exports provided: PrincipalRoutingModule, routedComponents */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PrincipalRoutingModule", function() { return PrincipalRoutingModule; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "routedComponents", function() { return routedComponents; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _principal_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./principal.component */ "Jibr");
/* harmony import */ var _inicio_inicio_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./inicio/inicio.component */ "Irzv");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _login_login_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./login/login.component */ "O5R8");






const routes = [{
        path: '',
        component: _principal_component__WEBPACK_IMPORTED_MODULE_1__["PrincipalComponent"],
        children: [
            {
                path: 'inicio',
                component: _inicio_inicio_component__WEBPACK_IMPORTED_MODULE_2__["InicioComponent"],
            },
            {
                path: 'login',
                component: _login_login_component__WEBPACK_IMPORTED_MODULE_5__["LoginComponent"],
            }
        ]
    }];
let PrincipalRoutingModule = class PrincipalRoutingModule {
};
PrincipalRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"]],
    })
], PrincipalRoutingModule);

const routedComponents = [
    _principal_component__WEBPACK_IMPORTED_MODULE_1__["PrincipalComponent"],
    _inicio_inicio_component__WEBPACK_IMPORTED_MODULE_2__["InicioComponent"],
    _login_login_component__WEBPACK_IMPORTED_MODULE_5__["LoginComponent"],
];


/***/ }),

/***/ "PHCC":
/*!*********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/common/principal/login/login.component.html ***!
  \*********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header class=\"ion-no-border\">\r\n  <div class=\"tri_sup_izq\"> </div>\r\n  <div class=\"tri_sup_der\"></div>\r\n</ion-header>\r\n\r\n\r\n<ion-content fixed>\r\n  <ion-grid fixed size=\"sx\" class=\"full-height\">\r\n    <ion-row class=\"full-height ion-align-items-center\">\r\n      <ion-col size=\"12\">\r\n        <ion-item>\r\n          <img class=\"imagen\" src=\"https://www.coexpan.com/wp-content/uploads/2019/02/logotipo-coexpan.png\" alt=\"\">\r\n        </ion-item>\r\n      </ion-col>\r\n      <ion-col size=\"12\">\r\n        <ion-item class=\"input\">\r\n          <ion-label position=\"floating\">Usuario SAP BO</ion-label>\r\n          <ion-input #user (keyup)=\"checkUserPassword()\"  ></ion-input>\r\n        </ion-item>\r\n      </ion-col>\r\n      <ion-col size=\"12\">\r\n        <ion-item class=\"input\">\r\n          <ion-label position=\"floating\">Contraseña</ion-label>\r\n          <ion-input #pass type=\"password\" (keyup)=\"checkUserPassword()\" (keyup.enter)=\"registrar()\"></ion-input>\r\n        </ion-item>\r\n        <ion-col size=\"12\">\r\n          <ion-button type=\"submit\" #btnEnviar color=\"warning\" (click)=\"registrar()\" expand=\"block\" shape=\"round\">\r\n            <span *ngIf=\"!spinner\">Ingresar</span>\r\n            <ion-spinner *ngIf=\"spinner\" name=\"crescent\"></ion-spinner>\r\n          </ion-button>\r\n        </ion-col>\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n</ion-content>\r\n\r\n<ion-footer class=\"ion-no-border\">\r\n  <div class=\"tri_inf_izq\"> </div>\r\n  <div class=\"tri_inf_der\"></div>\r\n</ion-footer>\r\n");

/***/ }),

/***/ "Qois":
/*!***********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/common/principal/inicio/inicio.component.html ***!
  \***********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n\n<ion-header class=\"ion-no-border\">\n  <ion-toolbar class=\"toolbar\">\n    <div class=\"tri_sup_izq\"> </div>\n    <div class=\"tri_sup_der\"></div>\n    <ion-title class=\"title ion-no-padding\"><strong>Bodega Planta</strong></ion-title>\n    <ion-button class=\"btn-sand\"\n      (click)=\"openMenu()\" slot=\"start\" fill=\"outline\" color=\"black\" color=\"warning\">\n      <ion-icon color=\"warning\" name=\"menu\"></ion-icon>\n    </ion-button>\n  </ion-toolbar>\n</ion-header>\n\n\n<ion-content fixed>\n  <ion-grid fixed size=\"sx\" class=\"full-height\">\n    <ion-row class=\"full-height ion-align-items-center\">\n      <ion-col size=\"12\">\n        <img src=\"https://www.coexpan.com/wp-content/uploads/2019/02/logotipo-coexpan.png\" alt=\"Logo Coexpan\">\n      </ion-col>\n      <ion-col size=\"12\">\n        <ion-button color=\"medium\" size=\"large\" expand=\"block\" (click)=\"pageInventario()\">\n          Inventario\n        </ion-button>\n      </ion-col>\n\n      <ion-col size=\"12\">\n        <ion-button color=\"warning\" size=\"large\" expand=\"block\" (click)=\"pageLogistica()\">\n          Logística\n        </ion-button>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-content>\n\n<ion-footer class=\"ion-no-border\">\n  <div class=\"tri_inf_izq\"> </div>\n  <div class=\"tri_inf_der\"></div>\n</ion-footer>\n");

/***/ }),

/***/ "dgmN":
/*!***************************************!*\
  !*** ./src/app/pages/pages.module.ts ***!
  \***************************************/
/*! exports provided: PagesModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PagesModule", function() { return PagesModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _pages_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./pages.component */ "8D7W");
/* harmony import */ var _pages_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./pages-routing.module */ "viRw");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _common_principal_principal_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./common/principal/principal.module */ "B1Cg");






let PagesModule = class PagesModule {
};
PagesModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _pages_routing_module__WEBPACK_IMPORTED_MODULE_3__["PagesRoutingModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _common_principal_principal_module__WEBPACK_IMPORTED_MODULE_5__["PrincipalModule"],
        ],
        declarations: [
            _pages_component__WEBPACK_IMPORTED_MODULE_2__["PagesComponent"],
        ]
    })
], PagesModule);



/***/ }),

/***/ "n/wm":
/*!*******************************************************************!*\
  !*** ./src/app/pages/common/principal/login/login.component.scss ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("/**/\n.full-height {\n  height: 100%;\n}\n/*Figuras*/\n.tri_sup_izq {\n  position: absolute;\n  width: 100%;\n  height: 0%;\n  border-top: 0px solid transparent;\n  border-right: 480px solid rgba(6, 4, 128, 0.7);\n  border-bottom: 50px solid transparent;\n}\n.tri_sup_der {\n  width: 100%;\n  height: 0%;\n  border-top: 0px solid transparent;\n  border-left: 480px solid rgba(7, 33, 230, 0.508);\n  border-bottom: 50px solid transparent;\n}\n.tri_inf_izq {\n  position: absolute;\n  width: 100%;\n  height: 0%;\n  border-top: 50px solid transparent;\n  border-right: 410px solid rgba(6, 4, 128, 0.7);\n  border-bottom: 0px solid transparent;\n}\n.tri_inf_der {\n  position: relative;\n  width: 100%;\n  height: 0%;\n  border-top: 50px solid transparent;\n  border-left: 410px solid rgba(7, 33, 230, 0.508);\n  border-bottom: 0px solid transparent;\n}\nion-content {\n  --ion-background-color: none;\n}\nion-content .imagen {\n  background-color: rgba(255, 255, 255, 0.1);\n  border-radius: 10px;\n}\nion-content .input {\n  background-color: rgba(255, 255, 255, 0.85);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXGxvZ2luLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLEdBQUE7QUFDQTtFQUNFLFlBQUE7QUFDRjtBQUdBLFVBQUE7QUFDQTtFQUNFLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFVBQUE7RUFDQSxpQ0FBQTtFQUNBLDhDQUFBO0VBQ0EscUNBQUE7QUFBRjtBQUdBO0VBQ0UsV0FBQTtFQUNBLFVBQUE7RUFDQSxpQ0FBQTtFQUNBLGdEQUFBO0VBQ0EscUNBQUE7QUFBRjtBQUdBO0VBQ0Usa0JBQUE7RUFDQSxXQUFBO0VBQ0EsVUFBQTtFQUNBLGtDQUFBO0VBQ0EsOENBQUE7RUFDQSxvQ0FBQTtBQUFGO0FBR0E7RUFDRSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxVQUFBO0VBQ0Esa0NBQUE7RUFDQSxnREFBQTtFQUNBLG9DQUFBO0FBQUY7QUFHQTtFQUNFLDRCQUFBO0FBQUY7QUFDRTtFQUNFLDBDQUFBO0VBQ0EsbUJBQUE7QUFDSjtBQUNFO0VBQ0UsMkNBQUE7QUFDSiIsImZpbGUiOiJsb2dpbi5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi8qKi9cclxuLmZ1bGwtaGVpZ2h0IHtcclxuICBoZWlnaHQ6IDEwMCU7XHJcbn1cclxuXHJcblxyXG4vKkZpZ3VyYXMqL1xyXG4udHJpX3N1cF9penEge1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICB3aWR0aDogMTAwJTtcclxuICBoZWlnaHQ6IDAlO1xyXG4gIGJvcmRlci10b3A6IDBweCBzb2xpZCB0cmFuc3BhcmVudDtcclxuICBib3JkZXItcmlnaHQ6IDQ4MHB4IHNvbGlkIHJnYmEoNiwgNCwgMTI4LCAwLjcpO1xyXG4gIGJvcmRlci1ib3R0b206IDUwcHggc29saWQgdHJhbnNwYXJlbnQ7XHJcbn1cclxuXHJcbi50cmlfc3VwX2RlciB7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgaGVpZ2h0OiAwJTtcclxuICBib3JkZXItdG9wOiAwcHggc29saWQgdHJhbnNwYXJlbnQ7XHJcbiAgYm9yZGVyLWxlZnQ6IDQ4MHB4IHNvbGlkIHJnYmEoNywgMzMsIDIzMCwgMC41MDgpO1xyXG4gIGJvcmRlci1ib3R0b206IDUwcHggc29saWQgdHJhbnNwYXJlbnQ7XHJcbn1cclxuXHJcbi50cmlfaW5mX2l6cSB7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGhlaWdodDogMCU7XHJcbiAgYm9yZGVyLXRvcDogNTBweCBzb2xpZCB0cmFuc3BhcmVudDtcclxuICBib3JkZXItcmlnaHQ6IDQxMHB4IHNvbGlkIHJnYmEoNiwgNCwgMTI4LCAwLjcpO1xyXG4gIGJvcmRlci1ib3R0b206IDBweCBzb2xpZCB0cmFuc3BhcmVudDtcclxufVxyXG5cclxuLnRyaV9pbmZfZGVyIHtcclxuICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgaGVpZ2h0OiAwJTtcclxuICBib3JkZXItdG9wOiA1MHB4IHNvbGlkIHRyYW5zcGFyZW50O1xyXG4gIGJvcmRlci1sZWZ0OiA0MTBweCBzb2xpZCByZ2JhKDcsIDMzLCAyMzAsIDAuNTA4KTtcclxuICBib3JkZXItYm90dG9tOiAwcHggc29saWQgdHJhbnNwYXJlbnQ7XHJcbn1cclxuXHJcbmlvbi1jb250ZW50IHtcclxuICAtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yOiBub25lO1xyXG4gIC5pbWFnZW57XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2JhKDI1NSwgMjU1LCAyNTUsIDAuMSk7XHJcbiAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4gIH1cclxuICAuaW5wdXQge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogcmdiYSgkY29sb3I6ICNmZmZmZmYsICRhbHBoYTogMC44NSk7XHJcbiAgfVxyXG59XHJcbiJdfQ== */");

/***/ }),

/***/ "viRw":
/*!***********************************************!*\
  !*** ./src/app/pages/pages-routing.module.ts ***!
  \***********************************************/
/*! exports provided: PagesRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PagesRoutingModule", function() { return PagesRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _pages_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./pages.component */ "8D7W");
/* harmony import */ var _common_principal_inicio_inicio_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./common/principal/inicio/inicio.component */ "Irzv");





const routes = [{
        path: '',
        component: _pages_component__WEBPACK_IMPORTED_MODULE_3__["PagesComponent"],
        children: [
            {
                path: 'inicio',
                component: _common_principal_inicio_inicio_component__WEBPACK_IMPORTED_MODULE_4__["InicioComponent"],
            },
            // PAGINAS COEXPAN
            {
                path: 'cxp/control',
                loadChildren: () => __webpack_require__.e(/*! import() | coexpan-logistica-control-productos-control-productos-module */ "coexpan-logistica-control-productos-control-productos-module").then(__webpack_require__.bind(null, /*! ./coexpan/logistica/control-productos/control-productos.module */ "AEVk"))
                    .then(m => m.ControlProductosModule),
            },
            // POR DEFECTO
            {
                path: '',
                redirectTo: 'inicio',
                pathMatch: 'full',
            }
        ],
    }];
let PagesRoutingModule = class PagesRoutingModule {
};
PagesRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], PagesRoutingModule);



/***/ })

}]);
//# sourceMappingURL=pages-pages-module.js.map